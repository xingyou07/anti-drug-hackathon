# Ripple — The 10% (Anti-Drug Jam 2026)

**Ripple** is a first- and third-person interactive story set in a Singapore heartland estate. You walk to six moments (an offer at the void deck, a group chat, an overseas trip, an all-nighter, a friend who is off, and an emergency). In each moment the camera drops into **first person** so you feel the pressure, you choose, and then it pulls back to **third person** so you see the *ripple*: who your choice reached, and how. Nobody "wins". Ripple sits under `/youth` (the "I want to stay informed" track). The recovery track is untouched and never routes here.

The existing two-track onboarding, crisis sheet, tools shelf (`/youth/tools`) and Roulette module are kept.

## Import into Google AI Studio

1. Zip this folder (or push it to GitHub) and import it in AI Studio **Build** mode.
2. Run it. `npm run dev` serves the app on port 3000.
3. The optional "Try it in your own words" coach uses AI Studio's built-in `GEMINI_API_KEY` **on the server**. `vite.config.ts` mounts `POST /api/coach` (see `server/coach.ts`). The key is never sent to the browser. With no key, or offline, a scripted coach answers, so the game never breaks.
4. No external accounts, no other secrets, no analytics, no CDN assets. All 3D assets are generated in code.

`npm run build` type-checks and builds; `npm start` builds and serves the production bundle with the same API route.

## How to play

WASD / arrow keys (or the on-screen stick on phones) to walk, drag to look, **V** to swap first/third person, number keys 1-4 to answer. "Take me to the next moment" skips the walk. A short self-check (three questions) runs before and after; answers are never stored.

## Kiosk / roadshow behaviour

- **Resets between users:** after 75 s of no input the game shows "Still there?" for 15 s, then returns to the title with all choices cleared. Tune with `/youth?idle=45` (10-600 s). "Next player" on the last screen does the same.
- **Nothing persists** from a play-through: game state is in memory only.
- **Bad wifi:** the shell is ~80 KB gzipped; the 3D game (~170 KB) loads on demand; the practice coach falls back to on-device scripting after 12 s. Performance auto-drops to a low-graphics mode on slow machines (force with `?lowgfx`).
- **No WebGL:** the same six moments run in a 2D story mode.
- Chrome and Safari: WebGL 1/2 only, no pointer lock, no exotic APIs.

## Message safeguards

- Every fact shown is in `src/content/ripple.json` with a source and link (table below) and is rendered with a tappable citation. No invented statistics.
- No scenario names a drug with a dose, route, price, source or appealing effect. Scenarios teach exits and checking in.
- The emergency scene teaches **call 995 first**; unsafe options send the player back to choose again.
- The Gemini coach: player text is treated as untrusted data, never placed in the system prompt; crisis wording short-circuits before any model call and opens the helplines sheet; replies are schema-checked and blocklisted server-side (substances, doses, prices, links, numbers) and rate-limited. Nothing is stored or logged.
- All copy is marked `UNREVIEWED_PLACEHOLDER` and shows a "Demo content" chip. **Have an NCADA/CNB facilitator review it before public use.**
- Helplines live only in `src/content/crisis-resources.json` (checked 2026-09-19; Narcotics Anonymous is unconfirmed).

### Fact sources (checked 19 Sep 2026)

| id | Statement | Source |
| --- | --- | --- |
| `laced` | The Singapore government says many vapes are laced with addictive and harmful substances like etomidate, and calls it a public health threat. | [gov.sg — Stop Vaping: higher penalties for vaping offences (checked 19 Sep 2026)](https://www.gov.sg/stopvaping-penalties/) |
| `vapeFine` | Buying, using or possessing a vape is illegal in Singapore. The maximum fine was raised from $2,000 to $10,000. | [gov.sg — What is the Tobacco and Vaporisers Control Act? (in force 1 May 2026)](https://www.gov.sg/explainers/what-is-the-tobacco-and-vaporisers-control-act/) |
| `etomidate` | Since 1 May 2026, etomidate is a 'specified psychoactive substance' under the Tobacco and Vaporisers Control Act. Consuming or possessing it can mean a fine of up to $20,000, up to 10 years in jail, or both. | [gov.sg — What is the Tobacco and Vaporisers Control Act? (in force 1 May 2026)](https://www.gov.sg/explainers/what-is-the-tobacco-and-vaporisers-control-act/) |
| `overseas` | It is an offence for Singapore citizens and permanent residents to consume controlled drugs in Singapore and overseas. The same applies to etomidate. | [CNB — Misuse of Drugs Act; gov.sg — Tobacco and Vaporisers Control Act](https://www.cnb.gov.sg/singapore-drug-situation/misuse-of-drugs-act/) |
| `youthStats` | In 2025, half of the new drug abusers arrested in Singapore were below 30, and six in 10 new cannabis abusers arrested were below 30. CNB says the youth drug problem remains a concern. | [CNB — Annual Statistics 2025 (released 10 Feb 2026)](https://www.cnb.gov.sg/mediaroom/news/cnb-annual-statistics-2025/) |
| `vapeEnforcement` | Between April and June 2026, 2,428 people were caught and penalised for possessing or using vapes. 457 of them were etomidate vape offenders. | [Ministry of Health — press release, 11 Aug 2026](https://www.moh.gov.sg/newsroom/over-2-400-caught-vaping--nine-persons-charged-for-alleged-import-or-supply-of-etomidate-from-april-to-june-2026/) |
| `harm` | NCADA says drug abuse can harm individuals, families and society, and can cause irreversible damage to the heart, kidney, liver and brain, as well as mental health issues. | [NCADA — Frequently Asked Questions](https://www.ncada.org.sg/faq/) |
| `help` | NCADA's 'Seeking help' page lists organisations that support people affected by drug abuse, including WE CARE Community Services, the Singapore Anti-Narcotics Association, Narcotics Anonymous Singapore, and youth services such as Teen Challenge and Youthline. | [NCADA — Seeking help](https://www.ncada.org.sg/seeking-help/) |
| `call995` | SCDF lists loss of consciousness as a life-threatening emergency. Call 995, give the location, describe what you see, follow the call-taker's instructions, and do not hang up until told to. | [SCDF — Emergency Medical Services](https://www.scdf.gov.sg/home/about-scdf/emergency-medical-services) |

## Project layout

- `src/game/ripple/engine/` — three.js engine (procedural assets, first/third-person camera director)
- `src/game/ripple/ui/` — React overlays; `state.ts` game flow; `coach.ts` client coach
- `server/coach.ts` — Gemini practice coach route
- `src/content/*.json` — all copy; `CLAUDE.md` — project constitution (with the documented Gemini exception)
