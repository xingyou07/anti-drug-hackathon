import { defineConfig, loadEnv } from 'vite';
import type { Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';
import { createCoachHandler } from './server/coach';

/**
 * Mounts POST /api/coach on both the dev server and `vite preview`, so the same
 * code path runs in AI Studio's live preview and in a production-style start.
 * GEMINI_API_KEY is read from the server's environment at request time and is
 * never `define`d into the client bundle.
 */
function coachApi(fileEnv: Record<string, string>): Plugin {
  const handler = createCoachHandler({ getKey: () => process.env['GEMINI_API_KEY'] || fileEnv['GEMINI_API_KEY'] || undefined });
  return {
    name: 'ripple-coach-api',
    configureServer(server) {
      server.middlewares.use((req, res, next) => void handler(req, res, next));
    },
    configurePreviewServer(server) {
      server.middlewares.use((req, res, next) => void handler(req, res, next));
    },
  };
}

export default defineConfig(({ mode }) => {
  const fileEnv = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react(), coachApi(fileEnv)],
    server: {
      host: '0.0.0.0',
      port: 3000,
      allowedHosts: true,
      // AI Studio serves the preview over https, so HMR must use wss on 443.
      hmr: process.env['DISABLE_HMR'] === 'true' ? false : { protocol: 'wss', clientPort: 443 },
    },
    preview: { host: '0.0.0.0', port: 3000, allowedHosts: true },
    resolve: {
      alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
    },
    build: { target: 'es2020' },
  };
});
