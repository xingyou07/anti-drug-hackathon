import * as THREE from 'three';
import type { RippleEffect, RippleLandmark } from '@/content/types';
import { Character, LOOKS, MOOD_COLORS, ambientLook } from './characters';
import { World, WORLD_RADIUS } from './world';
import type { LandmarkInfo } from './world';
import { angleDiff, clamp, damp, glowSprite, lerp } from './util';

export type PovMode = 'first' | 'third';
export type Phase = 'title' | 'explore' | 'arriving' | 'moment' | 'ripple' | 'finale';

export interface MomentStage {
  id: string;
  landmark: RippleLandmark;
  npcs: string[];
  title: string;
  timeLabel: string;
  pressure: 1 | 2 | 3;
}

export interface HudInfo {
  index: number | null;
  distance: number;
  /** Radians, relative to where the camera is facing. 0 = straight ahead, + = to the right. */
  bearing: number;
}

export interface EngineCallbacks {
  onReachMoment: (index: number) => void;
  onArrived: (index: number) => void;
  onPov: (mode: PovMode) => void;
  onHud: (info: HudInfo) => void;
  onLowGfx: () => void;
}

interface Ring {
  mesh: THREE.Mesh;
  age: number;
  life: number;
  maxScale: number;
  delay: number;
}

interface Pulse {
  mesh: THREE.Mesh;
  target: string;
  effect: RippleEffect;
  t: number;
  delay: number;
  done: boolean;
}

const PLAYER_START = new THREE.Vector3(0, 0, 11);
const CAST_IDS = ['kai', 'jay', 'ryan', 'dev'] as const;
const GHOST_IDS = ['mum', 'teacher'] as const;
const ease = (t: number): number => t * t * (3 - 2 * t);

export class RippleEngine {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(62, 1, 0.1, 700);
  private readonly world: World;
  private readonly player: Character;
  private readonly cast = new Map<string, Character>();
  private readonly walkers: Array<{ c: Character; radius: number; speed: number; angle: number; dir: number }> = [];
  private readonly rings: Ring[] = [];
  private readonly pulses: Pulse[] = [];
  private readonly ringGeo = new THREE.RingGeometry(0.92, 1, 64);
  private readonly ringMats = new Map<RippleEffect, THREE.MeshBasicMaterial>();
  private readonly chatPhones = new THREE.Group();
  private readonly tmp = new THREE.Vector3();
  private readonly raf = { id: 0 };
  private readonly ro: ResizeObserver;

  private phase: Phase = 'title';
  private stages: MomentStage[];
  private activeIndex: number | null = null;
  private reachFired = false;
  private currentMoment: number | null = null;

  // player kinematics
  private readonly pos = PLAYER_START.clone();
  private readonly vel = new THREE.Vector2();
  private playerHeading = Math.PI;

  // camera state
  private camHeading = Math.PI;
  private camPitch = 0;
  private zoom = 6.2;
  private userPov: PovMode = 'third';
  private povBlend = 0;
  private povTarget = 0;
  private cineBlend = 0;
  private cineOn = false;
  private orbitAngle = 0;
  private orbitCenter = new THREE.Vector3(0, 1.4, 0);
  private orbitDist = 26;
  private orbitHeight = 9;
  private orbitSpeed = 0.06;
  private momentFace = 0;
  private fov = 62;
  private camClear = 1;

  // arrival tween
  private arrive: { t: number; from: THREE.Vector3; fromH: number; to: THREE.Vector3; toH: number; index: number } | null = null;

  // input
  private readonly keys = new Set<string>();
  private joy = new THREE.Vector2();
  private dragging = false;
  private lastPointer = { x: 0, y: 0 };
  private lookDx = 0;
  private lookDy = 0;
  private inputLocked = false;

  private time = 0;
  private last = 0;
  private frames = 0;
  private frameAccum = 0;
  private hudTick = 0;
  private lowGfx: boolean;
  private disposed = false;
  private readonly reduceMotion: boolean;
  private speakerId: string | null = null;

  constructor(
    private readonly container: HTMLElement,
    stages: MomentStage[],
    private readonly cb: EngineCallbacks,
    opts: { reduceMotion: boolean; lowGfx: boolean },
  ) {
    this.stages = stages;
    this.reduceMotion = opts.reduceMotion;
    this.lowGfx = opts.lowGfx;

    // Throws when WebGL is unavailable; the UI falls back to story mode.
    this.renderer = new THREE.WebGLRenderer({ antialias: !opts.lowGfx, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, opts.lowGfx ? 1 : 1.75));
    this.renderer.shadowMap.enabled = !opts.lowGfx;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    const el = this.renderer.domElement;
    el.style.display = 'block';
    el.style.width = '100%';
    el.style.height = '100%';
    el.style.touchAction = 'none';
    el.setAttribute('aria-hidden', 'true');
    container.appendChild(el);

    this.world = new World(this.scene, { lowGfx: opts.lowGfx });
    this.scene.add(this.chatPhones);
    this.chatPhones.visible = false;

    this.player = new Character(LOOKS['you'] ?? ambientLook(0));
    this.scene.add(this.player.group);
    this.player.setPosition(this.pos.x, this.pos.z);
    this.player.setHeading(this.playerHeading);
    this.player.group.traverse((o) => ((o as THREE.Mesh).castShadow = true));

    for (const id of [...CAST_IDS, ...GHOST_IDS]) {
      const c = new Character(LOOKS[id] ?? ambientLook(1));
      c.group.visible = false;
      if ((GHOST_IDS as readonly string[]).includes(id)) c.setGhost(true);
      this.scene.add(c.group);
      this.cast.set(id, c);
    }
    this.buildAmbient();
    this.buildChatPhones();

    for (const m of ['steady', 'wobble', 'strain'] as const) {
      this.ringMats.set(
        m,
        new THREE.MeshBasicMaterial({ color: MOOD_COLORS[m], transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }),
      );
    }

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    this.resize();

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    el.addEventListener('pointerdown', this.onPointerDown);
    el.addEventListener('pointermove', this.onPointerMove);
    el.addEventListener('pointerup', this.onPointerUp);
    el.addEventListener('pointercancel', this.onPointerUp);
    el.addEventListener('wheel', this.onWheel, { passive: false });

    this.applyPhaseCamera();
    this.last = performance.now();
    this.raf.id = requestAnimationFrame(this.loop);
  }

  /* ------------------------------------------------------------------ */
  /* Public API                                                          */
  /* ------------------------------------------------------------------ */

  getPhase(): Phase {
    return this.phase;
  }

  getPov(): PovMode {
    return this.povTarget > 0.5 ? 'first' : 'third';
  }

  setPhase(phase: Phase): void {
    this.phase = phase;
    if (phase === 'explore' || phase === 'moment') {
      this.cineOn = false;
      this.setPov(this.userPov, false);
      this.camHeading = this.playerHeading;
      this.camPitch = 0;
    }
    this.applyPhaseCamera();
  }

  setInputLocked(locked: boolean): void {
    this.inputLocked = locked;
    if (locked) {
      this.keys.clear();
      this.joy.set(0, 0);
    }
  }

  setJoystick(x: number, y: number): void {
    this.joy.set(x, y);
  }

  addLook(dx: number, dy: number): void {
    this.lookDx += dx;
    this.lookDy += dy;
  }

  setPov(mode: PovMode, remember = true): void {
    this.povTarget = mode === 'first' ? 1 : 0;
    if (remember) this.userPov = mode;
    this.cb.onPov(mode);
  }

  togglePov(): void {
    if (this.phase === 'title' || this.phase === 'ripple' || this.phase === 'finale' || this.phase === 'arriving') return;
    this.setPov(this.getPov() === 'first' ? 'third' : 'first', this.phase === 'explore');
  }

  /** Light the beacon for moment `index` and stage its NPCs so the player can spot them from afar. */
  setActiveMoment(index: number | null): void {
    this.activeIndex = index;
    this.reachFired = false;
    this.stages.forEach((s, i) => {
      const done = index === null || i < index;
      this.world.setBeacon(i, i === index ? 'active' : done ? 'done' : 'hidden', i === index ? { title: `${i + 1} · ${s.title}`, sub: s.timeLabel } : undefined);
    });
    if (index !== null) this.stageNpcs(index);
    this.world.setTimeOfDay(index === null ? 1 : index / Math.max(1, this.stages.length - 1));
  }

  /** Walk the player to the stand mark, turn to face the group and glide into first person. */
  beginMoment(index: number): void {
    const stage = this.stages[index];
    if (!stage) return;
    this.currentMoment = index;
    this.stageNpcs(index);
    // The beacon's light column would blow out the scene once you're standing in it.
    this.world.setBeacon(index, 'done');
    const info = this.world.landmarks[stage.landmark];
    this.phase = 'arriving';
    this.cineOn = false;
    this.arrive = {
      t: 0,
      from: this.pos.clone(),
      fromH: this.playerHeading,
      to: info.stand.clone(),
      toH: info.heading + Math.PI,
      index,
    };
    this.momentFace = info.heading + Math.PI;
    this.setPov('first', false);
    this.vel.set(0, 0);
  }

  /** Back to the decision after an "unsafe" choice in the emergency scene. */
  resumeMoment(): void {
    this.phase = 'moment';
    this.cineOn = false;
    this.setPov('first', false);
    this.camHeading = this.momentFace;
    this.camPitch = 0;
  }

  setSpeaker(id: string | null): void {
    this.speakerId = id;
    this.cast.forEach((c, k) => c.setSpeaking(k === id));
  }

  /** Cinematic pull-back to third person while the ripple plays out. */
  playRipple(index: number, people: Array<{ person: string; effect: RippleEffect }>, choiceEffect: RippleEffect): void {
    this.phase = 'ripple';
    this.setSpeaker(null);
    const stage = this.stages[index];
    if (!stage) return;
    const info = this.world.landmarks[stage.landmark];
    this.setPov('third', false);
    this.orbitCenter.set((info.npc.x + info.stand.x) / 2, 1.5, (info.npc.z + info.stand.z) / 2);
    this.orbitDist = 9.5;
    this.orbitHeight = 3.6;
    this.orbitSpeed = this.reduceMotion ? 0 : 0.16;
    // start the orbit from behind the player so the pull-back feels continuous
    this.orbitAngle = Math.atan2(this.pos.x - this.orbitCenter.x, this.pos.z - this.orbitCenter.z) + 0.5;
    this.cineOn = true;

    this.spawnRing(this.pos.x, this.pos.z, choiceEffect, 0, 22);
    this.spawnRing(this.pos.x, this.pos.z, choiceEffect, 0.45, 30);
    this.spawnRing(this.pos.x, this.pos.z, choiceEffect, 0.9, 40);

    let d = 0.5;
    for (const p of people) {
      const target = p.person === 'you' ? null : this.cast.get(p.person);
      if (p.person === 'you') {
        this.pulses.push(this.makePulse('you', p.effect, d));
      } else if (target && target.group.visible) {
        this.pulses.push(this.makePulse(p.person, p.effect, d));
      } else {
        // People who aren't in the scene still feel it: a wider, slower ring.
        this.spawnRing(this.pos.x, this.pos.z, p.effect, d + 0.2, 55);
      }
      d += 0.5;
    }
  }

  endRipple(): void {
    this.cineOn = false;
    this.pulses.forEach((p) => this.scene.remove(p.mesh));
    this.pulses.length = 0;
  }

  /** Return to free-roam after a moment: the player keeps their spot and their preferred POV. */
  resumeExplore(): void {
    this.phase = 'explore';
    this.cineOn = false;
    this.currentMoment = null;
    this.setPov(this.userPov, false);
    this.camHeading = this.playerHeading;
    this.camPitch = 0;
    this.vel.set(0, 0);
    this.setSpeaker(null);
  }

  /** Teleport next to a moment's beacon (accessibility / time-pressed roadshow players). */
  fastTravel(index: number): void {
    const stage = this.stages[index];
    if (!stage) return;
    const info = this.world.landmarks[stage.landmark];
    const dirX = Math.sin(info.heading);
    const dirZ = Math.cos(info.heading);
    this.pos.set(info.stand.x + dirX * 3.2, 0, info.stand.z + dirZ * 3.2);
    this.playerHeading = info.heading + Math.PI;
    this.camHeading = this.playerHeading;
    this.reachFired = false;
  }

  /** Bring every character together around the pool for the finale. */
  enterFinale(moods: Record<string, RippleEffect | null>): void {
    this.phase = 'finale';
    this.cineOn = true;
    this.chatPhones.visible = true;
    this.setSpeaker(null);
    this.world.setTimeOfDay(1);
    this.world.beacons.forEach((_, i) => this.world.setBeacon(i, 'hidden'));
    const ids = ['kai', 'jay', 'ryan', 'dev', 'mum', 'teacher'];
    const R = 8.5;
    const n = ids.length + 1;
    // player at the south point facing the pool
    const startA = Math.PI / 2;
    this.pos.set(Math.cos(startA) * R, 0, Math.sin(startA) * R);
    this.playerHeading = Math.atan2(-this.pos.x, -this.pos.z);
    this.player.setPosition(this.pos.x, this.pos.z);
    this.player.setHeading(this.playerHeading);
    this.player.setMood(moods['you'] ?? null);
    this.player.setPose('stand');
    ids.forEach((id, i) => {
      const c = this.cast.get(id);
      if (!c) return;
      const a = startA + ((i + 1) / n) * Math.PI * 2;
      c.setPosition(Math.cos(a) * R, Math.sin(a) * R);
      c.faceTowards(0, 0);
      c.group.visible = true;
      c.setPose('stand');
      c.setGaze(new THREE.Vector3(0, 1.7, 0));
      c.setMood(moods[id] ?? null);
      c.setSpeaking(false);
    });
    this.chatPhones.position.set(Math.cos(startA + Math.PI) * (R + 0.5), 0, Math.sin(startA + Math.PI) * (R + 0.5));
    this.chatPhones.userData['mood'] = moods['chat'] ?? null;
    this.updateChatPhoneColor(moods['chat'] ?? null);
    this.orbitCenter.set(0, 2.2, 0);
    this.orbitDist = 27;
    this.orbitHeight = 9.5;
    this.orbitSpeed = this.reduceMotion ? 0 : 0.09;
    this.orbitAngle = Math.PI / 2 + 0.4;
    this.spawnRing(0, 0, 'steady', 0, 40);
  }

  /** Start over for the next player. Keeps the renderer, textures and world. */
  reset(): void {
    this.endRipple();
    this.rings.forEach((r) => this.scene.remove(r.mesh));
    this.rings.length = 0;
    this.phase = 'title';
    this.currentMoment = null;
    this.activeIndex = null;
    this.arrive = null;
    this.pos.copy(PLAYER_START);
    this.vel.set(0, 0);
    this.playerHeading = Math.PI;
    this.camHeading = Math.PI;
    this.camPitch = 0;
    this.userPov = 'third';
    this.povBlend = 0;
    this.povTarget = 0;
    this.zoom = 6.2;
    this.cast.forEach((c) => {
      c.setMood(null);
      c.setPose('stand');
      c.setGaze(null);
      c.setSpeaking(false);
      c.group.visible = false;
    });
    this.player.setMood(null);
    this.player.setPose('stand');
    this.chatPhones.visible = false;
    this.world.beacons.forEach((_, i) => this.world.setBeacon(i, 'hidden'));
    this.world.setTimeOfDay(0);
    this.keys.clear();
    this.applyPhaseCamera();
  }

  getPlayerHeading(): number {
    return this.camHeading;
  }

  /** Test/diagnostic hook: camera pose and player state. */
  debugState(): Record<string, unknown> {
    return {
      phase: this.phase,
      pov: this.getPov(),
      povBlend: Number(this.povBlend.toFixed(2)),
      pos: [Number(this.pos.x.toFixed(1)), Number(this.pos.z.toFixed(1))],
      cam: this.camera.position.toArray().map((v) => Number(v.toFixed(1))),
      speaker: this.speakerId,
      lowGfx: this.lowGfx,
      draw: this.renderer.info.render.calls,
      tris: this.renderer.info.render.triangles,
    };
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf.id);
    this.ro.disconnect();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    const el = this.renderer.domElement;
    el.removeEventListener('pointerdown', this.onPointerDown);
    el.removeEventListener('pointermove', this.onPointerMove);
    el.removeEventListener('pointerup', this.onPointerUp);
    el.removeEventListener('pointercancel', this.onPointerUp);
    el.removeEventListener('wheel', this.onWheel);
    this.world.dispose();
    this.ringGeo.dispose();
    this.ringMats.forEach((m) => m.dispose());
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    el.remove();
  }

  /* ------------------------------------------------------------------ */
  /* Setup helpers                                                       */
  /* ------------------------------------------------------------------ */

  private buildAmbient(): void {
    const cfg = [
      { r: 17, s: 0.055, a: 0.4, d: 1 },
      { r: 19, s: 0.045, a: 2.2, d: -1 },
      { r: 22, s: 0.05, a: 3.6, d: 1 },
      { r: 24, s: 0.04, a: 5.2, d: -1 },
      { r: 26, s: 0.05, a: 1.2, d: 1 },
      { r: 21, s: 0.035, a: 4.4, d: 1 },
      { r: 15, s: 0.05, a: 5.9, d: -1 },
      { r: 27, s: 0.042, a: 2.9, d: -1 },
    ];
    cfg.forEach((w, i) => {
      const c = new Character(ambientLook(i));
      this.scene.add(c.group);
      this.walkers.push({ c, radius: w.r, speed: w.s, angle: w.a, dir: w.d });
    });
  }

  private buildChatPhones(): void {
    const m = new THREE.MeshStandardMaterial({ color: 0x1e1b4b, emissive: 0x67e8f9, emissiveIntensity: 0.9, roughness: 0.3 });
    for (let i = 0; i < 3; i += 1) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.9, 0.06), m.clone());
      p.position.set((i - 1) * 0.7, 1.4 + (i % 2) * 0.35, 0);
      p.rotation.y = (i - 1) * 0.3;
      p.name = 'phone';
      this.chatPhones.add(p);
    }
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(0.5, 0.035, 8, 28),
      new THREE.MeshBasicMaterial({ color: 0x2dd4bf, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending }),
    );
    halo.rotation.x = Math.PI / 2;
    halo.position.y = 2.5;
    halo.name = 'halo';
    this.chatPhones.add(halo);
  }

  private updateChatPhoneColor(mood: RippleEffect | null): void {
    const col = mood ? MOOD_COLORS[mood] : 0x67e8f9;
    this.chatPhones.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      if (o.name === 'halo') {
        const hm = mesh.material as THREE.MeshBasicMaterial;
        hm.color.setHex(col);
        hm.opacity = mood ? 0.9 : 0;
      } else {
        (mesh.material as THREE.MeshStandardMaterial).emissive.setHex(col);
      }
    });
  }

  private stageNpcs(index: number): void {
    const stage = this.stages[index];
    if (!stage) return;
    const info = this.world.landmarks[stage.landmark];
    stage.npcs.forEach((id, i) => {
      const c = this.cast.get(id);
      const slot = info.slots[i];
      if (!c || !slot) return;
      c.group.visible = true;
      c.setPosition(slot.pos.x, slot.pos.z);
      c.setHeading(info.heading);
      c.setPose(slot.pose);
      c.setMood(null);
      c.setMoving(0);
    });
  }

  private spawnRing(x: number, z: number, effect: RippleEffect, delay: number, maxScale: number): void {
    const base = this.ringMats.get(effect);
    if (!base) return;
    const mesh = new THREE.Mesh(this.ringGeo, base.clone());
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, 0.12, z);
    mesh.scale.setScalar(0.01);
    mesh.visible = false;
    this.scene.add(mesh);
    this.rings.push({ mesh, age: -delay, life: 2.6, maxScale, delay });
  }

  private makePulse(target: string, effect: RippleEffect, delay: number): Pulse {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.26, 12, 10),
      new THREE.MeshBasicMaterial({ color: MOOD_COLORS[effect], transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    const glow = glowSprite(MOOD_COLORS[effect], 2.2, 0.9);
    mesh.add(glow);
    mesh.visible = false;
    this.scene.add(mesh);
    return { mesh, target, effect, t: -delay, delay, done: false };
  }

  private applyPhaseCamera(): void {
    if (this.phase === 'title') {
      this.cineOn = true;
      this.orbitCenter.set(0, 2.4, 0);
      this.orbitDist = 27.5;
      this.orbitHeight = 10;
      this.orbitSpeed = this.reduceMotion ? 0 : 0.045;
      this.orbitAngle = 0.4;
      this.povTarget = 0;
    }
  }

  private resize(): void {
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  /* ------------------------------------------------------------------ */
  /* Input                                                               */
  /* ------------------------------------------------------------------ */

  private static isTyping(t: EventTarget | null): boolean {
    if (!(t instanceof HTMLElement)) return false;
    return t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable;
  }

  private readonly onKeyDown = (e: KeyboardEvent): void => {
    if (RippleEngine.isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.key.toLowerCase();
    if (k === 'v') {
      this.togglePov();
      return;
    }
    if (['w', 'a', 's', 'd', 'q', 'e', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'shift'].includes(k)) {
      if (!this.inputLocked) {
        this.keys.add(k);
        if (k.startsWith('arrow')) e.preventDefault();
      }
    }
  };

  private readonly onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.key.toLowerCase());
  };

  private readonly onBlur = (): void => {
    this.keys.clear();
    this.dragging = false;
  };

  private readonly onPointerDown = (e: PointerEvent): void => {
    this.dragging = true;
    this.lastPointer = { x: e.clientX, y: e.clientY };
    try {
      (e.target as Element).setPointerCapture(e.pointerId);
    } catch {
      /* not fatal: drag still works while the pointer stays over the canvas */
    }
  };

  private readonly onPointerMove = (e: PointerEvent): void => {
    if (!this.dragging) return;
    this.lookDx += e.clientX - this.lastPointer.x;
    this.lookDy += e.clientY - this.lastPointer.y;
    this.lastPointer = { x: e.clientX, y: e.clientY };
  };

  private readonly onPointerUp = (): void => {
    this.dragging = false;
  };

  private readonly onWheel = (e: WheelEvent): void => {
    if (this.phase === 'title' || this.phase === 'finale') return;
    e.preventDefault();
    this.zoom = clamp(this.zoom + e.deltaY * 0.005, 3.2, 11);
  };

  /* ------------------------------------------------------------------ */
  /* Frame loop                                                          */
  /* ------------------------------------------------------------------ */

  private readonly loop = (now: number): void => {
    if (this.disposed) return;
    this.raf.id = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.time += dt;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
    this.monitorPerformance(dt);
  };

  private monitorPerformance(dt: number): void {
    if (this.lowGfx) return;
    this.frames += 1;
    this.frameAccum += dt;
    if (this.frames === 120) {
      const avg = this.frameAccum / this.frames;
      // Older roadshow laptops: drop to the cheap path rather than stutter.
      if (avg > 0.036) {
        this.lowGfx = true;
        this.renderer.setPixelRatio(1);
        this.renderer.shadowMap.enabled = false;
        this.world.sun.castShadow = false;
        this.resize();
        this.cb.onLowGfx();
      }
    }
  }

  private update(dt: number): void {
    // ---- look input ----
    const lookScale = this.getPov() === 'first' || this.povBlend > 0.5 ? 0.0032 : 0.0042;
    if (!this.inputLocked || this.phase === 'moment') {
      let kx = 0;
      let ky = 0;
      if (this.keys.has('q')) kx -= 1;
      if (this.keys.has('e')) kx += 1;
      if (this.phase !== 'title' && this.phase !== 'ripple' && this.phase !== 'finale') {
        this.camHeading -= this.lookDx * lookScale + kx * 1.7 * dt;
        this.camPitch = clamp(this.camPitch - this.lookDy * lookScale + ky * dt, -1.15, 1.15);
      }
    }
    this.lookDx = 0;
    this.lookDy = 0;
    if (this.phase === 'moment' || this.phase === 'arriving') {
      // Keep the group in view: you can glance around, not walk off.
      const off = clamp(angleDiff(this.momentFace, this.camHeading), -0.95, 0.95);
      this.camHeading = this.momentFace + off;
    }

    // ---- state machine bits ----
    if (this.phase === 'arriving' && this.arrive) this.updateArrival(dt);
    if (this.phase === 'explore') this.updateMovement(dt);
    else if (this.phase !== 'arriving') this.player.setMoving(0);

    // ---- characters ----
    this.player.setPosition(this.pos.x, this.pos.z);
    this.player.update(dt, this.time, this.reduceMotion);
    const head = this.tmp.set(this.pos.x, 1.7, this.pos.z).clone();
    this.cast.forEach((c) => {
      if (!c.group.visible) return;
      if (this.phase !== 'finale') c.setGaze(head);
      c.update(dt, this.time, this.reduceMotion);
    });
    this.updateWalkers(dt);
    this.updateFx(dt);
    this.chatPhones.children.forEach((c, i) => {
      if (c.name === 'phone') c.position.y = 1.4 + (i % 2) * 0.35 + (this.reduceMotion ? 0 : Math.sin(this.time * 1.4 + i) * 0.08);
      if (c.name === 'halo') c.rotation.z = this.time * 0.8;
    });

    this.world.update(dt, this.time, this.pos, this.reduceMotion);
    this.updateCamera(dt);
    this.updateHud();
  }

  private updateArrival(dt: number): void {
    const a = this.arrive;
    if (!a) return;
    a.t += dt / (this.reduceMotion ? 0.4 : 1.6);
    const k = ease(clamp(a.t, 0, 1));
    this.pos.lerpVectors(a.from, a.to, k);
    this.pos.y = 0;
    const dh = angleDiff(a.fromH, a.toH);
    this.playerHeading = a.fromH + dh * k;
    this.camHeading = this.playerHeading;
    this.camPitch *= 1 - k;
    this.player.setHeading(this.playerHeading);
    this.player.setMoving(a.t < 1 ? 0.7 : 0);
    if (a.t >= 1) {
      this.phase = 'moment';
      this.arrive = null;
      this.player.setMoving(0);
      this.cb.onArrived(a.index);
    }
  }

  private updateMovement(dt: number): void {
    let fwd = 0;
    let strafe = 0;
    if (this.keys.has('w') || this.keys.has('arrowup')) fwd += 1;
    if (this.keys.has('s') || this.keys.has('arrowdown')) fwd -= 1;
    if (this.keys.has('d') || this.keys.has('arrowright')) strafe += 1;
    if (this.keys.has('a') || this.keys.has('arrowleft')) strafe -= 1;
    fwd += this.joy.y;
    strafe += this.joy.x;
    const mag = Math.hypot(fwd, strafe);
    const run = this.keys.has('shift') ? 1.55 : 1;
    let tx = 0;
    let tz = 0;
    if (mag > 0.05 && !this.inputLocked) {
      const n = Math.min(1, mag);
      const fx = Math.sin(this.camHeading);
      const fz = Math.cos(this.camHeading);
      const rx = -fz;
      const rz = fx;
      tx = ((fx * fwd + rx * strafe) / mag) * n * 5.4 * run;
      tz = ((fz * fwd + rz * strafe) / mag) * n * 5.4 * run;
    }
    this.vel.x += (tx - this.vel.x) * damp(11, dt);
    this.vel.y += (tz - this.vel.y) * damp(11, dt);
    const speed = Math.hypot(this.vel.x, this.vel.y);
    this.moveWithCollision(this.vel.x * dt, this.vel.y * dt);
    this.player.setMoving(speed / 5.4);
    if (speed > 0.3) {
      const want = this.getPov() === 'first' && this.povBlend > 0.6 ? this.camHeading : Math.atan2(this.vel.x, this.vel.y);
      this.playerHeading += angleDiff(this.playerHeading, want) * damp(12, dt);
    } else if (this.povBlend > 0.6) {
      this.playerHeading += angleDiff(this.playerHeading, this.camHeading) * damp(10, dt);
    }
    this.player.setHeading(this.playerHeading);

    // Walk into the active moment's ring to start it.
    if (this.activeIndex !== null && !this.reachFired) {
      const stage = this.stages[this.activeIndex];
      if (stage) {
        const info = this.world.landmarks[stage.landmark];
        if (Math.hypot(this.pos.x - info.stand.x, this.pos.z - info.stand.z) < 6.2) {
          this.reachFired = true;
          this.cb.onReachMoment(this.activeIndex);
        }
      }
    }
  }

  private moveWithCollision(dx: number, dz: number): void {
    const pr = 0.5;
    let nx = this.pos.x + dx;
    let nz = this.pos.z + dz;
    for (const c of this.world.colliders) {
      const ddx = nx - c.x;
      const ddz = nz - c.z;
      const min = c.r + pr;
      if (Math.abs(ddx) > min || Math.abs(ddz) > min) continue;
      const d = Math.hypot(ddx, ddz);
      if (d < min && d > 1e-4) {
        nx = c.x + (ddx / d) * min;
        nz = c.z + (ddz / d) * min;
      }
    }
    const r = Math.hypot(nx, nz);
    if (r > WORLD_RADIUS) {
      nx = (nx / r) * WORLD_RADIUS;
      nz = (nz / r) * WORLD_RADIUS;
    }
    this.pos.set(nx, 0, nz);
  }

  private updateWalkers(dt: number): void {
    for (const w of this.walkers) {
      w.angle += w.speed * w.dir * dt * (this.reduceMotion ? 0.6 : 1);
      const x = Math.cos(w.angle) * w.radius;
      const z = Math.sin(w.angle) * w.radius;
      w.c.setPosition(x, z);
      // tangent heading
      const tx = -Math.sin(w.angle) * w.dir;
      const tz = Math.cos(w.angle) * w.dir;
      w.c.setHeading(Math.atan2(tx, tz));
      w.c.setMoving(0.55);
      w.c.update(dt, this.time, this.reduceMotion);
    }
  }

  private updateFx(dt: number): void {
    for (let i = this.rings.length - 1; i >= 0; i -= 1) {
      const r = this.rings[i];
      if (!r) continue;
      r.age += dt;
      if (r.age < 0) continue;
      r.mesh.visible = true;
      const k = clamp(r.age / r.life, 0, 1);
      r.mesh.scale.setScalar(0.4 + (r.maxScale - 0.4) * (1 - Math.pow(1 - k, 2.2)));
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - k) * 0.9;
      if (k >= 1) {
        this.scene.remove(r.mesh);
        (r.mesh.material as THREE.Material).dispose();
        this.rings.splice(i, 1);
      }
    }
    // title / finale: keep gentle rings pulsing from the pool
    if ((this.phase === 'title' || this.phase === 'finale') && !this.reduceMotion && this.rings.length < 3 && Math.sin(this.time * 0.9) > 0.985) {
      this.spawnRing(0, 0, this.phase === 'title' ? 'steady' : 'steady', 0, 34);
    }

    for (let i = this.pulses.length - 1; i >= 0; i -= 1) {
      const p = this.pulses[i];
      if (!p || p.done) continue;
      p.t += dt;
      if (p.t < 0) continue;
      p.mesh.visible = true;
      const k = clamp(p.t / 0.9, 0, 1);
      const to = this.tmp;
      if (p.target === 'you') to.set(this.pos.x, 2.4, this.pos.z);
      else {
        const c = this.cast.get(p.target);
        if (c) to.set(c.group.position.x, 2.2, c.group.position.z);
      }
      const fromX = this.pos.x;
      const fromZ = this.pos.z;
      if (p.target === 'you') {
        p.mesh.position.set(fromX, 2.4 + Math.sin(k * Math.PI) * 1.4, fromZ);
      } else {
        p.mesh.position.set(lerp(fromX, to.x, ease(k)), 1.8 + Math.sin(k * Math.PI) * 1.8, lerp(fromZ, to.z, ease(k)));
      }
      if (k >= 1) {
        p.done = true;
        p.mesh.visible = false;
        this.scene.remove(p.mesh);
        if (p.target === 'you') this.player.setMood(p.effect);
        else {
          const c = this.cast.get(p.target);
          c?.setMood(p.effect);
          if (c) this.spawnRing(c.group.position.x, c.group.position.z, p.effect, 0, 9);
        }
      }
    }
  }

  private updateCamera(dt: number): void {
    this.povBlend += (this.povTarget - this.povBlend) * damp(this.reduceMotion ? 30 : 6.5, dt);
    if (Math.abs(this.povTarget - this.povBlend) < 0.002) this.povBlend = this.povTarget;
    this.cineBlend += ((this.cineOn ? 1 : 0) - this.cineBlend) * damp(this.reduceMotion ? 30 : 3.2, dt);

    const ph = this.pos;
    const headY = 1.64;
    // -- first-person pose --
    const bob = this.reduceMotion ? 0 : Math.sin(this.time * 9) * 0.035 * Math.min(1, Math.hypot(this.vel.x, this.vel.y) / 5);
    const fp = new THREE.Vector3(ph.x + Math.sin(this.camHeading) * 0.12, headY + bob, ph.z + Math.cos(this.camHeading) * 0.12);
    const fdir = new THREE.Vector3(
      Math.sin(this.camHeading) * Math.cos(this.camPitch),
      Math.sin(this.camPitch),
      Math.cos(this.camHeading) * Math.cos(this.camPitch),
    );
    const fLook = fp.clone().addScaledVector(fdir, 10);
    // -- third-person pose --
    const el = clamp(0.3 - this.camPitch * 0.55, 0.05, 1.15);
    const tp = new THREE.Vector3(
      ph.x - Math.sin(this.camHeading) * Math.cos(el) * this.zoom,
      1.9 + Math.sin(el) * this.zoom,
      ph.z - Math.cos(this.camHeading) * Math.cos(el) * this.zoom,
    );
    tp.y = Math.max(tp.y, 0.7);
    const tLook = new THREE.Vector3(ph.x, 1.55, ph.z);
    // Pull the follow camera in if it would end up inside a tree canopy.
    let clear = 1;
    for (; clear > 0.3; clear -= 0.1) {
      const px = tLook.x + (tp.x - tLook.x) * clear;
      const py = tLook.y + (tp.y - tLook.y) * clear;
      const pz = tLook.z + (tp.z - tLook.z) * clear;
      const hit = this.world.canopies.some((c) => py > c.yMin - 0.4 && py < c.yMax + 0.4 && Math.hypot(px - c.x, pz - c.z) < c.r + 0.6);
      if (!hit) break;
    }
    this.camClear = clear < this.camClear ? clear : this.camClear + (clear - this.camClear) * damp(5, dt);
    tp.lerpVectors(tLook, tp, this.camClear);
    const b = ease(this.povBlend);
    const pos = tp.clone().lerp(fp, b);
    const look = tLook.clone().lerp(fLook, b);

    // -- cinematic orbit --
    if (this.cineBlend > 0.002) {
      this.orbitAngle += this.orbitSpeed * dt;
      const c = new THREE.Vector3(
        this.orbitCenter.x + Math.sin(this.orbitAngle) * this.orbitDist,
        this.orbitHeight,
        this.orbitCenter.z + Math.cos(this.orbitAngle) * this.orbitDist,
      );
      const cb = ease(clamp(this.cineBlend, 0, 1));
      pos.lerp(c, cb);
      look.lerp(this.orbitCenter, cb);
    }
    this.camera.position.copy(pos);
    this.camera.lookAt(look);

    // FOV: tighter in a high-pressure moment, wider when walking.
    const stage = this.currentMoment !== null ? this.stages[this.currentMoment] : undefined;
    let targetFov = lerp(62, 74, b);
    if (this.phase === 'moment' && stage && this.povBlend > 0.7 && !this.reduceMotion) targetFov -= stage.pressure * 2.6;
    if (this.cineBlend > 0.5) targetFov = 52;
    this.fov += (targetFov - this.fov) * damp(4, dt);
    if (Math.abs(this.camera.fov - this.fov) > 0.05) {
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
    }
    // Hide your own body in first person so it never blocks the view.
    this.player.group.visible = !(this.povBlend > 0.82 && this.cineBlend < 0.3);
  }

  private updateHud(): void {
    this.hudTick += 1;
    if (this.hudTick % 6 !== 0) return;
    if (this.phase !== 'explore' || this.activeIndex === null) {
      this.cb.onHud({ index: null, distance: 0, bearing: 0 });
      return;
    }
    const stage = this.stages[this.activeIndex];
    if (!stage) return;
    const info: LandmarkInfo = this.world.landmarks[stage.landmark];
    const dx = info.npc.x - this.pos.x;
    const dz = info.npc.z - this.pos.z;
    const want = Math.atan2(dx, dz);
    // + = to the right of where the camera is facing (camera right is decreasing heading)
    const bearing = -angleDiff(this.camHeading, want);
    this.cb.onHud({ index: this.activeIndex, distance: Math.hypot(dx, dz), bearing });
  }
}
