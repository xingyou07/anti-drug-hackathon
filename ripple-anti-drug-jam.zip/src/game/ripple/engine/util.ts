import * as THREE from 'three';

/** Deterministic PRNG so the world (and any screenshot test of it) is identical every run. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const clamp = (v: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, v));
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
/** Frame-rate independent exponential smoothing factor. */
export const damp = (rate: number, dt: number): number => 1 - Math.exp(-rate * dt);

export function angleDiff(a: number, b: number): number {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export function makeCanvas(w: number, h: number): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('2D canvas unavailable');
  return { canvas, ctx };
}

export function canvasTexture(canvas: HTMLCanvasElement, repeat = false): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
  }
  return tex;
}

const matCache = new Map<string, THREE.MeshStandardMaterial>();

/** Shared materials keep the draw-call and GPU-state count low. */
export function mat(
  color: number,
  opts: { emissive?: number; emissiveIntensity?: number; roughness?: number; metalness?: number; transparent?: boolean; opacity?: number } = {},
): THREE.MeshStandardMaterial {
  const key = `${color}|${opts.emissive ?? ''}|${opts.emissiveIntensity ?? ''}|${opts.roughness ?? ''}|${opts.metalness ?? ''}|${opts.opacity ?? ''}`;
  const cached = matCache.get(key);
  if (cached) return cached;
  const m = new THREE.MeshStandardMaterial({
    color,
    roughness: opts.roughness ?? 0.78,
    metalness: opts.metalness ?? 0.02,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 1,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
  });
  matCache.set(key, m);
  return m;
}

export function disposeMaterialCache(): void {
  matCache.forEach((m) => m.dispose());
  matCache.clear();
}

export function box(
  w: number,
  h: number,
  d: number,
  material: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  shadow = false,
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  m.castShadow = shadow;
  m.receiveShadow = true;
  return m;
}

export function cyl(
  rTop: number,
  rBot: number,
  h: number,
  material: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  seg = 12,
  shadow = false,
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, h, seg), material);
  m.position.set(x, y, z);
  m.castShadow = shadow;
  m.receiveShadow = true;
  return m;
}

export function sphere(r: number, material: THREE.Material, x = 0, y = 0, z = 0, seg = 14): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, seg, Math.max(6, Math.floor(seg * 0.7))), material);
  m.position.set(x, y, z);
  return m;
}

let glowTex: THREE.CanvasTexture | null = null;
/** Soft radial glow used for lamps, beacons and fireflies. */
export function glowTexture(): THREE.CanvasTexture {
  if (glowTex) return glowTex;
  const { canvas, ctx } = makeCanvas(128, 128);
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  glowTex = canvasTexture(canvas);
  return glowTex;
}

export function glowSprite(color: number, size: number, opacity = 0.8): THREE.Sprite {
  const s = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture(),
      color,
      transparent: true,
      opacity,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
    }),
  );
  s.scale.set(size, size, 1);
  return s;
}

/** A crisp text plate (shop signs, moment labels). Text is drawn to canvas so no font files are needed. */
export function textSprite(
  text: string,
  opts: { sub?: string; color?: string; bg?: string; width?: number; scale?: number } = {},
): THREE.Sprite {
  const w = opts.width ?? 512;
  const h = opts.sub ? 200 : 140;
  const { canvas, ctx } = makeCanvas(w, h);
  const r = 34;
  ctx.beginPath();
  ctx.moveTo(r, 6);
  ctx.lineTo(w - r, 6);
  ctx.quadraticCurveTo(w - 6, 6, w - 6, r);
  ctx.lineTo(w - 6, h - r);
  ctx.quadraticCurveTo(w - 6, h - 6, w - r, h - 6);
  ctx.lineTo(r, h - 6);
  ctx.quadraticCurveTo(6, h - 6, 6, h - r);
  ctx.lineTo(6, r);
  ctx.quadraticCurveTo(6, 6, r, 6);
  ctx.closePath();
  ctx.fillStyle = opts.bg ?? 'rgba(20,10,50,0.82)';
  ctx.fill();
  ctx.lineWidth = 6;
  ctx.strokeStyle = opts.color ?? '#ffffff';
  ctx.stroke();
  ctx.fillStyle = opts.color ?? '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold 64px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  ctx.fillText(text, w / 2, opts.sub ? h * 0.36 : h / 2);
  if (opts.sub) {
    ctx.font = '600 38px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillText(opts.sub, w / 2, h * 0.75);
  }
  const s = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: canvasTexture(canvas), transparent: true, depthWrite: false, fog: false }),
  );
  const sc = opts.scale ?? 1;
  s.scale.set((w / 100) * sc, (h / 100) * sc, 1);
  return s;
}

export function disposeObject(root: THREE.Object3D): void {
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const m = mesh.material as THREE.Material | THREE.Material[] | undefined;
    if (!m) return;
    const list = Array.isArray(m) ? m : [m];
    for (const mm of list) {
      const anyMap = mm as THREE.Material & { map?: THREE.Texture | null; emissiveMap?: THREE.Texture | null };
      if (anyMap.map && anyMap.map !== glowTex) anyMap.map.dispose();
      if (anyMap.emissiveMap) anyMap.emissiveMap.dispose();
      mm.dispose();
    }
  });
}
