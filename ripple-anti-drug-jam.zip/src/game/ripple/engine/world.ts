import * as THREE from 'three';
import type { RippleLandmark } from '@/content/types';
import {
  box,
  canvasTexture,
  cyl,
  glowSprite,
  makeCanvas,
  mat,
  mulberry32,
  sphere,
  textSprite,
} from './util';

/** Circle colliders are enough for a walkable estate and stay cheap to test. */
export interface Collider {
  x: number;
  z: number;
  r: number;
}

export interface LandmarkInfo {
  id: RippleLandmark;
  /** World position of the landmark origin (front faces the plaza). */
  origin: THREE.Vector3;
  heading: number;
  /** Where the NPC group stands and where the player stands to talk to them. */
  npc: THREE.Vector3;
  stand: THREE.Vector3;
  /** One entry per NPC in the moment's `npcs` order: where they stand/sit and their pose. */
  slots: Array<{ pos: THREE.Vector3; pose: 'stand' | 'sit' | 'slump' }>;
  color: number;
  /** World-space face direction for NPCs (toward the player's stand mark). */
  faceHeading: number;
}

export const WORLD_RADIUS = 66;
const RING = 40;

const LAYOUT: Array<{ id: RippleLandmark; x: number; z: number; color: number }> = [
  { id: 'void-deck', x: 0, z: -RING, color: 0xff7eb6 },
  { id: 'hawker', x: RING * 0.866, z: -RING * 0.5, color: 0xfbbf24 },
  { id: 'mrt', x: RING * 0.866, z: RING * 0.5, color: 0x38bdf8 },
  { id: 'library', x: 0, z: RING, color: 0xa78bfa },
  { id: 'kopitiam', x: -RING * 0.866, z: RING * 0.5, color: 0x34d399 },
  { id: 'playground', x: -RING * 0.866, z: -RING * 0.5, color: 0xfb923c },
];

type Slot = { x: number; z: number; pose: 'stand' | 'sit' | 'slump' };

/** Local (landmark-relative) staging. +Z points toward the plaza, i.e. toward the player. */
const STAGING: Record<RippleLandmark, { npc: { x: number; z: number }; slots: Slot[] }> = {
  'void-deck': { npc: { x: 0, z: -6.5 }, slots: [{ x: -1.3, z: -6.5, pose: 'stand' }, { x: 1.3, z: -6.5, pose: 'stand' }] },
  hawker: { npc: { x: -2.5, z: -2.6 }, slots: [{ x: -2.5, z: -2.6, pose: 'stand' }] },
  mrt: { npc: { x: 0, z: 3 }, slots: [{ x: 0, z: 3, pose: 'stand' }] },
  library: { npc: { x: -3.2, z: 4.7 }, slots: [{ x: -3.2, z: 4.7, pose: 'sit' }] },
  kopitiam: { npc: { x: 1.9, z: 3.2 }, slots: [{ x: 1.9, z: 3.2, pose: 'sit' }] },
  playground: { npc: { x: 0, z: 2.2 }, slots: [{ x: 1.3, z: 2.9, pose: 'stand' }, { x: -1.5, z: 1.5, pose: 'slump' }] },
};

/* ---------- textures ---------- */

function facadeTextures(base: string, accent: string, seed: number): { map: THREE.CanvasTexture; glow: THREE.CanvasTexture } {
  const rnd = mulberry32(seed);
  const S = 256;
  const a = makeCanvas(S, S);
  const b = makeCanvas(S, S);
  a.ctx.fillStyle = base;
  a.ctx.fillRect(0, 0, S, S);
  b.ctx.fillStyle = '#000';
  b.ctx.fillRect(0, 0, S, S);
  const cols = 8;
  const rows = 8;
  const cw = S / cols;
  const rh = S / rows;
  for (let r = 0; r < rows; r += 1) {
    // floor slab line + balcony band
    a.ctx.fillStyle = accent;
    a.ctx.fillRect(0, r * rh + rh - 7, S, 7);
    a.ctx.fillStyle = 'rgba(255,255,255,0.28)';
    a.ctx.fillRect(0, r * rh + rh - 11, S, 3);
    for (let c = 0; c < cols; c += 1) {
      const x = c * cw + 6;
      const y = r * rh + 7;
      const w = cw - 12;
      const h = rh - 20;
      a.ctx.fillStyle = '#1a1140';
      a.ctx.fillRect(x, y, w, h);
      const lit = rnd() < 0.5;
      if (lit) {
        const warm = ['#ffd77a', '#ffe9b0', '#ffb86b', '#fff2c9'][Math.floor(rnd() * 4)] ?? '#ffd77a';
        a.ctx.fillStyle = warm;
        a.ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
        b.ctx.fillStyle = warm;
        b.ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
      } else {
        a.ctx.fillStyle = 'rgba(120,150,255,0.35)';
        a.ctx.fillRect(x + 2, y + 2, w - 4, (h - 4) * 0.45);
      }
      // window bar
      a.ctx.fillStyle = 'rgba(30,20,70,0.6)';
      a.ctx.fillRect(x + w / 2 - 1, y, 2, h);
    }
  }
  return { map: canvasTexture(a.canvas, true), glow: canvasTexture(b.canvas, true) };
}

function groundTexture(): THREE.CanvasTexture {
  const S = 2048;
  const { canvas, ctx } = makeCanvas(S, S);
  const c = S / 2;
  ctx.fillStyle = '#5a4a8f';
  ctx.fillRect(0, 0, S, S);
  const scale = S / 2 / 84; // px per world unit (disc radius 84)

  // concentric tile rings
  const ringCols = ['#ff7eb6', '#fbbf24', '#2dd4bf', '#a78bfa', '#fb923c'];
  for (let r = 6; r < 78; r += 4.5) {
    ctx.beginPath();
    ctx.arc(c, c, r * scale, 0, Math.PI * 2);
    ctx.lineWidth = 1.1 * scale;
    ctx.strokeStyle = `${ringCols[Math.floor(r / 4.5) % ringCols.length] ?? '#fff'}55`;
    ctx.stroke();
  }
  // checker tiles in a wide band
  for (let i = 0; i < 360; i += 3) {
    const ang = (i * Math.PI) / 180;
    for (let r = 12; r < 32; r += 2.2) {
      if (((i / 3 + Math.floor(r / 2.2)) & 1) === 0) continue;
      ctx.fillStyle = 'rgba(255,255,255,0.05)';
      ctx.beginPath();
      ctx.arc(c + Math.cos(ang) * r * scale, c + Math.sin(ang) * r * scale, 1.0 * scale, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  // spokes to each landmark
  for (const l of LAYOUT) {
    const ang = Math.atan2(l.z, l.x);
    ctx.save();
    ctx.translate(c, c);
    ctx.rotate(ang);
    const hex = `#${l.color.toString(16).padStart(6, '0')}`;
    const g = ctx.createLinearGradient(0, 0, 44 * scale, 0);
    g.addColorStop(0, '#f6ecff');
    g.addColorStop(1, hex);
    ctx.fillStyle = g;
    ctx.fillRect(6 * scale, -3.2 * scale, 38 * scale, 6.4 * scale);
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    for (let d = 8; d < 40; d += 2.6) ctx.fillRect(d * scale, -0.12 * scale, 1.2 * scale, 0.24 * scale);
    ctx.restore();
  }
  // plaza disc
  ctx.beginPath();
  ctx.arc(c, c, 13 * scale, 0, Math.PI * 2);
  ctx.fillStyle = '#efe4ff';
  ctx.fill();
  const spokes = 24;
  for (let i = 0; i < spokes; i += 1) {
    const a0 = (i / spokes) * Math.PI * 2;
    const a1 = ((i + 1) / spokes) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(c, c);
    ctx.arc(c, c, 13 * scale, a0, a1);
    ctx.closePath();
    ctx.fillStyle = i % 2 ? '#ffd1e8' : '#c7f9ee';
    ctx.globalAlpha = 0.65;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  ctx.beginPath();
  ctx.arc(c, c, 13 * scale, 0, Math.PI * 2);
  ctx.lineWidth = 0.7 * scale;
  ctx.strokeStyle = '#7c3aed';
  ctx.stroke();

  const tex = canvasTexture(canvas);
  tex.anisotropy = 8;
  return tex;
}

function beamTexture(): THREE.CanvasTexture {
  const { canvas, ctx } = makeCanvas(8, 256);
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, 'rgba(255,255,255,0)');
  g.addColorStop(0.55, 'rgba(255,255,255,0.35)');
  g.addColorStop(1, 'rgba(255,255,255,1)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 8, 256);
  return canvasTexture(canvas);
}

/** Box whose UVs are in world units, so facades keep a constant window size on any block. */
function tiledBox(w: number, h: number, d: number, tile: number): THREE.BoxGeometry {
  const g = new THREE.BoxGeometry(w, h, d);
  const pos = g.getAttribute('position');
  const nor = g.getAttribute('normal');
  const uv = g.getAttribute('uv');
  for (let i = 0; i < pos.count; i += 1) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const nx = Math.abs(nor.getX(i));
    const ny = Math.abs(nor.getY(i));
    if (nx > 0.5) uv.setXY(i, z / tile, y / tile);
    else if (ny > 0.5) uv.setXY(i, x / tile, z / tile);
    else uv.setXY(i, x / tile, y / tile);
  }
  uv.needsUpdate = true;
  return g;
}

/* ---------- world ---------- */

export interface Beacon {
  group: THREE.Group;
  beam: THREE.Mesh;
  ring: THREE.Mesh;
  label: THREE.Sprite;
  glow: THREE.Sprite;
  color: number;
  state: 'hidden' | 'active' | 'done';
}

interface TodPalette {
  top: number;
  mid: number;
  horizon: number;
  fog: number;
  hemiSky: number;
  hemiGround: number;
  hemiInt: number;
  sun: number;
  sunInt: number;
  window: number;
  lamp: number;
  stars: number;
}

const DUSK: TodPalette = {
  top: 0x3b2a8c, mid: 0xff6b9e, horizon: 0xffb36b, fog: 0xf7a072,
  hemiSky: 0xffd0a8, hemiGround: 0x6a4a9c, hemiInt: 1.05,
  sun: 0xffb070, sunInt: 2.6, window: 0.22, lamp: 0.35, stars: 0,
};
const NIGHT: TodPalette = {
  top: 0x090433, mid: 0x3a1f7a, horizon: 0xb04fc0, fog: 0x2a1858,
  hemiSky: 0x8a86ff, hemiGround: 0x241650, hemiInt: 1.0,
  sun: 0x9cbcff, sunInt: 0.85, window: 1.35, lamp: 1.7, stars: 1,
};

export class World {
  readonly scene: THREE.Scene;
  readonly colliders: Collider[] = [];
  /** Tree canopy volumes, so the follow camera can pull in instead of clipping through leaves. */
  readonly canopies: Array<{ x: number; z: number; r: number; yMin: number; yMax: number }> = [];
  readonly landmarks: Record<RippleLandmark, LandmarkInfo>;
  readonly beacons: Beacon[] = [];
  readonly sun: THREE.DirectionalLight;
  /** Ambient-walk loop points, world space. */
  readonly walkRadius = 24;

  private readonly skyMat: THREE.ShaderMaterial;
  private readonly hemi: THREE.HemisphereLight;
  private readonly fog: THREE.Fog;
  private readonly stars: THREE.Points;
  private readonly moon: THREE.Sprite;
  private readonly windowMats: THREE.MeshStandardMaterial[] = [];
  private readonly lampMats: THREE.MeshBasicMaterial[] = [];
  private readonly lampGlows: THREE.Sprite[] = [];
  private readonly lampLights: THREE.PointLight[] = [];
  private readonly neon: Array<{ mat: THREE.MeshStandardMaterial; base: number }> = [];
  private readonly fireflies: THREE.Points;
  private readonly fireflyBase: Float32Array;
  private readonly poolRings: THREE.Mesh[] = [];
  private readonly beamTex = beamTexture();
  private readonly tmpColor = new THREE.Color();
  private readonly rnd = mulberry32(20260919);
  private readonly movable: THREE.Object3D[] = [];
  private tod = 0;

  constructor(scene: THREE.Scene, opts: { lowGfx: boolean }) {
    this.scene = scene;
    this.fog = new THREE.Fog(DUSK.fog, 55, 260);
    scene.fog = this.fog;

    // Sky dome
    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        top: { value: new THREE.Color(DUSK.top) },
        mid: { value: new THREE.Color(DUSK.mid) },
        horizon: { value: new THREE.Color(DUSK.horizon) },
      },
      vertexShader: `varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
      fragmentShader: `uniform vec3 top; uniform vec3 mid; uniform vec3 horizon; varying vec3 vP;
        void main(){ float h = clamp(vP.y,0.0,1.0);
          vec3 c = mix(horizon, mid, smoothstep(0.0,0.35,h));
          c = mix(c, top, smoothstep(0.25,0.9,h));
          gl_FragColor = vec4(c,1.0); }`,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(320, 24, 16), this.skyMat);
    sky.renderOrder = -10;
    scene.add(sky);

    // Stars + moon
    const starPos: number[] = [];
    for (let i = 0; i < 380; i += 1) {
      const u = this.rnd() * Math.PI * 2;
      const v = Math.acos(0.15 + this.rnd() * 0.85);
      starPos.push(Math.sin(v) * Math.cos(u) * 300, Math.cos(v) * 300, Math.sin(v) * Math.sin(u) * 300);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false }),
    );
    scene.add(this.stars);
    this.moon = glowSprite(0xdde8ff, 46, 0);
    this.moon.position.set(120, 170, -190);
    scene.add(this.moon);
    const sunDisc = glowSprite(0xffb36b, 130, 0.8);
    sunDisc.position.set(-230, 40, 170);
    scene.add(sunDisc);
    this.movable.push(sunDisc);

    // Lights
    this.hemi = new THREE.HemisphereLight(DUSK.hemiSky, DUSK.hemiGround, DUSK.hemiInt);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(DUSK.sun, DUSK.sunInt);
    this.sun.position.set(-40, 26, 30);
    this.sun.castShadow = !opts.lowGfx;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.near = 5;
    sc.far = 160;
    sc.left = -38;
    sc.right = 38;
    sc.top = 38;
    sc.bottom = -38;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.05;
    scene.add(this.sun);
    scene.add(this.sun.target);

    this.buildGround();
    this.buildSkyline();
    this.landmarks = this.buildLandmarks();
    this.buildPool();
    this.buildTrees();
    this.buildLamps();
    this.buildBunting();
    this.buildBeacons();
    this.fireflyBase = new Float32Array(150 * 3);
    this.fireflies = this.buildFireflies();
    this.setTimeOfDay(0);
  }

  /* --- ground --- */

  private buildGround(): void {
    const grass = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), mat(0x2a9d6f, { roughness: 1 }));
    grass.rotation.x = -Math.PI / 2;
    grass.position.y = -0.05;
    grass.receiveShadow = true;
    this.scene.add(grass);

    const disc = new THREE.Mesh(
      new THREE.CircleGeometry(84, 72),
      new THREE.MeshStandardMaterial({ map: groundTexture(), roughness: 0.92, metalness: 0 }),
    );
    disc.rotation.x = -Math.PI / 2;
    disc.rotation.z = Math.PI / 2;
    disc.receiveShadow = true;
    this.scene.add(disc);
  }

  /* --- skyline of HDB-style blocks --- */

  private facadeMat(base: string, accent: string, seed: number): THREE.MeshStandardMaterial {
    const t = facadeTextures(base, accent, seed);
    const m = new THREE.MeshStandardMaterial({ map: t.map, emissiveMap: t.glow, emissive: 0xffffff, emissiveIntensity: DUSK.window, roughness: 0.85 });
    this.windowMats.push(m);
    return m;
  }

  private buildSkyline(): void {
    const palette: Array<[string, string]> = [
      ['#ffb4a2', '#ff7f6e'],
      ['#a7f3d0', '#34d399'],
      ['#bae6fd', '#38bdf8'],
      ['#ddd6fe', '#a78bfa'],
      ['#fde68a', '#fbbf24'],
      ['#fbcfe8', '#f472b6'],
    ];
    const mats = palette.map(([b, a], i) => this.facadeMat(b, a, 100 + i));
    const rnd = mulberry32(77);
    const count = 18;
    for (let i = 0; i < count; i += 1) {
      const ang = (i / count) * Math.PI * 2 + rnd() * 0.15;
      const r = 92 + rnd() * 34;
      const w = 24 + rnd() * 20;
      const h = 34 + rnd() * 44;
      const d = 11 + rnd() * 3;
      const m = mats[i % mats.length];
      if (!m) continue;
      const b = new THREE.Mesh(tiledBox(w, h, d, 24), m);
      b.position.set(Math.cos(ang) * r, h / 2, Math.sin(ang) * r);
      b.rotation.y = -ang + Math.PI / 2 + (rnd() - 0.5) * 0.4;
      this.scene.add(b);
      const core = box(4.4, h + 3, d + 1.6, mat(0xf5ecff), b.position.x, (h + 3) / 2, b.position.z);
      core.rotation.y = b.rotation.y;
      this.scene.add(core);
    }
  }

  /* --- landmarks --- */

  private toWorld(origin: THREE.Vector3, h: number, lx: number, lz: number): THREE.Vector3 {
    return new THREE.Vector3(
      origin.x + lx * Math.cos(h) + lz * Math.sin(h),
      0,
      origin.z - lx * Math.sin(h) + lz * Math.cos(h),
    );
  }

  private addRectCollider(origin: THREE.Vector3, h: number, cx: number, cz: number, w: number, d: number): void {
    const r = Math.min(w, d) / 2;
    const long = Math.max(w, d);
    const n = Math.max(1, Math.ceil(long / (r * 1.4)));
    for (let i = 0; i < n; i += 1) {
      const t = n === 1 ? 0 : (i / (n - 1) - 0.5) * (long - 2 * r);
      const p = w >= d ? this.toWorld(origin, h, cx + t, cz) : this.toWorld(origin, h, cx, cz + t);
      this.colliders.push({ x: p.x, z: p.z, r });
    }
  }

  private buildLandmarks(): Record<RippleLandmark, LandmarkInfo> {
    const out = {} as Record<RippleLandmark, LandmarkInfo>;
    for (const l of LAYOUT) {
      const origin = new THREE.Vector3(l.x, 0, l.z);
      const heading = Math.atan2(-l.x, -l.z);
      const g = new THREE.Group();
      g.position.copy(origin);
      g.rotation.y = heading;
      this.scene.add(g);

      switch (l.id) {
        case 'void-deck': this.buildVoidDeck(g, origin, heading); break;
        case 'hawker': this.buildHawker(g, origin, heading); break;
        case 'mrt': this.buildMrt(g, origin, heading); break;
        case 'library': this.buildLibrary(g, origin, heading); break;
        case 'kopitiam': this.buildKopitiam(g, origin, heading); break;
        case 'playground': this.buildPlayground(g, origin, heading); break;
      }
      const st = STAGING[l.id];
      out[l.id] = {
        id: l.id,
        origin,
        heading,
        npc: this.toWorld(origin, heading, st.npc.x, st.npc.z),
        stand: this.toWorld(origin, heading, st.npc.x, st.npc.z + 3.6),
        slots: st.slots.map((sl) => ({ pos: this.toWorld(origin, heading, sl.x, sl.z), pose: sl.pose })),
        color: l.color,
        faceHeading: heading,
      };
    }
    return out;
  }

  private neonMat(color: number, intensity = 1.6): THREE.MeshStandardMaterial {
    const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.4 });
    this.neon.push({ mat: m, base: intensity });
    return m;
  }

  private addLampLight(g: THREE.Group, color: number, x: number, y: number, z: number, intensity: number, dist: number): void {
    const p = new THREE.PointLight(color, 0, dist, 1.6);
    p.position.set(x, y, z);
    p.userData['base'] = intensity;
    g.add(p);
    this.lampLights.push(p);
  }

  /** HDB block with an open void deck. Local -Z is the back of the building. */
  private buildVoidDeck(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    const facade = this.facadeMat('#ffb4a2', '#ff7f6e', 11);
    const W = 46;
    const D = 15;
    const H = 38;
    const deckH = 4.4;
    // upper slab
    const slab = new THREE.Mesh(tiledBox(W, H - deckH, D, 24), facade);
    slab.position.set(0, deckH + (H - deckH) / 2, -D / 2 - 0.5);
    slab.castShadow = true;
    g.add(slab);
    // back wall of the void deck
    g.add(box(W, deckH, 1, mat(0xffe4d6), 0, deckH / 2, -D - 0.5, true));
    g.add(box(1, deckH, D, mat(0xffe4d6), -W / 2, deckH / 2, -D / 2 - 0.5));
    g.add(box(1, deckH, D, mat(0xffe4d6), W / 2, deckH / 2, -D / 2 - 0.5));
    // pillars
    for (let x = -W / 2 + 3; x <= W / 2 - 3; x += 6.4) {
      g.add(box(1.1, deckH, 1.1, mat(0xfff1e8), x, deckH / 2, 0.2, true));
    }
    // ceiling light strips
    const strip = this.neonMat(0xfff0c2, 1.1);
    for (let x = -18; x <= 18; x += 9) g.add(box(4, 0.1, 0.35, strip, x, deckH - 0.08, -5));
    // stair cores
    const core = mat(0xfff1e8);
    for (const x of [-15, 15]) g.add(box(5, H + 3, D + 2.4, core, x, (H + 3) / 2, -D / 2 - 0.5));
    // tiled floor patch
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(W - 2, D), mat(0xffd9c7, { roughness: 0.6 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0.03, -D / 2 - 0.3);
    floor.receiveShadow = true;
    g.add(floor);
    // benches, chess tables, notice board
    const wood = mat(0x9a5b3a);
    for (const x of [-8, 8, 0]) {
      g.add(box(3, 0.16, 0.7, wood, x, 0.5, -11, true));
      g.add(box(3, 0.7, 0.14, wood, x, 0.85, -11.4));
      g.add(box(0.2, 0.5, 0.6, mat(0x555a7a), x - 1.2, 0.25, -11));
      g.add(box(0.2, 0.5, 0.6, mat(0x555a7a), x + 1.2, 0.25, -11));
    }
    for (const x of [-12, 12]) {
      g.add(cyl(0.9, 0.9, 0.12, mat(0xd8d2e6), x, 0.85, -6.5, 14, true));
      g.add(cyl(0.16, 0.22, 0.85, mat(0xb7b0cc), x, 0.42, -6.5));
      for (const dx of [-1.3, 1.3]) g.add(cyl(0.3, 0.3, 0.5, mat(0xb7b0cc), x + dx, 0.25, -6.5, 10));
    }
    g.add(box(6, 2.2, 0.2, mat(0x3b2d6e), -6, 2.4, -14.8));
    g.add(box(5.6, 1.9, 0.05, this.neonMat(0x38bdf8, 0.5), -6, 2.4, -14.68));
    const s = textSprite('Blk 12', { color: '#ffd1e8', scale: 0.55 });
    s.position.set(0, 6.2, 0.9);
    g.add(s);
    const ptr = sphere(0.25, this.neonMat(0xffb4d6, 1.5), 0, 4.0, 1);
    g.add(ptr);
    this.addLampLight(g, 0xffd9a0, 0, 3.6, -6, 16, 22);

    // Only the back and side walls block the player: the void deck floor stays walkable.
    for (let x = -W / 2; x <= W / 2; x += 5) {
      const p = this.toWorld(origin, h, x, -D - 0.5);
      this.colliders.push({ x: p.x, z: p.z, r: 3.2 });
    }
    for (const sx of [-W / 2, W / 2]) {
      for (let z = -2; z >= -D; z -= 4) {
        const p = this.toWorld(origin, h, sx, z);
        this.colliders.push({ x: p.x, z: p.z, r: 2.4 });
      }
    }
  }

  private buildHawker(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    const roofCols = [0xef4444, 0xfbbf24, 0x22c55e, 0x38bdf8];
    const W = 24;
    const D = 16;
    // roof made of coloured stripes
    for (let i = 0; i < 8; i += 1) {
      const c = roofCols[i % roofCols.length] ?? 0xef4444;
      const stripe = box(W / 8, 0.35, D + 2, mat(c, { roughness: 0.55 }), -W / 2 + W / 16 + (i * W) / 8, 5.4 + (i % 2) * 0.05, -D / 2 - 1, true);
      g.add(stripe);
    }
    for (const [x, z] of [[-W / 2 + 1, 2], [W / 2 - 1, 2], [-W / 2 + 1, -D + 0.5], [W / 2 - 1, -D + 0.5], [0, 2], [0, -D + 0.5]] as const) {
      g.add(cyl(0.3, 0.3, 5.4, mat(0xfef3c7), x, 2.7, z, 8, true));
    }
    g.add(box(W, 3.6, 0.5, mat(0xfde68a), 0, 1.8, -D - 0.5));
    // stalls
    const signs: Array<[string, string]> = [['Noodles', '#fbbf24'], ['Satay', '#fb7185'], ['Drinks', '#38bdf8'], ['Rice', '#a3e635']];
    signs.forEach(([t, col], i) => {
      const x = -9 + i * 6;
      g.add(box(4.6, 1.1, 1.3, mat(0xffffff, { roughness: 0.5 }), x, 0.55, -D + 1.5, true));
      g.add(box(4.6, 0.12, 1.5, mat(0x94a3b8), x, 1.15, -D + 1.5));
      const s = textSprite(t, { color: col, scale: 0.42, width: 384 });
      s.position.set(x, 3.4, -D + 1.3);
      g.add(s);
      g.add(box(4.2, 0.9, 0.2, this.neonMat(0xffe9a8, 0.9), x, 2.7, -D + 0.9));
    });
    // tables + stools
    const stoolCols = [0xef4444, 0x38bdf8, 0xfbbf24, 0x22c55e, 0xa78bfa];
    let k = 0;
    for (const x of [-8, -2.5, 3, 8.5]) {
      for (const z of [-4, -9]) {
        g.add(cyl(0.85, 0.85, 0.1, mat(0xfafafa), x, 0.9, z, 16, true));
        g.add(cyl(0.12, 0.12, 0.9, mat(0x64748b), x, 0.45, z, 8));
        for (const [dx, dz] of [[1.1, 0], [-1.1, 0], [0, 1.1], [0, -1.1]] as const) {
          g.add(cyl(0.3, 0.3, 0.55, mat(stoolCols[k % stoolCols.length] ?? 0xef4444), x + dx, 0.27, z + dz, 10));
          k += 1;
        }
      }
    }
    // hanging lanterns + string lights
    for (let i = 0; i < 14; i += 1) {
      const x = -W / 2 + 1.5 + (i * (W - 3)) / 13;
      const l = sphere(0.32, this.neonMat(roofCols[i % roofCols.length] ?? 0xef4444, 1.4), x, 4.6, 2.2 - (i % 2) * 0.6, 10);
      g.add(l);
    }
    const hs = textSprite('Hawker Centre', { color: '#ffe08a', scale: 0.6 });
    hs.position.set(0, 7.4, 2);
    g.add(hs);
    this.addLampLight(g, 0xffc27a, 0, 4.2, -4, 18, 26);
    this.addRectCollider(origin, h, 0, -D + 0.6, W, 2);
  }

  private buildMrt(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    const glass = new THREE.MeshStandardMaterial({ color: 0x8fdcff, transparent: true, opacity: 0.4, roughness: 0.1, metalness: 0.2, emissive: 0x2a8cc4, emissiveIntensity: 0.35 });
    const W = 16;
    const D = 10;
    g.add(box(W, 0.6, D + 2, mat(0xe11d48), 0, 6.4, -D / 2, true));
    g.add(box(W, 0.35, D + 2, mat(0xffffff), 0, 6.0, -D / 2));
    for (const x of [-W / 2, W / 2]) g.add(box(0.5, 6, D, glass, x, 3, -D / 2));
    g.add(box(W, 6, 0.5, glass, 0, 3, -D));
    for (const x of [-W / 2, W / 2]) g.add(box(0.7, 6, 0.7, mat(0xdbeafe), x, 3, 1.2, true));
    // escalator ramp going down
    const ramp = box(5, 0.4, 8, mat(0x334155), 0, 0.5, -5);
    ramp.rotation.x = 0.25;
    g.add(ramp);
    // gantries
    for (let i = 0; i < 4; i += 1) {
      const x = -4.5 + i * 3;
      g.add(box(0.7, 1.1, 2.2, mat(0xf1f5f9, { roughness: 0.4 }), x, 0.55, -0.6, true));
      g.add(box(0.5, 0.06, 0.5, this.neonMat(i % 2 ? 0x4ade80 : 0xef4444, 2), x, 1.14, -0.2));
    }
    // round line sign
    const sign = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.3, 24), this.neonMat(0xef4444, 1.0));
    sign.rotation.x = Math.PI / 2;
    sign.position.set(0, 8.2, 1.4);
    g.add(sign);
    const txt = textSprite('MRT', { color: '#ffffff', bg: 'rgba(225,29,72,0.95)', scale: 0.55, width: 300 });
    txt.position.set(0, 8.2, 1.7);
    g.add(txt);
    // bus stop
    g.add(box(6, 0.2, 2.2, mat(0x64748b), 13, 3, 2, true));
    g.add(box(0.2, 3, 2.2, glass, 15.9, 1.5, 2));
    g.add(box(4, 0.15, 0.6, mat(0xfbbf24), 13, 0.6, 2.8));
    g.add(box(0.35, 3, 0.35, mat(0x64748b), 10.2, 1.5, 3));
    this.addLampLight(g, 0x9be4ff, 0, 5, -3, 18, 24);
    this.addRectCollider(origin, h, 0, -D / 2 - 1, W, D - 2);
  }

  private buildLibrary(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    const W = 22;
    const D = 12;
    const glass = new THREE.MeshStandardMaterial({ color: 0xc7f9ff, transparent: true, opacity: 0.32, roughness: 0.1, metalness: 0.2, emissive: 0xffd9a0, emissiveIntensity: 0.55 });
    g.add(box(W, 0.6, D, mat(0x6d28d9), 0, 9.3, -D / 2, true));
    g.add(box(W, 9, 0.5, mat(0xede9fe), 0, 4.5, -D));
    for (const x of [-W / 2, W / 2]) g.add(box(0.5, 9, D, mat(0xede9fe), x, 4.5, -D / 2));
    g.add(box(W, 9, 0.35, glass, 0, 4.5, 0));
    for (let x = -W / 2; x <= W / 2; x += 3.66) g.add(box(0.25, 9, 0.4, mat(0x5b21b6), x, 4.5, 0.1));
    // interior shelves + desks
    for (let i = 0; i < 6; i += 1) {
      const c = [0xf472b6, 0x38bdf8, 0xfbbf24, 0x34d399][i % 4] ?? 0xf472b6;
      g.add(box(3.2, 3.2, 0.8, mat(c, { roughness: 0.7 }), -8 + i * 3.2, 1.7, -D + 1.2));
    }
    for (const x of [-6, 0, 6]) {
      g.add(box(3, 0.15, 1.4, mat(0xfef3c7), x, 0.9, -5));
      g.add(box(0.4, 0.4, 0.05, this.neonMat(0xfff0c2, 1.2), x, 1.2, -5));
    }
    const s = textSprite('Community Library', { color: '#e9d5ff', scale: 0.62 });
    s.position.set(0, 11.2, 0.6);
    g.add(s);
    // terrace pergola + study tables
    for (const x of [-7, 7]) {
      g.add(cyl(0.16, 0.16, 3.2, mat(0xa78bfa), x, 1.6, 6.5, 8, true));
    }
    g.add(box(16, 0.18, 3, mat(0xa78bfa), 0, 3.2, 6.5, true));
    for (let i = -3; i <= 3; i += 1) g.add(box(0.14, 0.14, 3, mat(0x7c3aed), i * 2.2, 3.4, 6.5));
    for (const x of [-3.2, 3.2]) {
      g.add(box(2.6, 0.12, 1.4, mat(0xfff7e6), x, 0.85, 3.6, true));
      g.add(box(0.2, 0.85, 0.2, mat(0x64748b), x, 0.42, 3.6));
      g.add(box(0.8, 0.05, 0.55, this.neonMat(0x9be4ff, 1.0), x + 0.3, 0.95, 3.6));
      g.add(sphere(0.12, this.neonMat(0xffe9a8, 2), x - 0.7, 1.35, 3.4));
      for (const dz of [-1.2, 1.1]) g.add(cyl(0.28, 0.28, 0.5, mat(0x7c3aed), x, 0.25, 3.6 + dz, 10));
    }
    this.addLampLight(g, 0xffe2b0, 0, 4, -3, 16, 22);
    this.addRectCollider(origin, h, 0, -D / 2, W, D);
  }

  private buildKopitiam(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    const cols: Array<[number, number]> = [[0x2dd4bf, 0xfef3c7], [0xfbbf24, 0xfde68a], [0xfb7185, 0xffe4e6]];
    const W = 6.4;
    cols.forEach(([c, trim], i) => {
      const x = (i - 1) * W;
      g.add(box(W - 0.2, 9, 8, mat(c, { roughness: 0.75 }), x, 4.5, -4, true));
      g.add(box(W - 0.2, 0.5, 8.6, mat(trim), x, 9.2, -4));
      // upper windows
      g.add(box(1.5, 1.9, 0.2, this.neonMat(0xffe9a8, 0.9), x - 1.3, 6.6, 0.05));
      g.add(box(1.5, 1.9, 0.2, this.neonMat(0xffe9a8, 0.9), x + 1.3, 6.6, 0.05));
      // shopfront opening
      g.add(box(W - 1.4, 3.4, 0.2, mat(0x1c1233), x, 1.7, 0.05));
      g.add(box(W - 2, 2.6, 0.12, this.neonMat(0xffd7a0, 0.75), x, 1.7, 0.16));
      // striped awning
      for (let s = 0; s < 6; s += 1) {
        const st = box((W - 0.4) / 6, 0.12, 2, mat(s % 2 ? 0xffffff : 0xef4444), x - (W - 0.4) / 2 + (s + 0.5) * ((W - 0.4) / 6), 3.9, 1);
        st.rotation.x = 0.28;
        g.add(st);
      }
    });
    const neon = textSprite('Kopitiam', { color: '#ffe08a', bg: 'rgba(60,10,40,0.85)', scale: 0.75 });
    neon.position.set(0, 10.8, 0.9);
    g.add(neon);
    // tables + stools
    for (const x of [-6, -1.6, 2.8, 7]) {
      g.add(cyl(0.7, 0.7, 0.1, mat(0xf5f5f4), x, 0.85, 3.2, 16, true));
      g.add(cyl(0.1, 0.1, 0.85, mat(0x57534e), x, 0.42, 3.2, 8));
      for (const [dx, dz] of [[0.9, 0], [-0.9, 0]] as const) g.add(cyl(0.26, 0.26, 0.5, mat(0xb45309), x + dx, 0.25, 3.2 + dz, 10));
      g.add(cyl(0.12, 0.1, 0.16, mat(0xffffff), x + 0.2, 1.0, 3.2, 10));
    }
    this.addLampLight(g, 0xffcf85, 0, 4, 2, 16, 22);
    this.addRectCollider(origin, h, 0, -4, W * 3, 8);
  }

  private buildPlayground(g: THREE.Group, origin: THREE.Vector3, h: number): void {
    // rubber floor: coloured wedges
    const cols = [0xf97316, 0x22c55e, 0x38bdf8, 0xfacc15, 0xf472b6, 0xa78bfa];
    for (let i = 0; i < 6; i += 1) {
      const wedge = new THREE.Mesh(new THREE.CircleGeometry(13, 16, (i * Math.PI) / 3, Math.PI / 3), new THREE.MeshStandardMaterial({ color: cols[i] ?? 0xf97316, roughness: 0.95 }));
      wedge.rotation.x = -Math.PI / 2;
      wedge.position.set(0, 0.04, 0);
      wedge.receiveShadow = true;
      g.add(wedge);
    }
    // slide tower
    const red = mat(0xef4444);
    const yellow = mat(0xfacc15);
    for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as const) g.add(box(0.2, 3, 0.2, yellow, -5 + x, 1.5, -4 + z, true));
    g.add(box(2.4, 0.2, 2.4, red, -5, 3, -4, true));
    g.add(box(2.6, 0.9, 0.12, mat(0x22c55e), -5, 3.6, -5.2));
    const slide = box(1.3, 0.14, 5.4, mat(0x38bdf8, { roughness: 0.3 }), -5, 1.5, -0.7, true);
    slide.rotation.x = 0.53;
    g.add(slide);
    // swings
    for (const x of [4, 9]) g.add(cyl(0.12, 0.12, 3.6, mat(0xfb923c), x, 1.8, -5, 8, true));
    const crossbar = cyl(0.1, 0.1, 5.4, mat(0xfb923c), 6.5, 3.6, -5, 8, true);
    crossbar.rotation.z = Math.PI / 2;
    g.add(crossbar);
    for (const x of [5.7, 7.3]) {
      g.add(box(0.05, 2.5, 0.05, mat(0x94a3b8), x, 2.3, -5));
      g.add(box(0.7, 0.1, 0.35, mat(0xf472b6), x, 1.0, -5));
    }
    // spring riders
    for (const [x, c] of [[-9, 0xa3e635], [-10.6, 0xf472b6]] as const) {
      g.add(cyl(0.08, 0.08, 0.7, mat(0x94a3b8), x, 0.4, 2, 8));
      g.add(sphere(0.5, mat(c), x, 1.0, 2, 10));
    }
    // benches
    for (const x of [-1.5, 1.6]) {
      g.add(box(2.4, 0.14, 0.6, mat(0xa16207), x, 0.5, 1.5, true));
      g.add(box(2.4, 0.6, 0.12, mat(0xa16207), x, 0.85, 1.18));
      g.add(box(0.2, 0.5, 0.5, mat(0x475569), x - 1, 0.25, 1.5));
      g.add(box(0.2, 0.5, 0.5, mat(0x475569), x + 1, 0.25, 1.5));
    }
    // tall lamp
    g.add(cyl(0.12, 0.16, 6, mat(0x475569), 0, 3, 8, 8));
    g.add(sphere(0.5, this.neonMat(0xffe2a8, 2.2), 0, 6.2, 8));
    const s = textSprite('Playground', { color: '#ffd9a8', scale: 0.55 });
    s.position.set(0, 7.6, 3);
    g.add(s);
    this.addLampLight(g, 0xffd1a0, 0, 6, 4, 18, 26);
    this.addRectCollider(origin, h, -5, -4, 2.6, 2.6);
  }

  /* --- ripple pool at the centre --- */

  private buildPool(): void {
    const basin = cyl(4.4, 4.7, 0.5, mat(0xe9ddff, { roughness: 0.5 }), 0, 0.25, 0, 32, true);
    this.scene.add(basin);
    const water = new THREE.Mesh(
      new THREE.CircleGeometry(4.0, 40),
      new THREE.MeshStandardMaterial({ color: 0x2dd4bf, emissive: 0x14b8a6, emissiveIntensity: 0.85, roughness: 0.15, metalness: 0.2 }),
    );
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.52;
    this.scene.add(water);
    for (let i = 0; i < 4; i += 1) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.9, 1.0, 48),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.56;
      ring.userData['phase'] = i / 4;
      this.scene.add(ring);
      this.poolRings.push(ring);
    }
    const spout = cyl(0.35, 0.5, 1.3, mat(0xffffff, { roughness: 0.3 }), 0, 1.1, 0, 12, true);
    this.scene.add(spout);
    const orb = sphere(0.55, this.neonMat(0x67e8f9, 2.2), 0, 2.2, 0, 16);
    this.scene.add(orb);
    this.movable.push(orb);
    const glow = glowSprite(0x67e8f9, 7, 0.55);
    glow.position.set(0, 2.2, 0);
    this.scene.add(glow);
    this.colliders.push({ x: 0, z: 0, r: 4.9 });
  }

  /* --- trees --- */

  private buildTrees(): void {
    const rnd = mulberry32(5150);
    const spots: Array<{ x: number; z: number; s: number; c: number }> = [];
    const canopyCols = [0x22c55e, 0x16a34a, 0x4ade80, 0xf97316, 0xef4444, 0xfacc15, 0xf472b6];
    const nearLandmark = (x: number, z: number): boolean =>
      LAYOUT.some((l) => Math.hypot(x - l.x, z - l.z) < 20) || Math.hypot(x, z) < 8;
    let tries = 0;
    while (spots.length < 90 && tries < 2000) {
      tries += 1;
      const ang = rnd() * Math.PI * 2;
      // Trees only beyond r=36: the plaza and the r≈24-34 orbit cameras stay clear of canopies.
      const r = 36 + rnd() * 32;
      const x = Math.cos(ang) * r;
      const z = Math.sin(ang) * r;
      if (nearLandmark(x, z)) continue;
      // keep the spokes (walking paths) clear
      const onSpoke = LAYOUT.some((l) => {
        const t = (x * l.x + z * l.z) / (RING * RING);
        const px = t * l.x;
        const pz = t * l.z;
        return t > 0 && t < 1.05 && Math.hypot(x - px, z - pz) < 6;
      });
      if (onSpoke) continue;
      const flame = rnd() < 0.28;
      spots.push({ x, z, s: 0.7 + rnd() * 0.55, c: flame ? (canopyCols[3 + Math.floor(rnd() * 4)] ?? 0xf97316) : (canopyCols[Math.floor(rnd() * 3)] ?? 0x22c55e) });
    }
    const n = spots.length;
    const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.28, 0.4, 3.4, 8), mat(0x6b4226), n);
    trunk.castShadow = true;
    const cGeo = new THREE.IcosahedronGeometry(1, 1);
    const canopy = new THREE.InstancedMesh(cGeo, new THREE.MeshStandardMaterial({ roughness: 0.85, flatShading: true }), n * 3);
    canopy.castShadow = true;
    const m4 = new THREE.Matrix4();
    const col = new THREE.Color();
    spots.forEach((sp, i) => {
      m4.compose(new THREE.Vector3(sp.x, 1.7 * sp.s, sp.z), new THREE.Quaternion(), new THREE.Vector3(sp.s, sp.s, sp.s));
      trunk.setMatrixAt(i, m4);
      for (let k = 0; k < 3; k += 1) {
        const ox = (k - 1) * 1.3 * sp.s * (0.6 + rnd() * 0.5);
        const oz = (rnd() - 0.5) * 1.6 * sp.s;
        const oy = 4.1 * sp.s + (k === 1 ? 0.9 : 0) * sp.s;
        const sc = (2.1 - Math.abs(k - 1) * 0.35) * sp.s;
        m4.compose(new THREE.Vector3(sp.x + ox, oy, sp.z + oz), new THREE.Quaternion(), new THREE.Vector3(sc, sc * 0.78, sc));
        canopy.setMatrixAt(i * 3 + k, m4);
        col.setHex(sp.c).offsetHSL((rnd() - 0.5) * 0.03, 0, (rnd() - 0.5) * 0.08);
        canopy.setColorAt(i * 3 + k, col);
      }
      this.colliders.push({ x: sp.x, z: sp.z, r: 0.7 * sp.s });
      this.canopies.push({ x: sp.x, z: sp.z, r: 3.0 * sp.s, yMin: 2.4 * sp.s, yMax: 7.2 * sp.s });
    });
    trunk.instanceMatrix.needsUpdate = true;
    canopy.instanceMatrix.needsUpdate = true;
    if (canopy.instanceColor) canopy.instanceColor.needsUpdate = true;
    this.scene.add(trunk, canopy);
  }

  /* --- lamps --- */

  private buildLamps(): void {
    const rnd = mulberry32(99);
    const pts: Array<[number, number]> = [];
    for (const l of LAYOUT) {
      for (let d = 12; d <= 34; d += 11) {
        const nx = -l.z / RING;
        const nz = l.x / RING;
        const off = d % 2 ? 3.6 : -3.6;
        pts.push([(l.x / RING) * d + nx * off, (l.z / RING) * d + nz * off]);
      }
    }
    for (let i = 0; i < 10; i += 1) {
      const a = (i / 10) * Math.PI * 2 + 0.2;
      pts.push([Math.cos(a) * 18, Math.sin(a) * 18]);
    }
    const bulbGeo = new THREE.SphereGeometry(0.34, 10, 8);
    for (const [x, z] of pts) {
      const pole = cyl(0.09, 0.13, 4.6, mat(0x3b3358), x, 2.3, z, 8, true);
      this.scene.add(pole);
      const bm = new THREE.MeshBasicMaterial({ color: 0xffe2a8 });
      const bulb = new THREE.Mesh(bulbGeo, bm);
      bulb.position.set(x, 4.8, z);
      this.scene.add(bulb);
      this.lampMats.push(bm);
      const gl = glowSprite(0xffcf85, 4.2, 0);
      gl.position.set(x, 4.8, z);
      this.scene.add(gl);
      this.lampGlows.push(gl);
      this.colliders.push({ x, z, r: 0.25 });
      void rnd;
    }
  }

  /* --- bunting --- */

  private buildBunting(): void {
    const poles: THREE.Vector3[] = [];
    const n = 12;
    for (let i = 0; i < n; i += 1) {
      const a = (i / n) * Math.PI * 2;
      const p = new THREE.Vector3(Math.cos(a) * 20, 0, Math.sin(a) * 20);
      poles.push(p);
      this.scene.add(cyl(0.1, 0.14, 6.4, mat(0xf5f3ff), p.x, 3.2, p.z, 8, true));
      this.colliders.push({ x: p.x, z: p.z, r: 0.3 });
    }
    const perSpan = 11;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute([-0.42, 0, 0, 0.42, 0, 0, 0, -0.9, 0], 3));
    const flags = new THREE.InstancedMesh(geo, new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }), n * perSpan);
    const cols = [0xff5fa2, 0xfbbf24, 0x2dd4bf, 0xa78bfa, 0xfb923c, 0x60a5fa];
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    let idx = 0;
    for (let i = 0; i < n; i += 1) {
      const a = poles[i];
      const b = poles[(i + 1) % n];
      if (!a || !b) continue;
      for (let k = 0; k < perSpan; k += 1) {
        const t = (k + 0.5) / perSpan;
        const x = a.x + (b.x - a.x) * t;
        const z = a.z + (b.z - a.z) * t;
        const y = 6.2 - 1.3 * 4 * t * (1 - t);
        q.setFromEuler(new THREE.Euler(0, Math.atan2(b.x - a.x, b.z - a.z) + Math.PI / 2, 0));
        m4.compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(1, 1, 1));
        flags.setMatrixAt(idx, m4);
        flags.setColorAt(idx, new THREE.Color(cols[(i + k) % cols.length] ?? 0xff5fa2));
        idx += 1;
      }
    }
    flags.instanceMatrix.needsUpdate = true;
    if (flags.instanceColor) flags.instanceColor.needsUpdate = true;
    this.scene.add(flags);
  }

  /* --- beacons --- */

  private buildBeacons(): void {
    for (const l of LAYOUT) {
      const g = new THREE.Group();
      const beamMat = new THREE.MeshBasicMaterial({
        color: l.color,
        map: this.beamTex,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        fog: false,
      });
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.5, 16, 24, 1, true), beamMat);
      beam.position.y = 8;
      g.add(beam);
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(1.4, 1.7, 40),
        new THREE.MeshBasicMaterial({ color: l.color, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.08;
      g.add(ring);
      const glow = glowSprite(l.color, 6, 0.7);
      glow.position.y = 1.2;
      g.add(glow);
      const label = textSprite('', { color: '#ffffff' });
      label.position.y = 10;
      label.visible = false;
      g.add(label);
      g.visible = false;
      this.scene.add(g);
      this.beacons.push({ group: g, beam, ring, label, glow, color: l.color, state: 'hidden' });
    }
  }

  setBeacon(index: number, state: Beacon['state'], text?: { title: string; sub: string }): void {
    const b = this.beacons[index];
    const info = LAYOUT[index] ? this.landmarks[LAYOUT[index].id] : undefined;
    if (!b || !info) return;
    b.state = state;
    b.group.position.copy(info.npc);
    b.group.visible = state !== 'hidden';
    b.beam.visible = state === 'active';
    b.glow.visible = state === 'active';
    b.label.visible = state === 'active';
    if (text && state === 'active') {
      const old = b.label;
      const next = textSprite(text.title, { sub: text.sub, color: `#${b.color.toString(16).padStart(6, '0')}`, scale: 0.42 });
      next.position.copy(old.position);
      b.group.remove(old);
      (old.material as THREE.SpriteMaterial).map?.dispose();
      old.material.dispose();
      b.label = next;
      b.group.add(next);
    }
    (b.ring.material as THREE.MeshBasicMaterial).opacity = state === 'done' ? 0.25 : 0.9;
  }

  /* --- fireflies --- */

  private buildFireflies(): THREE.Points {
    const n = 150;
    const pos = new Float32Array(n * 3);
    const col = new Float32Array(n * 3);
    const c = new THREE.Color();
    for (let i = 0; i < n; i += 1) {
      const a = this.rnd() * Math.PI * 2;
      const r = 4 + this.rnd() * 56;
      const x = Math.cos(a) * r;
      const y = 0.6 + this.rnd() * 4.2;
      const z = Math.sin(a) * r;
      this.fireflyBase.set([x, y, z], i * 3);
      pos.set([x, y, z], i * 3);
      c.setHex([0xfff3a0, 0xffb3d9, 0x9bf0ff, 0xd3b8ff][i % 4] ?? 0xfff3a0);
      col.set([c.r, c.g, c.b], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const pts = new THREE.Points(
      g,
      new THREE.PointsMaterial({ size: 0.55, map: (glowSprite(0xffffff, 1).material as THREE.SpriteMaterial).map, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true }),
    );
    this.scene.add(pts);
    return pts;
  }

  /* --- time of day: 0 = dusk, 1 = deep night --- */

  setTimeOfDay(k: number): void {
    this.tod = Math.min(1, Math.max(0, k));
    const t = this.tod;
    const L = (a: number, b: number): THREE.Color => this.tmpColor.setHex(a).lerp(new THREE.Color(b), t);
    (this.skyMat.uniforms['top']?.value as THREE.Color).copy(L(DUSK.top, NIGHT.top));
    (this.skyMat.uniforms['mid']?.value as THREE.Color).copy(L(DUSK.mid, NIGHT.mid));
    (this.skyMat.uniforms['horizon']?.value as THREE.Color).copy(L(DUSK.horizon, NIGHT.horizon));
    this.fog.color.copy(L(DUSK.fog, NIGHT.fog));
    this.hemi.color.copy(L(DUSK.hemiSky, NIGHT.hemiSky));
    this.hemi.groundColor.copy(L(DUSK.hemiGround, NIGHT.hemiGround));
    this.hemi.intensity = DUSK.hemiInt + (NIGHT.hemiInt - DUSK.hemiInt) * t;
    this.sun.color.copy(L(DUSK.sun, NIGHT.sun));
    this.sun.intensity = DUSK.sunInt + (NIGHT.sunInt - DUSK.sunInt) * t;
    this.sun.position.set(-40 + 70 * t, 26 + 26 * t, 30 - 60 * t);
    const w = DUSK.window + (NIGHT.window - DUSK.window) * t;
    this.windowMats.forEach((m) => (m.emissiveIntensity = w));
    const lamp = DUSK.lamp + (NIGHT.lamp - DUSK.lamp) * t;
    this.lampMats.forEach((m) => m.color.setRGB(1, 0.86 + 0.1 * (1 - t), 0.6 + 0.2 * (1 - t)).multiplyScalar(0.55 + 0.45 * Math.min(1, lamp)));
    this.lampGlows.forEach((s) => ((s.material as THREE.SpriteMaterial).opacity = 0.25 + 0.55 * Math.min(1, lamp / 1.7)));
    this.lampLights.forEach((p) => (p.intensity = (p.userData['base'] as number) * (0.4 + t * 0.9)));
    this.neon.forEach((n) => (n.mat.emissiveIntensity = n.base * (0.6 + 0.7 * t)));
    (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, (t - 0.25) / 0.75);
    (this.moon.material as THREE.SpriteMaterial).opacity = Math.max(0, (t - 0.35) / 0.65) * 0.9;
  }

  get timeOfDay(): number {
    return this.tod;
  }

  /* --- per-frame --- */

  update(dt: number, time: number, focus: THREE.Vector3, reduceMotion: boolean): void {
    // Pool ripples
    this.poolRings.forEach((r) => {
      const ph = ((time * 0.35 + (r.userData['phase'] as number)) % 1 + 1) % 1;
      const s = 1 + ph * 3.6;
      r.scale.set(s, s, 1);
      (r.material as THREE.MeshBasicMaterial).opacity = (1 - ph) * 0.75;
      (r.material as THREE.MeshBasicMaterial).color.setHSL((0.5 + ph * 0.25) % 1, 0.9, 0.7);
    });
    // Beacons
    for (const b of this.beacons) {
      if (!b.group.visible) continue;
      const p = 1 + (reduceMotion ? 0 : Math.sin(time * 3) * 0.07);
      b.ring.scale.setScalar(b.state === 'active' ? p : 1);
      b.label.position.y = 10 + (reduceMotion ? 0 : Math.sin(time * 1.6) * 0.35);
      b.beam.rotation.y = time * 0.4;
    }
    if (!reduceMotion) {
      const pos = this.fireflies.geometry.getAttribute('position') as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i += 1) {
        const bx = this.fireflyBase[i * 3] ?? 0;
        const by = this.fireflyBase[i * 3 + 1] ?? 0;
        const bz = this.fireflyBase[i * 3 + 2] ?? 0;
        pos.setXYZ(i, bx + Math.sin(time * 0.6 + i) * 1.1, by + Math.sin(time * 0.9 + i * 1.7) * 0.6, bz + Math.cos(time * 0.5 + i * 0.7) * 1.1);
      }
      pos.needsUpdate = true;
    }
    (this.fireflies.material as THREE.PointsMaterial).opacity = 0.35 + 0.6 * this.tod;

    // Keep the sun's shadow box centred on the player.
    this.sun.target.position.set(focus.x, 0, focus.z);
    this.sun.position.set(focus.x - 40 + 70 * this.tod, 26 + 26 * this.tod, focus.z + 30 - 60 * this.tod);
    void dt;
  }

  dispose(): void {
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mm = m.material as THREE.Material | THREE.Material[] | undefined;
      if (!mm) return;
      const list = Array.isArray(mm) ? mm : [mm];
      list.forEach((x) => {
        const anyM = x as THREE.Material & { map?: THREE.Texture | null; emissiveMap?: THREE.Texture | null };
        anyM.map?.dispose();
        anyM.emissiveMap?.dispose();
        x.dispose();
      });
    });
    this.beamTex.dispose();
  }
}
