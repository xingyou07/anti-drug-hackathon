import * as THREE from 'three';
import type { RippleEffect } from '@/content/types';
import { angleDiff, clamp, damp, glowSprite, mat } from './util';

export interface CharacterLook {
  skin: number;
  hair: number;
  top: number;
  bottom: number;
  hairStyle: 'short' | 'long' | 'cap' | 'bun' | 'none';
  accessory?: 'bag' | 'headphones' | 'glasses' | 'scarf';
}

export const MOOD_COLORS: Record<RippleEffect, number> = {
  steady: 0x2dd4bf,
  wobble: 0xfbbf24,
  strain: 0xfb7185,
};

/**
 * Low-poly, silhouette-friendly people built from primitives. No photographs
 * or likenesses of anyone (project constraint: silhouettes / stylised only).
 * The character faces local +Z.
 */
export class Character {
  readonly group = new THREE.Group();
  private readonly body = new THREE.Group();
  private readonly head = new THREE.Group();
  private readonly armL = new THREE.Group();
  private readonly armR = new THREE.Group();
  private readonly legL = new THREE.Group();
  private readonly legR = new THREE.Group();
  private readonly mouth: THREE.Mesh;
  private readonly browL: THREE.Mesh;
  private readonly browR: THREE.Mesh;
  private readonly halo: THREE.Mesh;
  private readonly haloGlow: THREE.Sprite;
  private readonly haloMat: THREE.MeshBasicMaterial;

  /** Walk cycle phase. */
  private phase = Math.random() * 6;
  private moving = 0;
  private speaking = false;
  private mood: RippleEffect | null = null;
  private slump = 0;
  private tilt = 0;
  private gaze: THREE.Vector3 | null = null;
  private wave = 0;
  private readonly idleSeed = Math.random() * 100;
  private ghost = false;
  private pose: 'stand' | 'sit' | 'slump' = 'stand';
  private sit = 0;
  private slumpPose = 0;

  constructor(look: CharacterLook) {
    const skin = mat(look.skin, { roughness: 0.65 });
    const top = mat(look.top, { roughness: 0.7 });
    const bottom = mat(look.bottom, { roughness: 0.8 });
    const hairM = mat(look.hair, { roughness: 0.55 });
    const dark = mat(0x140c22, { roughness: 0.4 });

    // Torso
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.27, 0.46, 4, 10), top);
    torso.position.y = 1.12;
    torso.castShadow = true;
    this.body.add(torso);

    // Hips + legs
    this.body.position.y = 0;
    for (const [leg, x] of [[this.legL, -0.13], [this.legR, 0.13]] as const) {
      leg.position.set(x, 0.78, 0);
      const l = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.5, 3, 8), bottom);
      l.position.y = -0.36;
      l.castShadow = true;
      leg.add(l);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.09, 0.3), mat(0xf5f5f5, { roughness: 0.6 }));
      shoe.position.set(0, -0.68, 0.05);
      leg.add(shoe);
      this.group.add(leg);
    }

    // Arms
    for (const [arm, x] of [[this.armL, -0.36], [this.armR, 0.36]] as const) {
      arm.position.set(x, 1.36, 0);
      const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.42, 3, 8), top);
      a.position.y = -0.27;
      a.castShadow = true;
      arm.add(a);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), skin);
      hand.position.y = -0.56;
      arm.add(hand);
      this.body.add(arm);
    }

    // Head
    this.head.position.set(0, 1.72, 0);
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 12), skin);
    skull.castShadow = true;
    this.head.add(skull);
    const eyeGeo = new THREE.SphereGeometry(0.035, 8, 6);
    for (const x of [-0.095, 0.095]) {
      const eye = new THREE.Mesh(eyeGeo, dark);
      eye.position.set(x, 0.03, 0.245);
      this.head.add(eye);
    }
    this.browL = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.022, 0.02), dark);
    this.browR = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.022, 0.02), dark);
    this.browL.position.set(-0.095, 0.105, 0.245);
    this.browR.position.set(0.095, 0.105, 0.245);
    this.head.add(this.browL, this.browR);
    this.mouth = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.028, 0.02), mat(0x7a2340, { roughness: 0.5 }));
    this.mouth.position.set(0, -0.1, 0.25);
    this.head.add(this.mouth);

    // Hair
    if (look.hairStyle !== 'none') {
      const capGeo = new THREE.SphereGeometry(0.29, 16, 10, 0, Math.PI * 2, 0, Math.PI * (look.hairStyle === 'cap' ? 0.42 : 0.55));
      const cap = new THREE.Mesh(capGeo, hairM);
      cap.position.y = 0.02;
      cap.rotation.x = -0.18;
      this.head.add(cap);
      if (look.hairStyle === 'long') {
        const back = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.34, 3, 8), hairM);
        back.position.set(0, -0.1, -0.13);
        this.head.add(back);
      }
      if (look.hairStyle === 'bun') {
        const bun = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), hairM);
        bun.position.set(0, 0.3, -0.06);
        this.head.add(bun);
      }
      if (look.hairStyle === 'cap') {
        const brim = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.02, 0.2), mat(look.top, { roughness: 0.6 }));
        brim.position.set(0, 0.1, 0.28);
        this.head.add(brim);
      }
    }
    if (look.accessory === 'headphones') {
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.03, 6, 20, Math.PI), mat(0x22223a));
      band.rotation.z = Math.PI / 2 + Math.PI / 2;
      band.rotation.y = Math.PI / 2;
      band.position.y = 0.02;
      this.head.add(band);
      for (const x of [-0.29, 0.29]) {
        const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.07, 10), mat(0xff5fa2));
        cup.rotation.z = Math.PI / 2;
        cup.position.set(x, 0, 0);
        this.head.add(cup);
      }
    }
    if (look.accessory === 'glasses') {
      const g = mat(0x1b1240, { roughness: 0.3 });
      for (const x of [-0.095, 0.095]) {
        const lens = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.01, 6, 14), g);
        lens.position.set(x, 0.03, 0.255);
        this.head.add(lens);
      }
    }
    if (look.accessory === 'bag') {
      const bag = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.2), mat(0x14b8a6, { roughness: 0.6 }));
      bag.position.set(0, 1.15, -0.32);
      bag.castShadow = true;
      this.body.add(bag);
    }
    if (look.accessory === 'scarf') {
      const sc = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.07, 8, 16), mat(0xff8a3d));
      sc.rotation.x = Math.PI / 2;
      sc.position.set(0, 1.5, 0);
      this.body.add(sc);
    }

    this.body.add(this.head);
    this.group.add(this.body);

    // Mood halo: colour + posture carry the ripple's effect on this person.
    this.haloMat = new THREE.MeshBasicMaterial({ color: 0x2dd4bf, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
    this.halo = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.035, 8, 28), this.haloMat);
    this.halo.rotation.x = Math.PI / 2;
    this.halo.position.y = 2.32;
    this.group.add(this.halo);
    this.haloGlow = glowSprite(0x2dd4bf, 1.5, 0);
    this.haloGlow.position.y = 2.3;
    this.group.add(this.haloGlow);
  }

  setPosition(x: number, z: number): void {
    this.group.position.set(x, 0, z);
  }

  faceTowards(x: number, z: number): void {
    this.group.rotation.y = Math.atan2(x - this.group.position.x, z - this.group.position.z);
  }

  setHeading(h: number): void {
    this.group.rotation.y = h;
  }

  get heading(): number {
    return this.group.rotation.y;
  }

  setMood(m: RippleEffect | null): void {
    this.mood = m;
    if (m) {
      const c = MOOD_COLORS[m];
      this.haloMat.color.setHex(c);
      (this.haloGlow.material as THREE.SpriteMaterial).color.setHex(c);
    }
  }

  getMood(): RippleEffect | null {
    return this.mood;
  }

  setSpeaking(s: boolean): void {
    this.speaking = s;
  }

  /** Sitting on a bench; 'slump' is a silhouette-level unresponsive posture (no detail, no medical imagery). */
  setPose(p: 'stand' | 'sit' | 'slump'): void {
    this.pose = p;
  }

  setMoving(amount: number): void {
    this.moving = clamp(amount, 0, 1.4);
  }

  setGaze(target: THREE.Vector3 | null): void {
    this.gaze = target;
  }

  /** A brief friendly wave (title screen). */
  doWave(): void {
    this.wave = 1.8;
  }

  /** Semi-transparent, used for people who aren't physically in the scene (family, teacher). */
  setGhost(on: boolean): void {
    this.ghost = on;
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (!m.isMesh) return;
      if (m === this.halo) return;
      const src = m.material as THREE.MeshStandardMaterial;
      if (!src || !('emissive' in src)) return;
      const c = src.clone();
      c.transparent = on;
      c.opacity = on ? 0.55 : 1;
      c.emissive = new THREE.Color(on ? 0x9b8cff : 0x000000);
      c.emissiveIntensity = on ? 0.35 : 1;
      m.material = c;
    });
  }

  update(dt: number, time: number, reduceMotion: boolean): void {
    const walk = this.moving;
    this.phase += dt * (5 + walk * 4) * (walk > 0.05 ? 1 : 0);
    const swing = Math.sin(this.phase) * 0.75 * Math.min(1, walk);
    const sitTarget = this.pose === 'stand' ? 0 : 1;
    this.sit += (sitTarget - this.sit) * damp(6, dt);
    this.slumpPose += ((this.pose === 'slump' ? 1 : 0) - this.slumpPose) * damp(4, dt);
    this.group.position.y = -0.33 * this.sit;
    this.legL.rotation.x = swing - 1.45 * this.sit;
    this.legR.rotation.x = -swing - 1.45 * this.sit;

    const idle = reduceMotion ? 0 : Math.sin(time * 1.6 + this.idleSeed) * 0.03;
    this.body.position.y = Math.abs(Math.sin(this.phase)) * 0.06 * Math.min(1, walk) + idle * 0.5;

    // Arms
    let armRX = -swing * 0.9;
    const armLX = swing * 0.9;
    if (this.wave > 0) {
      this.wave -= dt;
      this.armR.rotation.z = -2.4 + Math.sin(time * 14) * 0.35;
      armRX = 0;
    } else {
      this.armR.rotation.z = 0;
    }
    this.armR.rotation.x = armRX;
    this.armL.rotation.x = armLX + idle;

    // Mood posture
    const targetSlump = this.mood === 'strain' ? 0.28 : this.mood === 'wobble' ? 0.1 : 0;
    const targetTilt = this.mood === 'wobble' ? 0.18 : 0;
    this.slump += (targetSlump - this.slump) * damp(4, dt);
    this.tilt += (targetTilt - this.tilt) * damp(4, dt);
    this.body.rotation.x = this.slump + this.slumpPose * 0.55;
    this.head.rotation.z = this.tilt + this.slumpPose * 0.35;

    // Gaze: turn the head toward a target within a comfortable range.
    let yaw = 0;
    let pitch = 0;
    if (this.gaze) {
      const dx = this.gaze.x - this.group.position.x;
      const dz = this.gaze.z - this.group.position.z;
      const want = Math.atan2(dx, dz);
      yaw = clamp(angleDiff(this.group.rotation.y, want), -0.9, 0.9);
      pitch = clamp(-(this.gaze.y - 1.7) * 0.05, -0.3, 0.3);
    }
    this.head.rotation.y += (yaw - this.head.rotation.y) * damp(8, dt);
    this.head.rotation.x += (pitch + this.slump * 0.9 + this.slumpPose * 0.5 - this.head.rotation.x) * damp(8, dt);

    // Face
    const talk = this.speaking && !reduceMotion ? 0.5 + 0.5 * Math.abs(Math.sin(time * 14)) : 0;
    this.mouth.scale.set(1, 1 + talk * 2.8, 1);
    const brow = this.mood === 'strain' ? 0.35 : this.mood === 'wobble' ? 0.2 : 0;
    this.browL.rotation.z = brow;
    this.browR.rotation.z = -brow;

    // Halo
    const targetOpacity = this.mood ? (this.ghost ? 0.95 : 0.9) : 0;
    const cur = this.haloMat.opacity;
    this.haloMat.opacity = cur + (targetOpacity - cur) * damp(5, dt);
    const gm = this.haloGlow.material as THREE.SpriteMaterial;
    gm.opacity += (targetOpacity * 0.55 - gm.opacity) * damp(5, dt);
    const pulse = 1 + (reduceMotion ? 0 : Math.sin(time * 3 + this.idleSeed) * 0.08);
    this.halo.scale.setScalar(pulse);
    this.halo.rotation.z = time * 0.8;
    this.halo.position.y = 2.32 + (reduceMotion ? 0 : Math.sin(time * 2 + this.idleSeed) * 0.04);
  }
}

export const LOOKS: Record<string, CharacterLook> = {
  you: { skin: 0xe8b48a, hair: 0x1c1230, top: 0xffd23f, bottom: 0x2b3a67, hairStyle: 'short', accessory: 'bag' },
  kai: { skin: 0xc98a5b, hair: 0x120a1e, top: 0xff5fa2, bottom: 0x1f2a44, hairStyle: 'cap' },
  jay: { skin: 0xf0c49a, hair: 0x3a2412, top: 0x38bdf8, bottom: 0x334155, hairStyle: 'short', accessory: 'headphones' },
  ryan: { skin: 0xd99a6c, hair: 0x1c1230, top: 0xa3e635, bottom: 0x3b2d5c, hairStyle: 'short', accessory: 'scarf' },
  dev: { skin: 0xb37846, hair: 0x120a1e, top: 0xf97316, bottom: 0x27334d, hairStyle: 'short', accessory: 'glasses' },
  mum: { skin: 0xf0c49a, hair: 0x5a3b2a, top: 0xc084fc, bottom: 0x4c3a75, hairStyle: 'bun' },
  teacher: { skin: 0xe2ac80, hair: 0x2a1a3a, top: 0x34d399, bottom: 0x2f3e5e, hairStyle: 'long', accessory: 'glasses' },
};

const AMBIENT_TOPS = [0xff8a3d, 0x60a5fa, 0xf472b6, 0xfacc15, 0x34d399, 0xa78bfa, 0xfb7185, 0x22d3ee];
const AMBIENT_SKINS = [0xe8b48a, 0xc98a5b, 0xf0c49a, 0xb37846, 0xd99a6c];

export function ambientLook(i: number): CharacterLook {
  const styles: CharacterLook['hairStyle'][] = ['short', 'long', 'bun', 'cap', 'none'];
  return {
    skin: AMBIENT_SKINS[i % AMBIENT_SKINS.length] ?? 0xe8b48a,
    hair: i % 3 === 0 ? 0xd9d9e3 : 0x1c1230,
    top: AMBIENT_TOPS[i % AMBIENT_TOPS.length] ?? 0xff8a3d,
    bottom: i % 2 ? 0x2b3a67 : 0x3f3f5f,
    hairStyle: styles[i % styles.length] ?? 'short',
  };
}
