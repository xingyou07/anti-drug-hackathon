import { Eye, Footprints, Waves, MessagesSquare } from 'lucide-react';
import { rippleContent } from '@/content';
import { t } from './labels';

const ICONS = [Footprints, Eye, MessagesSquare, Waves];

export function TitleScreen({ onStart, hasEngine }: { onStart: () => void; hasEngine: boolean }): JSX.Element {
  return (
    <div className="absolute inset-0 z-20 flex items-end overflow-y-auto bg-gradient-to-t from-ink-950 via-ink-950/60 to-transparent sm:items-center sm:bg-gradient-to-r sm:from-ink-950/95 sm:via-ink-950/70 sm:to-transparent">
      <section aria-labelledby="ripple-title" className="w-full max-w-xl px-5 pb-6 pt-16 sm:px-10 sm:py-10">
        <p className="rp-rise text-xs font-bold uppercase tracking-[0.3em] text-teal-300">{t('kicker')}</p>
        <h1
          id="ripple-title"
          className="rp-title rp-rise mt-1 bg-gradient-to-r from-teal-300 via-sky-300 to-fuchsia-400 bg-clip-text text-6xl font-black tracking-tight text-transparent sm:text-8xl"
          style={{ animationDelay: '60ms' }}
        >
          {rippleContent.title}
        </h1>
        <p className="rp-rise mt-2 text-xl font-semibold text-fg sm:text-2xl" style={{ animationDelay: '120ms' }}>
          {rippleContent.tagline}
        </p>
        <p className="rp-rise mt-3 max-w-md text-sm leading-relaxed text-muted sm:text-base" style={{ animationDelay: '180ms' }}>
          {rippleContent.lede}
        </p>

        <ul className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {rippleContent.howToPlay.map((line, i) => {
            const Icon = ICONS[i % ICONS.length] ?? Waves;
            return (
              <li
                key={line}
                className="rp-rise flex items-start gap-2.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[13px] leading-snug text-muted backdrop-blur-sm"
                style={{ animationDelay: `${240 + i * 70}ms` }}
              >
                <Icon className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" aria-hidden="true" />
                <span>{line}</span>
              </li>
            );
          })}
        </ul>

        {hasEngine ? null : <p className="mt-3 rounded-lg border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-xs text-amber-200">{t('textModeNote')}</p>}

        <button
          type="button"
          onClick={onStart}
          className="rp-rise rp-glow tap-target mt-6 w-full rounded-2xl bg-gradient-to-r from-teal-300 via-cyan-300 to-fuchsia-400 px-8 py-4 text-xl font-black text-ink-950 shadow-xl shadow-teal-500/30 transition hover:brightness-110 sm:w-auto"
          style={{ animationDelay: '520ms' }}
        >
          {t('start')}
        </button>
      </section>
    </div>
  );
}
