import { useEffect, useRef } from 'react';
import { ChevronRight, RotateCcw } from 'lucide-react';
import { rippleContent } from '@/content';
import type { RippleLine, RippleMoment } from '@/content/types';
import type { GameState } from '../state';
import { findChoice } from '../state';
import { PERSON_HUE, personName, personRole, t } from './labels';

interface Props {
  moment: RippleMoment;
  g: GameState;
  onAdvance: () => void;
  onChoose: (id: string) => void;
  onRetry: () => void;
  onToRipple: () => void;
}

function Pressure({ n }: { n: number }): JSX.Element {
  return (
    <span className="inline-flex items-center gap-1" role="img" aria-label={`${t('pressure')} ${n} / 3`}>
      <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-subtle">{t('pressure')}</span>
      {[1, 2, 3].map((i) => (
        <span key={i} className={`h-2 w-4 rounded-full ${i <= n ? 'bg-gradient-to-r from-amber-300 to-rose-400' : 'bg-white/15'}`} />
      ))}
    </span>
  );
}

function SpeechBubble({ line, onClick, hint, autoFocus }: { line: RippleLine; onClick: () => void; hint: string; autoFocus: boolean }): JSX.Element {
  const ref = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (autoFocus) ref.current?.focus({ preventScroll: true });
  }, [line, autoFocus]);
  const narrator = line.who === 'narrator';
  return (
    <button
      ref={ref}
      type="button"
      onClick={onClick}
      key={line.text}
      className="rp-pop group w-full rounded-3xl border border-white/15 bg-ink-950/85 p-4 text-left shadow-2xl backdrop-blur-md transition hover:border-teal-300/60 sm:p-5"
    >
      {narrator ? null : (
        <span className={`mb-2 inline-flex items-center gap-2 rounded-full bg-gradient-to-r ${PERSON_HUE[line.who] ?? 'from-slate-400 to-slate-500'} px-3 py-1 text-xs font-extrabold text-ink-950`}>
          {personName(line.who)}
          {personRole(line.who) ? <span className="font-semibold opacity-70">· {personRole(line.who)}</span> : null}
        </span>
      )}
      <span className={`block text-lg leading-snug sm:text-xl ${narrator ? 'italic text-muted' : 'font-semibold text-fg'}`}>{line.text}</span>
      <span className="mt-3 flex items-center justify-end gap-1 text-xs font-semibold text-teal-300">
        {hint}
        <ChevronRight className="h-4 w-4 transition group-hover:translate-x-0.5" aria-hidden="true" />
      </span>
    </button>
  );
}

function ChatPhone({ lines, upTo, onAdvance, hint, autoFocus }: { lines: RippleLine[]; upTo: number; onAdvance: () => void; hint: string; autoFocus: boolean }): JSX.Element {
  const shown = lines.slice(0, upTo + 1);
  const endRef = useRef<HTMLDivElement>(null);
  const btn = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
    if (autoFocus) btn.current?.focus({ preventScroll: true });
  }, [upTo, autoFocus]);
  return (
    <div className="rp-pop mx-auto w-full max-w-sm overflow-hidden rounded-[2rem] border-2 border-white/25 bg-ink-950/90 shadow-2xl backdrop-blur-md">
      <div className="flex items-center gap-2 border-b border-white/10 bg-white/5 px-4 py-2.5">
        <span className="h-2 w-2 rounded-full bg-emerald-400" aria-hidden="true" />
        <span className="text-sm font-bold text-fg">{personName('chat')}</span>
      </div>
      <div className="flex max-h-[46vh] min-h-[11rem] flex-col gap-2 overflow-y-auto px-3 py-3" aria-live="polite">
        {shown.map((l, i) =>
          l.who === 'narrator' ? (
            <p key={i} className="rp-pop self-center px-4 text-center text-xs italic text-subtle">{l.text}</p>
          ) : (
            <div key={i} className="rp-pop max-w-[85%] self-start">
              <span className="ml-2 text-[10px] font-bold text-subtle">{personName(l.who)}</span>
              <p className={`mt-0.5 rounded-2xl rounded-tl-sm bg-gradient-to-br ${PERSON_HUE[l.who] ?? 'from-slate-400 to-slate-500'} px-3 py-2 text-sm font-semibold text-ink-950`}>{l.text}</p>
            </div>
          ),
        )}
        <div ref={endRef} />
      </div>
      <button
        ref={btn}
        type="button"
        onClick={onAdvance}
        className="tap-target flex w-full items-center justify-end gap-1 border-t border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold text-teal-300 transition hover:bg-white/10"
      >
        {hint}
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
}

/**
 * Everything the player reads and taps during a scene. The 3D view stays
 * visible above it; this sits in the lower part of the frame (or a phone on the
 * right for group-chat scenes) and never covers the bottom-right corner used by
 * the crisis button.
 */
export function MomentOverlay({ moment, g, onAdvance, onChoose, onRetry, onToRipple }: Props): JSX.Element {
  const picked = findChoice(moment, g.picked);
  const hint = t('tapContinue');
  const chat = moment.format === 'chat';

  useEffect(() => {
    if (g.stage !== 'choose') return;
    const onKey = (e: KeyboardEvent): void => {
      if (e.target instanceof HTMLElement && ['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;
      const n = Number(e.key);
      const c = moment.choices[n - 1];
      if (n >= 1 && n <= 9 && c) onChoose(c.id);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [g.stage, moment, onChoose]);

  const header = (
    <div className="pointer-events-none absolute left-3 right-3 top-3 z-10 flex flex-wrap items-center gap-2">
      <span className="rp-rise rounded-full border border-white/10 bg-ink-950/75 px-3 py-1.5 text-xs font-bold text-fg backdrop-blur-md">
        {moment.place} <span className="text-subtle">· {moment.timeLabel}</span>
      </span>
      <span className="rp-rise rounded-full border border-white/10 bg-ink-950/75 px-3 py-1.5 backdrop-blur-md">
        <Pressure n={moment.pressure} />
      </span>
    </div>
  );

  let body: JSX.Element;
  if (g.stage === 'intro') {
    body = (
      <div className="rp-pop w-full rounded-3xl border border-white/15 bg-ink-950/85 p-5 shadow-2xl backdrop-blur-md">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-fuchsia-300">{moment.place} · {moment.timeLabel}</p>
        <h2 className="mt-1 text-3xl font-black tracking-tight">{moment.title}</h2>
        <p className="mt-2 text-base leading-relaxed text-muted">{moment.setup}</p>
        <button
          type="button"
          autoFocus
          onClick={onAdvance}
          className="tap-target mt-4 rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-6 py-3 text-base font-extrabold text-ink-950 shadow-lg shadow-teal-500/30 transition hover:brightness-110"
        >
          {t('continue')}
        </button>
      </div>
    );
  } else if (g.stage === 'lines') {
    body = chat ? (
      <ChatPhone lines={moment.lines} upTo={g.lineIdx} onAdvance={onAdvance} hint={hint} autoFocus />
    ) : (
      <SpeechBubble line={moment.lines[g.lineIdx] ?? { who: 'narrator', text: '' }} onClick={onAdvance} hint={hint} autoFocus />
    );
  } else if (g.stage === 'choose') {
    body = (
      <div className="rp-rise w-full rounded-3xl border border-white/15 bg-ink-950/90 p-4 shadow-2xl backdrop-blur-md sm:p-5">
        <h3 className="text-lg font-extrabold sm:text-xl">{moment.prompt}</h3>
        <ul className="mt-3 flex flex-col gap-2">
          {moment.choices.map((c, i) => (
            <li key={c.id}>
              <button
                type="button"
                onClick={() => onChoose(c.id)}
                className="tap-target group flex w-full items-center gap-3 rounded-2xl border border-white/15 bg-white/5 px-3 py-2.5 text-left text-[15px] font-semibold leading-snug text-fg transition hover:border-teal-300 hover:bg-teal-300/10 sm:text-base"
              >
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-teal-300 to-fuchsia-400 text-sm font-black text-ink-950" aria-hidden="true">
                  {i + 1}
                </span>
                <span>{c.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    );
  } else if (g.stage === 'reaction' && picked) {
    const line = picked.reaction[g.lineIdx];
    const last = g.lineIdx + 1 >= picked.reaction.length;
    body = (
      <div className="flex w-full flex-col gap-2">
        {line ? <SpeechBubble line={line} onClick={last ? (picked.redo ? onAdvance : onToRipple) : onAdvance} hint={last ? (picked.redo ? hint : t('seeRipple')) : hint} autoFocus /> : null}
      </div>
    );
  } else if (g.stage === 'unsafe' && picked) {
    body = (
      <div className="rp-pop w-full rounded-3xl border border-rose-400/40 bg-ink-950/90 p-5 shadow-2xl backdrop-blur-md">
        <h3 className="text-lg font-extrabold text-rose-300">{t('unsafeHeading')}</h3>
        <p className="mt-2 text-base leading-relaxed text-muted">{picked.learn}</p>
        <button
          type="button"
          autoFocus
          onClick={onRetry}
          className="tap-target mt-4 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-300 to-rose-400 px-5 py-3 text-base font-extrabold text-ink-950 transition hover:brightness-110"
        >
          <RotateCcw className="h-4 w-4" aria-hidden="true" />
          {rippleContent.labels['rewind'] ?? ''}
        </button>
      </div>
    );
  } else {
    body = <div />;
  }

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      {header}
      <div
        className={`pointer-events-auto absolute inset-x-3 bottom-3 mx-auto max-h-[68%] overflow-y-auto sm:bottom-6 ${
          chat && g.stage === 'lines' ? 'sm:left-auto sm:right-8 sm:max-w-sm' : 'max-w-2xl'
        }`}
      >
        {body}
      </div>
    </div>
  );
}
