import { useEffect, useState } from 'react';
import { rippleContent } from '@/content';
import { t } from './labels';

interface Props {
  mode: 'pre' | 'post';
  before?: number[] | undefined;
  onDone: (values: number[]) => void;
}

/**
 * Self-rated confidence, before and after. Answers live only in game state and
 * are never stored or sent anywhere. Stated to the player on screen.
 */
export function ConfidenceCheck({ mode, before, onDone }: Props): JSX.Element {
  const { items, scaleLabels, intro } = rippleContent.confidence;
  const [vals, setVals] = useState<number[]>(() => items.map(() => 0));
  const ready = vals.every((v) => v > 0);

  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.target instanceof HTMLElement && ['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;
      if (e.key === 'Enter' && ready) onDone(vals);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [ready, vals, onDone]);

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center overflow-y-auto bg-ink-950/70 p-4 backdrop-blur-sm">
      <section
        aria-labelledby="conf-h"
        className="rp-pop my-auto w-full max-w-xl rounded-3xl border border-white/10 bg-gradient-to-b from-ink-800/95 to-ink-900/95 p-5 shadow-2xl sm:p-7"
      >
        <h2 id="conf-h" className="text-2xl font-extrabold tracking-tight">
          {mode === 'pre' ? t('preHeading') : rippleContent.finale.confidenceHeading}
        </h2>
        <p className="mt-1.5 text-sm text-muted">{mode === 'pre' ? intro : t('postIntro')}</p>

        <div className="mt-5 flex flex-col gap-5">
          {items.map((it, i) => (
            <fieldset key={it.id}>
              <legend className="text-base font-semibold leading-snug text-fg">{it.prompt}</legend>
              <div className="mt-2.5 grid grid-cols-5 gap-1.5" role="radiogroup">
                {scaleLabels.map((lab, k) => {
                  const v = k + 1;
                  const on = vals[i] === v;
                  const was = mode === 'post' && before?.[i] === v;
                  return (
                    <button
                      key={lab}
                      type="button"
                      role="radio"
                      aria-checked={on}
                      onClick={() => setVals((p) => p.map((x, j) => (j === i ? v : x)))}
                      className={`tap-target relative flex flex-col items-center justify-center rounded-xl border px-1 py-2 text-center text-[11px] font-semibold leading-tight transition sm:text-xs ${
                        on
                          ? 'border-transparent bg-gradient-to-br from-teal-300 to-fuchsia-400 text-ink-950 shadow-lg shadow-teal-500/30'
                          : 'border-white/15 bg-white/5 text-muted hover:border-teal-300 hover:text-fg'
                      }`}
                    >
                      <span className="text-base font-extrabold">{v}</span>
                      <span className="mt-0.5 hidden sm:block">{lab}</span>
                      {was ? <span className="absolute -top-2 rounded-full bg-ink-950 px-1.5 text-[9px] text-teal-300 ring-1 ring-teal-400/60">{t('before')}</span> : null}
                    </button>
                  );
                })}
              </div>
              <div className="mt-1 flex justify-between text-[11px] text-subtle sm:hidden">
                <span>{scaleLabels[0]}</span>
                <span>{scaleLabels[scaleLabels.length - 1]}</span>
              </div>
            </fieldset>
          ))}
        </div>

        <div className="mt-6 flex items-center justify-between gap-3">
          {mode === 'pre' ? (
            <button type="button" onClick={() => onDone([])} className="tap-target rounded-xl px-4 py-2 text-sm font-semibold text-subtle transition hover:text-fg">
              {t('skipIntro')}
            </button>
          ) : (
            <span />
          )}
          <button
            type="button"
            disabled={!ready}
            onClick={() => onDone(vals)}
            className="tap-target rounded-xl bg-gradient-to-r from-teal-300 to-cyan-400 px-6 py-2.5 text-base font-extrabold text-ink-950 shadow-lg shadow-teal-500/30 transition enabled:hover:brightness-110 disabled:opacity-40"
          >
            {t('continue')}
          </button>
        </div>
        <p className="mt-3 text-center text-[11px] text-subtle">{t('notSaved')}</p>
      </section>
    </div>
  );
}
