import { ArrowUp, Eye, Footprints, User } from 'lucide-react';
import type { HudInfo, PovMode } from '../engine/RippleEngine';
import { moments } from '../state';
import { t } from './labels';
import { Joystick } from './Joystick';

interface Props {
  hud: HudInfo;
  current: number;
  pov: PovMode;
  touch: boolean;
  hasEngine: boolean;
  onTogglePov: () => void;
  onFastTravel: () => void;
  onJoystick: (x: number, y: number) => void;
}

export function Hud({ hud, current, pov, touch, hasEngine, onTogglePov, onFastTravel, onJoystick }: Props): JSX.Element {
  const m = moments[current];
  const deg = (hud.bearing * 180) / Math.PI;
  const off = Math.abs(hud.bearing) > 0.9;
  const dist = Math.max(0, Math.round(hud.distance - 6));

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      {/* progress + objective */}
      <div className="absolute left-3 right-3 top-3 flex items-start justify-between gap-3">
        <div className="rp-rise pointer-events-auto max-w-[62%] rounded-2xl border border-white/10 bg-ink-950/75 px-3.5 py-2.5 backdrop-blur-md">
          <ol className="flex items-center gap-1.5" aria-label={t('moments')}>
            {moments.map((mm, i) => (
              <li
                key={mm.id}
                aria-current={i === current ? 'step' : undefined}
                className={`h-2 rounded-full transition-all ${
                  i < current ? 'w-4 bg-teal-400' : i === current ? 'rp-glow w-7 bg-gradient-to-r from-teal-300 to-fuchsia-400' : 'w-4 bg-white/20'
                }`}
              />
            ))}
          </ol>
          <p className="mt-1.5 text-xs font-semibold uppercase tracking-wider text-teal-300">
            {t('momentOf', { n: current + 1, m: moments.length })}
          </p>
          {m ? <p className="text-sm font-semibold text-fg">{m.place}</p> : null}
        </div>

        {hasEngine ? (
          <div className="pointer-events-auto flex flex-col items-end gap-2">
            <button
              type="button"
              onClick={onTogglePov}
              aria-pressed={pov === 'first'}
              className="tap-target flex items-center gap-2 rounded-full border border-white/15 bg-ink-950/75 px-3.5 py-2 text-sm font-semibold text-fg backdrop-blur-md transition hover:border-teal-300"
            >
              {pov === 'first' ? <Eye className="h-4 w-4 text-fuchsia-300" aria-hidden="true" /> : <User className="h-4 w-4 text-teal-300" aria-hidden="true" />}
              {pov === 'first' ? t('povFirst') : t('povThird')}
              <span className="hidden rounded border border-white/20 px-1 text-[10px] text-subtle sm:inline">V</span>
            </button>
            <button
              type="button"
              onClick={onFastTravel}
              className="tap-target flex items-center gap-2 rounded-full border border-white/15 bg-ink-950/75 px-3.5 py-2 text-xs font-semibold text-muted backdrop-blur-md transition hover:border-teal-300 hover:text-fg"
            >
              <Footprints className="h-4 w-4" aria-hidden="true" />
              {t('nextMoment')}
            </button>
          </div>
        ) : null}
      </div>

      {/* compass toward the beacon */}
      {hasEngine && hud.index !== null ? (
        <div className="absolute left-1/2 top-[4.6rem] -translate-x-1/2 sm:top-3">
          <div className="rp-rise flex items-center gap-3 rounded-full border border-white/10 bg-ink-950/75 py-1.5 pl-2 pr-4 backdrop-blur-md">
            <span
              className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-teal-300 to-fuchsia-400 text-ink-950"
              style={{ transform: `rotate(${deg}deg)`, transition: 'transform 0.12s linear' }}
              aria-hidden="true"
            >
              <ArrowUp className="h-5 w-5" strokeWidth={3} />
            </span>
            <span className="text-sm font-semibold text-fg" aria-live="polite">
              {off ? (hud.bearing > 0 ? t('turnRight') : t('turnLeft')) : dist <= 0 ? t('almostThere') : t('metresAway', { n: dist })}
            </span>
          </div>
        </div>
      ) : null}

      {/* controls */}
      {hasEngine ? (
        <>
          {touch ? (
            <div className="absolute bottom-4 left-4">
              <Joystick onMove={onJoystick} label={t('joystick')} />
            </div>
          ) : (
            <p className="absolute bottom-3 left-4 hidden rounded-full bg-ink-950/60 px-3 py-1.5 text-xs text-muted backdrop-blur-sm sm:block">
              {t('controlsHint')}
            </p>
          )}
        </>
      ) : null}
    </div>
  );
}
