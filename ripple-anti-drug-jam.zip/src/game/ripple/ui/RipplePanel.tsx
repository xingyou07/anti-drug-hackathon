import { ArrowRight, Lightbulb, MessageCircle } from 'lucide-react';
import { SourceCitation } from '@/components/SourceCitation';
import { rippleContent } from '@/content';
import type { RippleChoice, RippleMoment } from '@/content/types';
import { MOOD_CSS, PERSON_HUE, personName, t } from './labels';

interface Props {
  moment: RippleMoment;
  choice: RippleChoice;
  isLast: boolean;
  practiced: boolean;
  onPractice: () => void;
  onNext: () => void;
}

const STEP = 480;

export function RipplePanel({ moment, choice, isLast, practiced, onPractice, onNext }: Props): JSX.Element {
  const facts = moment.factIds.map((id) => rippleContent.facts[id]).filter((f): f is NonNullable<typeof f> => Boolean(f));
  const base = 500 + choice.ripple.length * STEP;
  const mood = MOOD_CSS[choice.effect];

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      <section
        aria-labelledby="ripple-h"
        className="pointer-events-auto absolute inset-x-3 bottom-3 max-h-[64%] overflow-y-auto rounded-3xl border border-white/15 bg-ink-950/90 p-4 shadow-2xl backdrop-blur-md sm:inset-x-auto sm:bottom-4 sm:right-4 sm:top-4 sm:max-h-none sm:w-[26rem] sm:p-5"
      >
        <div className="flex items-center justify-between gap-2">
          <h2 id="ripple-h" className="text-xl font-black tracking-tight">{rippleContent.finale.title}</h2>
          <span className={`rounded-full border px-2.5 py-1 text-xs font-bold ${mood.bg} ${mood.ring} ${mood.text}`}>
            {rippleContent.effectLabels[choice.effect]}
          </span>
        </div>
        <p className="mt-1 text-sm text-muted">
          <span className="text-subtle">{t('youChose')}</span> {choice.label}
        </p>

        <ul className="mt-3 flex flex-col gap-2">
          {choice.ripple.map((r, i) => {
            const m = MOOD_CSS[r.effect];
            return (
              <li
                key={r.person}
                className="rp-rise flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-3"
                style={{ animationDelay: `${500 + i * STEP}ms` }}
              >
                <span
                  className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-xs font-black text-ink-950 ${PERSON_HUE[r.person] ?? 'from-slate-300 to-slate-400'}`}
                  aria-hidden="true"
                >
                  {personName(r.person).slice(0, 1)}
                </span>
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-bold">
                    {personName(r.person)}
                    <span className={`rounded-full border px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide ${m.bg} ${m.ring} ${m.text}`}>
                      {rippleContent.effectLabels[r.effect]}
                    </span>
                  </p>
                  <p className="mt-0.5 text-[13px] leading-snug text-muted">{r.text}</p>
                </div>
              </li>
            );
          })}
        </ul>

        <div className="rp-rise mt-3 rounded-2xl border border-teal-400/30 bg-teal-400/10 p-3" style={{ animationDelay: `${base}ms` }}>
          <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-300">
            <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" />
            {t('learnHeading')}
          </p>
          <p className="mt-1 text-sm leading-snug text-fg">{choice.learn}</p>
        </div>

        {facts.length ? (
          <div className="rp-rise mt-3" style={{ animationDelay: `${base + 250}ms` }}>
            <p className="text-xs font-bold uppercase tracking-wider text-fuchsia-300">{t('factHeading')}</p>
            <ul className="mt-1.5 flex flex-col gap-2">
              {facts.map((f) => (
                <li key={f.text} className="rounded-xl border border-white/10 bg-white/5 p-3 text-[13px] leading-snug text-muted">
                  {f.text} <SourceCitation source={f.source} sourceUrl={f.sourceUrl} />
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="rp-rise mt-4 flex flex-wrap items-center gap-2" style={{ animationDelay: `${base + 450}ms` }}>
          {moment.practice ? (
            <button
              type="button"
              onClick={onPractice}
              className="tap-target inline-flex items-center gap-2 rounded-2xl border border-fuchsia-300/60 bg-fuchsia-400/10 px-4 py-2.5 text-sm font-bold text-fuchsia-200 transition hover:bg-fuchsia-400/20"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              {practiced ? t('practiceAgain') : t('practiceCta')}
            </button>
          ) : null}
          <button
            type="button"
            onClick={onNext}
            className="tap-target ml-auto inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-5 py-2.5 text-sm font-extrabold text-ink-950 shadow-lg shadow-teal-500/30 transition hover:brightness-110"
          >
            {isLast ? t('finish') : t('continue')}
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </section>
    </div>
  );
}
