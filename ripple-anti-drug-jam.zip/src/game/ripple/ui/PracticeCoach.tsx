import { useEffect, useRef, useState } from 'react';
import { LifeBuoy, Send, X } from 'lucide-react';
import { rippleContent } from '@/content';
import type { RipplePractice } from '@/content/types';
import { useCrisisSheet } from '@/state/CrisisSheetContext';
import { askCoach } from '../coach';
import type { CoachReply, CoachTurn } from '../coach';
import { PERSON_HUE, t } from './labels';

interface Props {
  momentId: string;
  practice: RipplePractice;
  onClose: (done: boolean) => void;
}

interface Exchange {
  you: string;
  reply: CoachReply;
}

const STRENGTH_STYLE = ['', 'from-rose-400 to-amber-300', 'from-amber-300 to-lime-300', 'from-teal-300 to-emerald-300'] as const;

/**
 * "Try it in your own words". Player text goes to this app's own server, which
 * asks Gemini for one in-character reply and one wording tip. When the network
 * or the model is unavailable it silently falls back to a scripted coach; the
 * badge under each reply says which one answered.
 */
export function PracticeCoach({ momentId, practice, onClose }: Props): JSX.Element {
  const cfg = rippleContent.practice;
  const { open: openHelp } = useCrisisSheet();
  const [text, setText] = useState('');
  const [log, setLog] = useState<Exchange[]>([]);
  const [busy, setBusy] = useState(false);
  const [crisis, setCrisis] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const finished = log.length >= cfg.maxTurns;
  const starters = practice.kind === 'refuse' ? cfg.starters : cfg.checkinStarters;

  useEffect(() => {
    taRef.current?.focus({ preventScroll: true });
  }, []);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end', behavior: 'smooth' });
  }, [log, busy, crisis]);

  const send = async (): Promise<void> => {
    const message = text.trim();
    if (!message || busy || finished || crisis) return;
    setBusy(true);
    setText('');
    const history: CoachTurn[] = [{ role: 'friend', text: practice.opener }];
    for (const x of log) {
      history.push({ role: 'you', text: x.you }, { role: 'friend', text: x.reply.friendReply });
    }
    const reply = await askCoach({ momentId, kind: practice.kind, friendName: practice.friendName, history, message });
    setBusy(false);
    if (reply.crisis) {
      setCrisis(true);
      return;
    }
    setLog((p) => [...p, { you: message, reply }]);
  };

  const last = log[log.length - 1];
  const source = last?.reply.source;

  return (
    <div className="absolute inset-0 z-20 flex items-end justify-center bg-ink-950/75 p-3 backdrop-blur-sm sm:items-center">
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="practice-h"
        className="rp-pop flex max-h-full w-full max-w-xl flex-col overflow-hidden rounded-3xl border border-white/15 bg-gradient-to-b from-ink-800 to-ink-900 shadow-2xl"
      >
        <header className="flex items-start justify-between gap-3 border-b border-white/10 p-4">
          <div>
            <h2 id="practice-h" className="text-lg font-black">{cfg.title}</h2>
            <p className="mt-0.5 text-xs text-muted">{cfg.sub}</p>
          </div>
          <button
            type="button"
            onClick={() => onClose(log.length > 0)}
            aria-label={t('close')}
            className="tap-target flex items-center justify-center rounded-full border border-white/15 text-muted transition hover:text-fg"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
          <p className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs italic text-muted">{practice.scenario}</p>

          <div className="flex max-w-[88%] flex-col items-start">
            <span className="mb-1 text-[11px] font-bold text-subtle">{practice.friendName}</span>
            <p className={`rounded-2xl rounded-tl-sm bg-gradient-to-br ${PERSON_HUE[practice.friendId] ?? 'from-slate-300 to-slate-400'} px-3.5 py-2 text-sm font-semibold text-ink-950`}>{practice.opener}</p>
          </div>

          {log.map((x, i) => (
            <div key={i} className="space-y-3">
              <div className="ml-auto flex max-w-[88%] flex-col items-end">
                <p className="rp-pop rounded-2xl rounded-tr-sm bg-white/15 px-3.5 py-2 text-sm font-semibold text-fg">{x.you}</p>
              </div>
              <div className="flex max-w-[88%] flex-col items-start">
                <span className="mb-1 text-[11px] font-bold text-subtle">{practice.friendName}</span>
                <p className={`rp-pop rounded-2xl rounded-tl-sm bg-gradient-to-br ${PERSON_HUE[practice.friendId] ?? 'from-slate-300 to-slate-400'} px-3.5 py-2 text-sm font-semibold text-ink-950`}>{x.reply.friendReply}</p>
              </div>
              <div className="rp-rise rounded-2xl border border-teal-400/30 bg-teal-400/10 p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-teal-300">{t('coachTip')}</span>
                  <span className="flex items-center gap-1.5" role="img" aria-label={t(`strength${x.reply.strength}`)}>
                    {[1, 2, 3].map((n) => (
                      <span key={n} className={`h-2 w-5 rounded-full ${n <= x.reply.strength ? `bg-gradient-to-r ${STRENGTH_STYLE[x.reply.strength]}` : 'bg-white/15'}`} />
                    ))}
                    <span className="ml-1 text-[11px] font-bold text-fg">{t(`strength${x.reply.strength}`)}</span>
                  </span>
                </div>
                <p className="mt-1 text-sm leading-snug text-fg">{x.reply.coachTip}</p>
              </div>
            </div>
          ))}

          {busy ? <p className="text-xs italic text-subtle">{t('thinking')}</p> : null}

          {crisis ? (
            <div className="rp-rise rounded-2xl border border-rose-400/50 bg-rose-400/10 p-4" role="alert">
              <p className="text-sm leading-relaxed text-fg">{cfg.crisisNote}</p>
              <button
                type="button"
                onClick={openHelp}
                className="tap-target mt-3 inline-flex items-center gap-2 rounded-xl bg-crisis-600 px-4 py-2 text-sm font-bold text-white transition hover:bg-crisis-500"
              >
                <LifeBuoy className="h-4 w-4" aria-hidden="true" />
                {t('openHelplines')}
              </button>
            </div>
          ) : null}
          <div ref={endRef} />
        </div>

        <footer className="border-t border-white/10 p-3">
          {finished || crisis ? (
            <button
              type="button"
              onClick={() => onClose(log.length > 0)}
              className="tap-target w-full rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-5 py-3 text-base font-extrabold text-ink-950"
            >
              {t('practiceDone')}
            </button>
          ) : (
            <>
              {log.length === 0 ? (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {starters.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        setText(s);
                        taRef.current?.focus();
                      }}
                      className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs text-muted transition hover:border-teal-300 hover:text-fg"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              ) : null}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void send();
                }}
                className="flex items-end gap-2"
              >
                <label className="sr-only" htmlFor="practice-input">{cfg.placeholder}</label>
                <textarea
                  id="practice-input"
                  ref={taRef}
                  rows={2}
                  value={text}
                  maxLength={cfg.maxChars}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      void send();
                    }
                  }}
                  placeholder={cfg.placeholder}
                  autoComplete="off"
                  className="min-h-[3rem] flex-1 resize-none rounded-xl border border-white/20 bg-ink-950 px-3 py-2 text-sm text-fg placeholder:text-subtle"
                />
                <button
                  type="submit"
                  disabled={busy || !text.trim()}
                  aria-label={cfg.send}
                  className="tap-target flex items-center justify-center rounded-xl bg-gradient-to-br from-teal-300 to-cyan-400 px-4 text-ink-950 transition enabled:hover:brightness-110 disabled:opacity-40"
                >
                  <Send className="h-5 w-5" aria-hidden="true" />
                </button>
              </form>
              <div className="mt-1.5 flex items-start justify-between gap-3 text-[11px] leading-snug text-subtle">
                <span>{cfg.privacy}</span>
                <span className="shrink-0 tabular-nums">{t('turnOf', { n: Math.min(log.length + 1, cfg.maxTurns), max: cfg.maxTurns })}</span>
              </div>
            </>
          )}
          {source ? (
            <p className="mt-1.5 text-center text-[11px] text-subtle">{source === 'gemini' ? cfg.onlineNote : cfg.offlineNote}</p>
          ) : null}
        </footer>
      </section>
    </div>
  );
}
