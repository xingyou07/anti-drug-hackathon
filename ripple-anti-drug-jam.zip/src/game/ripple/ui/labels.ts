import { rippleContent } from '@/content';
import type { RippleEffect } from '@/content/types';

/** Copy lookup: every string a player reads lives in ripple.json (constraint 5). */
export function t(key: string, vars?: Record<string, string | number>): string {
  let s = rippleContent.labels[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
  return s;
}

/** Same hues as the 3D halos (MOOD_COLORS in the engine) so a colour means one thing everywhere. */
export const MOOD_CSS: Record<RippleEffect, { hex: string; text: string; bg: string; ring: string }> = {
  steady: { hex: '#2dd4bf', text: 'text-teal-300', bg: 'bg-teal-400/15', ring: 'border-teal-400/50' },
  wobble: { hex: '#fbbf24', text: 'text-amber-300', bg: 'bg-amber-400/15', ring: 'border-amber-400/50' },
  strain: { hex: '#fb7185', text: 'text-rose-300', bg: 'bg-rose-400/15', ring: 'border-rose-400/50' },
};

export function personName(id: string): string {
  return rippleContent.people[id]?.name ?? id;
}
export function personRole(id: string): string {
  return rippleContent.people[id]?.role ?? '';
}

/** Small, stable colour per speaker for chat bubbles and name chips. */
export const PERSON_HUE: Record<string, string> = {
  kai: 'from-orange-400 to-rose-500',
  jay: 'from-sky-400 to-indigo-500',
  ryan: 'from-lime-400 to-emerald-500',
  dev: 'from-fuchsia-400 to-purple-500',
  chat: 'from-cyan-400 to-blue-500',
  mum: 'from-pink-400 to-rose-400',
  teacher: 'from-amber-300 to-orange-400',
  you: 'from-teal-300 to-cyan-400',
};
