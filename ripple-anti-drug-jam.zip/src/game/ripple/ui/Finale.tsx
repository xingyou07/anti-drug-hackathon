import { ArrowRight, Check, LifeBuoy, MessageCircle, RotateCcw } from 'lucide-react';
import { rippleContent } from '@/content';
import type { RippleEffect } from '@/content/types';
import { useCrisisSheet } from '@/state/CrisisSheetContext';
import { moments } from '../state';
import { MOOD_CSS, PERSON_HUE, personName, personRole, t } from './labels';

interface Props {
  moods: Record<string, RippleEffect | null>;
  pre: number[];
  post: number[];
  commit: string | null;
  onCommit: (id: string) => void;
  onPractice: (momentIndex: number) => void;
  onNextPlayer: () => void;
}

export function Finale({ moods, pre, post, commit, onCommit, onPractice, onNextPlayer }: Props): JSX.Element {
  const f = rippleContent.finale;
  const { open: openHelp } = useCrisisSheet();
  const reached = Object.entries(moods).filter((e): e is [string, RippleEffect] => e[1] !== null);
  const practiceMoments = moments.map((m, i) => ({ m, i })).filter((x) => x.m.practice);
  const compare = pre.length === post.length && pre.length > 0;

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      <section
        aria-labelledby="finale-h"
        className="pointer-events-auto absolute inset-x-3 bottom-3 max-h-[78%] overflow-y-auto rounded-3xl border border-white/15 bg-ink-950/90 p-4 shadow-2xl backdrop-blur-md sm:inset-x-auto sm:bottom-4 sm:right-4 sm:top-4 sm:max-h-none sm:w-[27rem] sm:p-5"
      >
        <h2 id="finale-h" className="rp-title bg-gradient-to-r from-teal-300 via-sky-300 to-fuchsia-400 bg-clip-text text-4xl font-black tracking-tight text-transparent">
          {f.title}
        </h2>
        <p className="mt-1 text-sm text-muted">{f.lede}</p>

        <ul className="mt-3 flex flex-wrap gap-2" aria-label={t('whoReached')}>
          {reached.map(([id, mood]) => {
            const m = MOOD_CSS[mood];
            return (
              <li key={id} className={`rp-pop flex items-center gap-2 rounded-full border py-1 pl-1 pr-3 ${m.bg} ${m.ring}`}>
                <span className={`flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br text-[11px] font-black text-ink-950 ${PERSON_HUE[id] ?? 'from-slate-300 to-slate-400'}`} aria-hidden="true">
                  {personName(id).slice(0, 1)}
                </span>
                <span className="text-xs font-bold text-fg">
                  {personName(id)}
                  {personRole(id) && id !== 'you' ? <span className="sr-only">, {personRole(id)}</span> : null}
                </span>
                <span className={`text-[10px] font-extrabold uppercase tracking-wide ${m.text}`}>{rippleContent.effectLabels[mood]}</span>
              </li>
            );
          })}
        </ul>

        {compare ? (
          <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-teal-300">{f.confidenceHeading}</h3>
            <ul className="mt-2 flex flex-col gap-1.5">
              {rippleContent.confidence.items.map((it, i) => (
                <li key={it.id} className="flex items-center justify-between gap-3 text-xs text-muted">
                  <span className="min-w-0 flex-1 leading-snug">{t(`conf_${it.id}`)}</span>
                  <span className="shrink-0 font-black tabular-nums text-fg">
                    {pre[i]} <ArrowRight className="mx-0.5 inline h-3 w-3 text-teal-300" aria-label={t('to')} /> {post[i]}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-2 text-[11px] text-subtle">{t('confNote')}</p>
          </div>
        ) : null}

        <h3 className="mt-4 text-xs font-bold uppercase tracking-wider text-fuchsia-300">{f.takeawaysHeading}</h3>
        <ul className="mt-1.5 flex flex-col gap-1.5">
          {f.takeaways.map((x) => (
            <li key={x} className="flex gap-2 text-[13px] leading-snug text-fg">
              <Check className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" aria-hidden="true" />
              {x}
            </li>
          ))}
        </ul>

        <h3 className="mt-4 text-xs font-bold uppercase tracking-wider text-amber-300">{f.commitHeading}</h3>
        <div className="mt-1.5 flex flex-col gap-1.5" role="radiogroup" aria-label={f.commitHeading}>
          {f.commitOptions.map((o) => (
            <button
              key={o.id}
              type="button"
              role="radio"
              aria-checked={commit === o.id}
              onClick={() => onCommit(o.id)}
              className={`tap-target rounded-xl border px-3 py-2 text-left text-[13px] font-semibold leading-snug transition ${
                commit === o.id ? 'border-transparent bg-gradient-to-r from-amber-300 to-rose-300 text-ink-950' : 'border-white/15 bg-white/5 text-muted hover:border-amber-300 hover:text-fg'
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
        {commit ? <p className="rp-rise mt-2 text-xs font-semibold text-amber-200">{f.commitDone}</p> : null}

        <div className="mt-4 rounded-2xl border border-fuchsia-300/30 bg-fuchsia-400/10 p-3">
          <h3 className="text-sm font-extrabold text-fg">{f.practiceHeading}</h3>
          <p className="mt-0.5 text-xs text-muted">{f.practiceSub}</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {practiceMoments.map(({ m, i }) => (
              <button
                key={m.id}
                type="button"
                onClick={() => onPractice(i)}
                className="tap-target inline-flex items-center gap-1.5 rounded-xl border border-fuchsia-300/60 px-3 py-1.5 text-xs font-bold text-fuchsia-100 transition hover:bg-fuchsia-400/20"
              >
                <MessageCircle className="h-3.5 w-3.5" aria-hidden="true" />
                {m.practice?.kind === 'checkin' ? t('practiceCheckin', { name: m.practice.friendName }) : t('practiceRefuse', { name: m.practice?.friendName ?? '' })}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={openHelp}
            className="tap-target inline-flex items-center gap-2 rounded-xl border border-crisis-500/60 px-4 py-2 text-sm font-bold text-crisis-100 transition hover:bg-crisis-600/30"
          >
            <LifeBuoy className="h-4 w-4" aria-hidden="true" />
            {f.helpButton}
          </button>
          <button
            type="button"
            onClick={onNextPlayer}
            className="tap-target ml-auto inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-5 py-2.5 text-sm font-extrabold text-ink-950 shadow-lg shadow-teal-500/30 transition hover:brightness-110"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            {f.nextPlayer}
          </button>
        </div>
        <p className="mt-3 text-center text-[11px] text-subtle">{t('nothingSaved')}</p>
      </section>
    </div>
  );
}
