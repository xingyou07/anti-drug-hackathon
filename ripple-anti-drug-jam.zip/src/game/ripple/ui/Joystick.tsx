import { useRef, useState } from 'react';

interface Props {
  onMove: (x: number, y: number) => void;
  label: string;
}

const R = 46;

/** Bottom-left on purpose: the crisis button owns the bottom-right corner. */
export function Joystick({ onMove, label }: Props): JSX.Element {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const active = useRef<number | null>(null);

  const update = (e: React.PointerEvent): void => {
    const el = base.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (d > R) {
      dx = (dx / d) * R;
      dy = (dy / d) * R;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / R, -dy / R);
  };
  const end = (): void => {
    active.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };

  return (
    <div
      ref={base}
      role="group"
      aria-label={label}
      onPointerDown={(e) => {
        active.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e);
      }}
      onPointerMove={(e) => {
        if (active.current === e.pointerId) update(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
      className="pointer-events-auto relative h-32 w-32 touch-none select-none rounded-full border border-white/20 bg-white/10 backdrop-blur-sm"
    >
      <div
        className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full bg-gradient-to-br from-teal-300 to-cyan-500 shadow-lg shadow-teal-500/40"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}
