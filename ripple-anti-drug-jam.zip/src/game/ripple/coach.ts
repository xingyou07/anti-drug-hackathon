/**
 * Client side of the "try it in your own words" coach.
 *
 * The scripted coach is not just a fallback for a dead network: it is what runs
 * at a roadshow booth with bad wifi, and it must be good enough that the player
 * never feels the feature "broke". It uses cheap wording heuristics only. It
 * never names a substance, a stat, or a law.
 */
import { rippleContent } from '@/content';

export interface CoachTurn {
  role: 'friend' | 'you';
  text: string;
}

export interface CoachReply {
  source: 'gemini' | 'offline';
  friendReply: string;
  coachTip: string;
  strength: 1 | 2 | 3;
  crisis: boolean;
}

const CRISIS_RE =
  /\b(kill (my)?self|suicid\w*|end (it all|my life)|want to die|wanna die|don'?t want to (live|be here)|hurt(ing)? myself|self[- ]?harm\w*|no reason to live)\b/i;

const HEDGE_RE =
  /\b(maybe|later|next time|not now|i guess|i suppose|i don'?t know|not sure|idk|sorry|but|perhaps|might|another time|i have to|my (mum|mom|dad|parents)|i'?m busy|tired)\b/i;
const CLEAR_NO_RE = /\b(no|nope|nah|not for me|not interested|i'?m good|i'?ll pass|pass|i'?m out|don'?t want|won'?t|not doing|i'?m not)\b/i;
const ALT_RE = /\b(let'?s|how about|wanna|want to|shall we|come|kopi|makan|game|walk|movie|eat)\b/i;

const CARE_RE =
  /\b(worried|worry|care|here for you|i'?m here|noticed|notice|not judging|no judg\w*|want to talk|talk|listen|kopi|okay\?|ok\?|are you ok\w*|how are you|how'?re you|been off|been quiet|with you|come along|go with you)\b/i;
const BLAME_RE =
  /\b(you'?re (using|on|high|addicted|stupid|an idiot|pathetic)|stop (it|now|this)|what'?s wrong with you|you need to|you should|disappointed|idiot|stupid|loser|i know what you|admit it|how could you)\b/i;

function pick<T>(arr: readonly T[], seed: string): T {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return arr[h % arr.length] as T;
}

export function scriptedCoach(kind: 'refuse' | 'checkin', message: string): CoachReply {
  const msg = message.trim();
  if (CRISIS_RE.test(msg)) {
    return { source: 'offline', friendReply: '', coachTip: '', strength: 1, crisis: true };
  }
  const wc = msg.split(/\s+/).filter(Boolean).length;

  if (kind === 'refuse') {
    const hedge = HEDGE_RE.test(msg);
    const clear = CLEAR_NO_RE.test(msg);
    const alt = ALT_RE.test(msg);
    let strength: 1 | 2 | 3;
    if (clear && !hedge && wc <= 22) strength = 3;
    else if (clear) strength = 2;
    else strength = 1;

    if (strength === 3) {
      return {
        source: 'offline',
        friendReply: pick(
          ["...Okay lah. Your loss.", "Fine, fine. Don't need to be so serious.", "Okay okay. Won't ask again."],
          msg,
        ),
        coachTip: alt
          ? 'Short, clear, and you offered something else to do. That gives the moment a way to move on.'
          : 'Short and clear. That works. Next time, you can add "let\'s go do something else" to move the moment along.',
        strength,
        crisis: false,
      };
    }
    if (strength === 2) {
      return {
        source: 'offline',
        friendReply: pick(["Come on, one time only. Don't be like that.", "You sure? Nobody's going to know."], msg),
        coachTip: hedge
          ? 'Your no is in there, but "but" or "maybe" gives the other person something to push against. Try dropping the excuse: "No, I\'m good."'
          : 'Your no is clear, but it runs long. Two or three words is usually enough, and easier to repeat if they ask again.',
        strength,
        crisis: false,
      };
    }
    return {
      source: 'offline',
      friendReply: pick(["So is that a yes or no? Just try lah.", "Later when? Just do it now."], msg),
      coachTip: 'That could sound like a "maybe", and a "maybe" gets asked again. Start with the word "no", then stop. For example: "No, I\'m good."',
      strength,
      crisis: false,
    };
  }

  // check-in
  const blame = BLAME_RE.test(msg);
  const care = CARE_RE.test(msg);
  let strength: 1 | 2 | 3;
  if (blame) strength = 1;
  else if (care && wc >= 4) strength = 3;
  else strength = 2;

  if (strength === 3) {
    return {
      source: 'offline',
      friendReply: pick(
        ["...Thanks. It's been a lot lately. I didn't know how to say it.", "Yeah. I'm not great. Okay, maybe kopi."],
        msg,
      ),
      coachTip: 'You led with care and left room for them to talk. You don\'t have to fix anything: showing up and listening is the whole job at this stage.',
      strength,
      crisis: false,
    };
  }
  if (strength === 2) {
    return {
      source: 'offline',
      friendReply: pick(["I'm fine. Why are you asking?", "Nothing. Don't worry about it."], msg),
      coachTip: 'A good start. Try naming what you noticed and saying you\'re not judging, e.g. "I\'ve noticed you\'ve been quiet. I\'m here if you want to talk."',
      strength,
      crisis: false,
    };
  }
  return {
    source: 'offline',
    friendReply: pick(["Wow. Forget it. Leave me alone.", "You don't know anything about me."], msg),
    coachTip: 'That may come across as blame, and people shut down when they feel judged. Try starting with what you\'ve noticed and that you care, without guessing at the reason.',
    strength,
    crisis: false,
  };
}

interface ServerOk {
  source: 'gemini';
  friendReply: string;
  coachTip: string;
  strength: 1 | 2 | 3;
}

function isServerOk(x: unknown): x is ServerOk {
  if (typeof x !== 'object' || x === null) return false;
  const o = x as Record<string, unknown>;
  return typeof o['friendReply'] === 'string' && typeof o['coachTip'] === 'string' && (o['strength'] === 1 || o['strength'] === 2 || o['strength'] === 3);
}

/**
 * Exception to the original "zero network requests" constraint, approved by the
 * project owner for this feature only: the typed line goes to /api/coach on this
 * app's own server, which calls Gemini. Nothing else in the app fetches.
 */
export async function askCoach(args: {
  momentId: string;
  kind: 'refuse' | 'checkin';
  friendName: string;
  history: CoachTurn[];
  message: string;
}): Promise<CoachReply> {
  const message = args.message.slice(0, rippleContent.practice.maxChars);
  // Crisis language never waits on a network round trip.
  if (CRISIS_RE.test(message)) return scriptedCoach(args.kind, message);

  const ctl = new AbortController();
  const timer = window.setTimeout(() => ctl.abort(), 12_000);
  try {
    const res = await fetch('/api/coach', {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ momentId: args.momentId, history: args.history.slice(-6), message }),
    });
    if (!res.ok) throw new Error('coach-http');
    const data: unknown = await res.json();
    if (typeof data === 'object' && data !== null && (data as { crisis?: unknown }).crisis === true) {
      return { source: 'gemini', friendReply: '', coachTip: '', strength: 1, crisis: true };
    }
    if (!isServerOk(data)) throw new Error('coach-shape');
    return { ...data, crisis: false };
  } catch {
    return scriptedCoach(args.kind, message);
  } finally {
    window.clearTimeout(timer);
  }
}
