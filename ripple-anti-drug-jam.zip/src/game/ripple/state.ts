import { rippleContent } from '@/content';
import type { RippleChoice, RippleEffect, RippleMoment } from '@/content/types';

/**
 * Game flow state. Deliberately lives outside AppState (which is persisted):
 * nothing a player picks in Ripple is ever written to storage, and the whole
 * thing resets between players (jam requirement: unattended, reset per user).
 */
export type Screen = 'title' | 'pre' | 'explore' | 'arriving' | 'moment' | 'ripple' | 'post' | 'finale';
export type MStage = 'intro' | 'lines' | 'choose' | 'reaction' | 'unsafe';

export interface GameState {
  screen: Screen;
  current: number;
  stage: MStage;
  lineIdx: number;
  picked: string | null;
  finalChoices: Array<string | null>;
  /** How many times the player went back on an unsafe emergency choice. */
  redos: number[];
  pre: number[];
  post: number[];
  commit: string | null;
  practiceFor: number | null;
  practiced: number[];
}

export const moments: RippleMoment[] = [...rippleContent.moments].sort((a, b) => a.order - b.order);

export function initialGame(): GameState {
  return {
    screen: 'title',
    current: 0,
    stage: 'intro',
    lineIdx: 0,
    picked: null,
    finalChoices: moments.map(() => null),
    redos: moments.map(() => 0),
    pre: [],
    post: [],
    commit: null,
    practiceFor: null,
    practiced: [],
  };
}

export type GameAction =
  | { type: 'GO_PRE' }
  | { type: 'PRE_DONE'; values: number[] }
  | { type: 'REACHED' }
  | { type: 'ARRIVED' }
  | { type: 'ADVANCE' }
  | { type: 'CHOOSE'; choiceId: string }
  | { type: 'RETRY' }
  | { type: 'TO_RIPPLE' }
  | { type: 'NEXT' }
  | { type: 'JUMP'; index: number }
  | { type: 'POST_DONE'; values: number[] }
  | { type: 'COMMIT'; id: string }
  | { type: 'PRACTICE_OPEN'; index: number }
  | { type: 'PRACTICE_CLOSE'; done: boolean }
  | { type: 'RESET' };

export function findChoice(m: RippleMoment | undefined, id: string | null): RippleChoice | undefined {
  return m?.choices.find((c) => c.id === id);
}

export function gameReducer(s: GameState, a: GameAction): GameState {
  const m = moments[s.current];
  switch (a.type) {
    case 'GO_PRE':
      return { ...initialGame(), screen: 'pre' };
    case 'PRE_DONE':
      return { ...s, pre: a.values, screen: 'explore', current: 0 };
    case 'REACHED':
      return s.screen === 'explore' ? { ...s, screen: 'arriving' } : s;
    case 'ARRIVED':
      return s.screen === 'arriving' ? { ...s, screen: 'moment', stage: 'intro', lineIdx: 0, picked: null } : s;
    case 'ADVANCE': {
      if (s.screen !== 'moment' || !m) return s;
      if (s.stage === 'intro') return { ...s, stage: m.lines.length ? 'lines' : 'choose', lineIdx: 0 };
      if (s.stage === 'lines') {
        return s.lineIdx + 1 < m.lines.length ? { ...s, lineIdx: s.lineIdx + 1 } : { ...s, stage: 'choose', lineIdx: 0 };
      }
      if (s.stage === 'reaction') {
        const c = findChoice(m, s.picked);
        if (!c) return s;
        if (s.lineIdx + 1 < c.reaction.length) return { ...s, lineIdx: s.lineIdx + 1 };
        return c.redo ? { ...s, stage: 'unsafe' } : s;
      }
      return s;
    }
    case 'CHOOSE': {
      if (s.screen !== 'moment' || s.stage !== 'choose' || !m) return s;
      const c = findChoice(m, a.choiceId);
      if (!c) return s;
      const finalChoices = [...s.finalChoices];
      if (!c.redo) finalChoices[s.current] = c.id;
      return { ...s, stage: 'reaction', lineIdx: 0, picked: c.id, finalChoices };
    }
    case 'RETRY': {
      const redos = [...s.redos];
      redos[s.current] = (redos[s.current] ?? 0) + 1;
      return { ...s, stage: 'choose', picked: null, lineIdx: 0, redos };
    }
    case 'TO_RIPPLE':
      return s.screen === 'moment' ? { ...s, screen: 'ripple' } : s;
    case 'NEXT': {
      const next = s.current + 1;
      if (next >= moments.length) return { ...s, screen: 'post', practiceFor: null };
      return { ...s, screen: 'explore', current: next, stage: 'intro', lineIdx: 0, picked: null, practiceFor: null };
    }
    case 'JUMP':
      return { ...s, screen: 'explore', current: a.index };
    case 'POST_DONE':
      return { ...s, post: a.values, screen: 'finale' };
    case 'COMMIT':
      return { ...s, commit: a.id };
    case 'PRACTICE_OPEN':
      return { ...s, practiceFor: a.index };
    case 'PRACTICE_CLOSE':
      return {
        ...s,
        practiceFor: null,
        practiced: a.done && s.practiceFor !== null && !s.practiced.includes(s.practiceFor) ? [...s.practiced, s.practiceFor] : s.practiced,
      };
    case 'RESET':
      return initialGame();
  }
}

const SCORE: Record<RippleEffect, number> = { steady: 1, wobble: 0, strain: -1 };

/**
 * Who your final choices reached, and how. Averaged across the scenes each
 * person appears in; ties round toward "shaken" so nobody is labelled steady
 * on thin evidence. People not touched by any scene stay null (no halo).
 */
export function aggregateMoods(finalChoices: Array<string | null>): Record<string, RippleEffect | null> {
  const acc: Record<string, number[]> = {};
  finalChoices.forEach((cid, i) => {
    const c = findChoice(moments[i], cid);
    if (!c) return;
    for (const r of c.ripple) (acc[r.person] ??= []).push(SCORE[r.effect]);
  });
  const out: Record<string, RippleEffect | null> = {};
  for (const id of Object.keys(rippleContent.people)) {
    const v = acc[id];
    if (!v || v.length === 0) {
      out[id] = null;
      continue;
    }
    const avg = v.reduce((x, y) => x + y, 0) / v.length;
    out[id] = avg >= 0.5 ? 'steady' : avg <= -0.5 ? 'strain' : 'wobble';
  }
  return out;
}
