import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { MapPin } from 'lucide-react';
import { PlaceholderChip } from '@/components/PlaceholderChip';
import { appMeta, rippleContent } from '@/content';
import type { RippleLine } from '@/content/types';
import { usePrefersReducedMotion } from '@/lib/motion';
import { useAppState } from '@/state/AppStateContext';
import { useCrisisSheet } from '@/state/CrisisSheetContext';
import { RippleEngine } from './engine/RippleEngine';
import type { HudInfo, PovMode } from './engine/RippleEngine';
import { aggregateMoods, findChoice, gameReducer, initialGame, moments } from './state';
import { ConfidenceCheck } from './ui/ConfidenceCheck';
import { Finale } from './ui/Finale';
import { Hud } from './ui/Hud';
import { MomentOverlay } from './ui/MomentOverlay';
import { PracticeCoach } from './ui/PracticeCoach';
import { RipplePanel } from './ui/RipplePanel';
import { TitleScreen } from './ui/TitleScreen';
import { t } from './ui/labels';

/** Unattended-kiosk reset (jam requirement): quiet for this long, then a countdown, then back to the title. */
const GRACE_SECONDS = 15;

/** Booth operators can tune the quiet period with ?idle=SECONDS (10-600). Default 75. */
function idleSeconds(): number {
  const n = Number(new URLSearchParams(window.location.search).get('idle'));
  return Number.isFinite(n) && n >= 10 && n <= 600 ? n : 75;
}

type EngineState = 'loading' | 'ready' | 'none';

declare global {
  interface Window {
    __ripple?: { engine: () => RippleEngine | null };
  }
}

/** Story mode: same moments, same choices, no 3D. Used when WebGL is missing or the context is lost. */
function StoryMap({ current, onGo }: { current: number; onGo: () => void }): JSX.Element {
  const m = moments[current];
  if (!m) return <div />;
  return (
    <div className="absolute inset-0 z-10 flex items-end justify-center p-4 sm:items-center">
      <section className="rp-pop w-full max-w-md rounded-3xl border border-white/15 bg-ink-950/85 p-5 shadow-2xl backdrop-blur-md" aria-labelledby="story-h">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-fuchsia-300">{t('momentOf', { n: current + 1, m: moments.length })}</p>
        <h2 id="story-h" className="mt-1 text-2xl font-black">{m.title}</h2>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-muted">
          <MapPin className="h-4 w-4 text-teal-300" aria-hidden="true" />
          {m.place} · {m.timeLabel}
        </p>
        <button
          type="button"
          autoFocus
          onClick={onGo}
          className="tap-target mt-4 w-full rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-5 py-3 text-base font-extrabold text-ink-950 shadow-lg shadow-teal-500/30"
        >
          {t('nextMoment')}
        </button>
      </section>
    </div>
  );
}

export function RippleGame(): JSX.Element {
  const { state } = useAppState();
  const { isOpen: helpOpen } = useCrisisSheet();
  const sysReduce = usePrefersReducedMotion();
  const reduceMotion = sysReduce || state.settings.reduceMotion === 'always';

  const [g, dispatch] = useReducer(gameReducer, undefined, initialGame);
  const gRef = useRef(g);
  gRef.current = g;
  const helpRef = useRef(helpOpen);
  helpRef.current = helpOpen;

  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<RippleEngine | null>(null);
  const [engineState, setEngineState] = useState<EngineState>('loading');
  const [pov, setPov] = useState<PovMode>('third');
  const [hud, setHud] = useState<HudInfo>({ index: null, distance: 0, bearing: 0 });
  const [idleLeft, setIdleLeft] = useState<number | null>(null);
  const idleLimit = useMemo(idleSeconds, []);
  const lastActive = useRef(Date.now());
  const touch = useMemo(() => typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches, []);

  /* ---------------------------- engine lifecycle ---------------------------- */
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let eng: RippleEngine | null = null;
    let cancelled = false;
    let onLost: (() => void) | null = null;

    // One frame late so the shell paints ("Building the neighbourhood…") before
    // the procedural textures block the main thread.
    const raf = requestAnimationFrame(() => {
      if (cancelled) return;
      try {
        const lowGfx = new URLSearchParams(window.location.search).has('lowgfx') || (navigator.hardwareConcurrency ?? 8) <= 2;
        eng = new RippleEngine(
          host,
          moments.map((m) => ({ id: m.id, landmark: m.landmark, npcs: m.npcs, title: m.title, timeLabel: m.timeLabel, pressure: m.pressure })),
          {
            onReachMoment: () => dispatch({ type: 'REACHED' }),
            onArrived: () => dispatch({ type: 'ARRIVED' }),
            onPov: setPov,
            onHud: (h) =>
              setHud((p) => (p.index === h.index && Math.round(p.distance) === Math.round(h.distance) && Math.abs(p.bearing - h.bearing) < 0.04 ? p : h)),
            onLowGfx: () => undefined,
          },
          { reduceMotion, lowGfx },
        );
        engineRef.current = eng;
        setEngineState('ready');
        const dying = eng;
        onLost = () => {
          host.removeEventListener('webglcontextlost', onLost as () => void, true);
          dying.dispose();
          if (engineRef.current === dying) engineRef.current = null;
          setEngineState('none');
          if (gRef.current.screen === 'arriving') dispatch({ type: 'ARRIVED' });
        };
        host.addEventListener('webglcontextlost', onLost, true);
      } catch {
        engineRef.current = null;
        setEngineState('none');
      }
    });

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      if (onLost) host.removeEventListener('webglcontextlost', onLost, true);
      eng?.dispose();
      engineRef.current = null;
    };
    // The engine is built once; motion preference is read at construction.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    window.__ripple = { engine: () => engineRef.current };
    return () => {
      delete window.__ripple;
    };
  }, []);

  /* ------------------------ game state -> 3D world sync ------------------------ */
  useEffect(() => {
    const eng = engineRef.current;
    const m = moments[g.current];
    switch (g.screen) {
      case 'title':
        eng?.reset();
        break;
      case 'pre':
        break;
      case 'explore':
        eng?.endRipple();
        eng?.resumeExplore();
        eng?.setInputLocked(false);
        eng?.setActiveMoment(g.current);
        break;
      case 'arriving':
        eng?.setInputLocked(true);
        if (eng) eng.beginMoment(g.current);
        else dispatch({ type: 'ARRIVED' });
        break;
      case 'moment':
        eng?.setInputLocked(true);
        break;
      case 'ripple': {
        eng?.setInputLocked(true);
        const c = findChoice(m, g.picked);
        if (eng && c) eng.playRipple(g.current, c.ripple.map((r) => ({ person: r.person, effect: r.effect })), c.effect);
        break;
      }
      case 'post':
        eng?.setInputLocked(true);
        eng?.endRipple();
        eng?.enterFinale(aggregateMoods(g.finalChoices));
        break;
      case 'finale':
        break;
    }
    // finalChoices / picked are read at the moment the screen changes; re-running on them would replay the ripple.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [g.screen, g.current, engineState]);

  // Whoever is talking gets the mouth animation and the camera's attention.
  useEffect(() => {
    const m = moments[g.current];
    let who: string | null = null;
    if (g.screen === 'moment' && m && m.format === 'face') {
      let line: RippleLine | undefined;
      if (g.stage === 'lines') line = m.lines[g.lineIdx];
      else if (g.stage === 'reaction') line = findChoice(m, g.picked)?.reaction[g.lineIdx];
      if (line && line.who !== 'narrator') who = line.who;
    }
    engineRef.current?.setSpeaker(who);
  }, [g.screen, g.stage, g.lineIdx, g.picked, g.current]);

  /* ------------------------------- idle reset ------------------------------- */
  const doReset = useCallback(() => {
    engineRef.current?.reset();
    dispatch({ type: 'RESET' });
    setIdleLeft(null);
    lastActive.current = Date.now();
  }, []);

  useEffect(() => {
    const bump = (): void => {
      lastActive.current = Date.now();
    };
    const evs = ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart'] as const;
    evs.forEach((e) => window.addEventListener(e, bump, { passive: true }));
    const iv = window.setInterval(() => {
      if (gRef.current.screen === 'title' || helpRef.current || document.hidden) {
        lastActive.current = Date.now();
        setIdleLeft(null);
        return;
      }
      const idle = (Date.now() - lastActive.current) / 1000;
      if (idle < idleLimit) {
        setIdleLeft((p) => (p === null ? p : null));
        return;
      }
      const left = idleLimit + GRACE_SECONDS - idle;
      if (left <= 0) doReset();
      else setIdleLeft(Math.ceil(left));
    }, 1000);
    return () => {
      evs.forEach((e) => window.removeEventListener(e, bump));
      window.clearInterval(iv);
    };
  }, [doReset, idleLimit]);

  /* -------------------------------- handlers -------------------------------- */
  const onAdvance = useCallback(() => dispatch({ type: 'ADVANCE' }), []);
  const onChoose = useCallback((id: string) => dispatch({ type: 'CHOOSE', choiceId: id }), []);
  const onRetry = useCallback(() => {
    engineRef.current?.resumeMoment();
    dispatch({ type: 'RETRY' });
  }, []);
  const onToRipple = useCallback(() => dispatch({ type: 'TO_RIPPLE' }), []);
  const onPre = useCallback((values: number[]) => dispatch({ type: 'PRE_DONE', values }), []);
  const onPost = useCallback((values: number[]) => dispatch({ type: 'POST_DONE', values }), []);

  const moment = moments[g.current];
  const choice = findChoice(moment, g.picked);
  const hasEngine = engineState === 'ready';
  const practiceMoment = g.practiceFor !== null ? moments[g.practiceFor] : undefined;
  const moods = useMemo(() => aggregateMoods(g.finalChoices), [g.finalChoices]);

  return (
    <div data-screen={g.screen} data-stage={g.stage} data-moment={g.current} className="relative flex h-[calc(100dvh-4rem)] min-h-[34rem] w-full flex-col overflow-hidden bg-ink-950 sm:rounded-3xl sm:border sm:border-white/10">
      <div className="relative flex-1 overflow-hidden">
        {/* Story-mode backdrop; the canvas covers it when WebGL is running. */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-ink-900 to-fuchsia-950" aria-hidden="true" />
        <div ref={hostRef} className="absolute inset-0" />

        {engineState === 'loading' ? (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink-950" role="status">
            <p className="rp-float text-sm font-semibold text-muted">{t('loading')}</p>
          </div>
        ) : null}

        {g.screen === 'title' ? <TitleScreen hasEngine={engineState !== 'none'} onStart={() => dispatch({ type: 'GO_PRE' })} /> : null}
        {g.screen === 'pre' ? <ConfidenceCheck mode="pre" onDone={onPre} /> : null}

        {g.screen === 'explore' ? (
          <>
            <Hud
              hud={hud}
              current={g.current}
              pov={pov}
              touch={touch}
              hasEngine={hasEngine}
              onTogglePov={() => engineRef.current?.togglePov()}
              onFastTravel={() => engineRef.current?.fastTravel(gRef.current.current)}
              onJoystick={(x, y) => engineRef.current?.setJoystick(x, y)}
            />
            {hasEngine ? null : <StoryMap current={g.current} onGo={() => dispatch({ type: 'REACHED' })} />}
          </>
        ) : null}

        {(g.screen === 'moment' || g.screen === 'arriving') && moment && g.screen === 'moment' ? (
          <MomentOverlay moment={moment} g={g} onAdvance={onAdvance} onChoose={onChoose} onRetry={onRetry} onToRipple={onToRipple} />
        ) : null}

        {g.screen === 'ripple' && moment && choice ? (
          <RipplePanel
            moment={moment}
            choice={choice}
            isLast={g.current === moments.length - 1}
            practiced={g.practiced.includes(g.current)}
            onPractice={() => dispatch({ type: 'PRACTICE_OPEN', index: g.current })}
            onNext={() => dispatch({ type: 'NEXT' })}
          />
        ) : null}

        {g.screen === 'post' ? <ConfidenceCheck mode="post" before={g.pre} onDone={onPost} /> : null}

        {g.screen === 'finale' ? (
          <Finale
            moods={moods}
            pre={g.pre}
            post={g.post}
            commit={g.commit}
            onCommit={(id) => dispatch({ type: 'COMMIT', id })}
            onPractice={(i) => dispatch({ type: 'PRACTICE_OPEN', index: i })}
            onNextPlayer={doReset}
          />
        ) : null}

        {practiceMoment?.practice ? (
          <PracticeCoach
            key={practiceMoment.id}
            momentId={practiceMoment.id}
            practice={practiceMoment.practice}
            onClose={(done) => dispatch({ type: 'PRACTICE_CLOSE', done })}
          />
        ) : null}

        {idleLeft !== null ? (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink-950/85 p-6 backdrop-blur-sm" role="alertdialog" aria-labelledby="idle-h">
            <div className="rp-pop max-w-sm rounded-3xl border border-white/15 bg-ink-800 p-6 text-center shadow-2xl">
              <h2 id="idle-h" className="text-2xl font-black">{rippleContent.labels['stillThere']}</h2>
              <p className="mt-1 text-sm text-muted">{rippleContent.labels['stillThereSub']}</p>
              <p className="mt-2 text-4xl font-black tabular-nums text-teal-300" aria-live="polite">{idleLeft}</p>
              <button
                type="button"
                autoFocus
                onClick={() => {
                  lastActive.current = Date.now();
                  setIdleLeft(null);
                }}
                className="tap-target mt-4 rounded-2xl bg-gradient-to-r from-teal-300 to-cyan-400 px-6 py-3 text-base font-extrabold text-ink-950"
              >
                {rippleContent.labels['imHere']}
              </button>
            </div>
          </div>
        ) : null}
      </div>

      {/* Constraints 4 and 5: the disclaimer and the demo-content chip stay on screen the whole time. */}
      <footer className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 border-t border-white/10 bg-ink-950 px-3 py-1.5 text-center text-[10px] leading-snug text-subtle">
        <PlaceholderChip status={rippleContent.status} />
        <span>{appMeta.disclaimer}</span>
      </footer>
    </div>
  );
}
