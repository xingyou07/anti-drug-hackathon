import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Sparkles } from 'lucide-react';
import type { Direction, StationDef } from './types';

interface Props {
  onMoveStart: (direction: Direction) => void;
  onMoveEnd: () => void;
  onInteract: () => void;
  activeStation: StationDef | null;
}

export function VirtualControls({
  onMoveStart,
  onMoveEnd,
  onInteract,
  activeStation,
}: Props): JSX.Element {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-4 px-4 flex items-end justify-between z-20 select-none">
      {/* Directional Pad */}
      <div className="pointer-events-auto flex flex-col items-center gap-1 bg-ink-950/80 backdrop-blur-md p-2 rounded-2xl border border-line shadow-2xl">
        <button
          type="button"
          onPointerDown={() => onMoveStart('up')}
          onPointerUp={onMoveEnd}
          onPointerLeave={onMoveEnd}
          className="tap-target h-12 w-12 rounded-xl bg-ink-900 border border-line flex items-center justify-center text-fg active:bg-accent-500 active:text-ink-950 transition"
          aria-label="Move Up"
        >
          <ArrowUp className="h-5 w-5" />
        </button>
        <div className="flex gap-1">
          <button
            type="button"
            onPointerDown={() => onMoveStart('left')}
            onPointerUp={onMoveEnd}
            onPointerLeave={onMoveEnd}
            className="tap-target h-12 w-12 rounded-xl bg-ink-900 border border-line flex items-center justify-center text-fg active:bg-accent-500 active:text-ink-950 transition"
            aria-label="Move Left"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            onPointerDown={() => onMoveStart('down')}
            onPointerUp={onMoveEnd}
            onPointerLeave={onMoveEnd}
            className="tap-target h-12 w-12 rounded-xl bg-ink-900 border border-line flex items-center justify-center text-fg active:bg-accent-500 active:text-ink-950 transition"
            aria-label="Move Down"
          >
            <ArrowDown className="h-5 w-5" />
          </button>
          <button
            type="button"
            onPointerDown={() => onMoveStart('right')}
            onPointerUp={onMoveEnd}
            onPointerLeave={onMoveEnd}
            className="tap-target h-12 w-12 rounded-xl bg-ink-900 border border-line flex items-center justify-center text-fg active:bg-accent-500 active:text-ink-950 transition"
            aria-label="Move Right"
          >
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Action / Enter Station Button */}
      <div className="pointer-events-auto flex flex-col items-end gap-2">
        <button
          type="button"
          disabled={!activeStation}
          onClick={onInteract}
          className={`tap-target flex items-center gap-2 px-6 py-4 rounded-2xl font-bold shadow-2xl transition border ${
            activeStation
              ? 'bg-accent-500 text-ink-950 border-accent-400 scale-105 animate-pulse cursor-pointer'
              : 'bg-ink-950/80 text-subtle border-line cursor-not-allowed opacity-50'
          }`}
        >
          <Sparkles className="h-5 w-5" />
          <span>{activeStation ? `Enter ${activeStation.shortName}` : 'Walk to a Station'}</span>
        </button>
      </div>
    </div>
  );
}
