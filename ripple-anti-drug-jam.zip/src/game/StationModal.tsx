import { useState, useEffect } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  PhoneCall,
  Maximize2,
  Minimize2,
  Pin,
  PinOff,
} from 'lucide-react';
import type { StationDef } from './types';
import { UrgeSurf } from '@/features/urgesurf/UrgeSurf';
import { Breathing } from '@/features/breathing/Breathing';
import { Grounding } from '@/features/grounding/Grounding';
import { RefusalScripts } from '@/features/refusal/RefusalScripts';
import { FakeCall } from '@/features/fakecall/FakeCall';
import { LegalExplainer } from '@/pages/recovery/LegalExplainer';
import { TriggerZonesPreview } from '@/features/recovery/TriggerZonesPreview';
import { RouletteEngine } from '@/features/youth/RouletteEngine';
import { PressureScenarios } from '@/features/youth/PressureScenarios';
import { RealityCheck } from '@/features/youth/RealityCheck';
import { LiteracyChallenge } from '@/features/youth/LiteracyChallenge';
import { SomeoneUsing } from '@/features/youth/SomeoneUsing';
import { Settings } from '@/pages/shared/Settings';
import { Privacy } from '@/pages/shared/Privacy';
import { CrisisResourceRow } from '@/components/CrisisResourceRow';
import { crisisResources } from '@/content';
import type { CrisisResource } from '@/content/types';
import { playCloseSound } from './sound';

interface Props {
  station: StationDef;
  stations: StationDef[];
  onClose: () => void;
  onSelectStation: (station: StationDef) => void;
  onOpenCrisisSheet: () => void;
  isInsideCircle?: boolean;
  isPinned?: boolean;
  onTogglePinned?: () => void;
}

export function StationModal({
  station,
  stations,
  onClose,
  onSelectStation,
  onOpenCrisisSheet,
  isInsideCircle = true,
  isPinned = false,
  onTogglePinned,
}: Props): JSX.Element {
  // Option to maximize from docked side terminal to full-screen
  const [isMaximized, setIsMaximized] = useState(false);

  // Optional ESC key to close if user wants to close manually
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        playCloseSound();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const currentIndex = stations.findIndex((s) => s.id === station.id);
  const prevStation = stations[(currentIndex - 1 + stations.length) % stations.length];
  const nextStation = stations[(currentIndex + 1) % stations.length];

  const handleClose = () => {
    playCloseSound();
    onClose();
  };

  const renderContent = () => {
    switch (station.componentKey) {
      case 'urge-surf':
        return <UrgeSurf />;
      case 'breathe':
        return <Breathing />;
      case 'grounding':
        return <Grounding />;
      case 'scripts':
        return <RefusalScripts backTo="/recovery" />;
      case 'fake-call':
        return <FakeCall />;
      case 'legal':
        return <LegalExplainer />;
      case 'trigger-zones':
        return <TriggerZonesPreview />;
      case 'roulette':
        return (
          <RouletteEngine
            onNavigateToScripts={() => {
              const scriptsSt = stations.find((s) => s.id === 'scripts' || s.id === 'pressure');
              if (scriptsSt) onSelectStation(scriptsSt);
            }}
            onNavigateToSomeone={() => {
              const someoneSt = stations.find((s) => s.id === 'someone');
              if (someoneSt) onSelectStation(someoneSt);
            }}
          />
        );
      case 'pressure':
        return <PressureScenarios />;
      case 'reality':
        return <RealityCheck />;
      case 'literacy':
        return <LiteracyChallenge />;
      case 'someone':
        return <SomeoneUsing />;
      case 'crisis':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold tracking-tight text-fg">Emergency & Crisis Lines</h2>
              <button
                type="button"
                onClick={onOpenCrisisSheet}
                className="tap-target flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-crisis-500 text-ink-950 font-bold text-xs"
              >
                <PhoneCall className="h-4 w-4" />
                <span>Open Full Crisis Sheet</span>
              </button>
            </div>
            <p className="text-sm text-muted">
              Singapore verified helplines. No personal data or call history leaves your device.
            </p>
            <ul className="space-y-2.5">
              {crisisResources.resources.map((res: CrisisResource) => (
                <CrisisResourceRow key={res.id} resource={res} />
              ))}
            </ul>
          </div>
        );
      case 'settings':
        return <Settings />;
      case 'privacy':
        return <Privacy />;
      default:
        return (
          <div className="p-6 text-center space-y-2 text-fg">
            <p className="font-bold">{station.title}</p>
            <p className="text-sm text-muted">{station.description}</p>
          </div>
        );
    }
  };

  const modalContent = (
    <div className={`flex flex-col bg-ink-950 border border-line shadow-2xl overflow-hidden h-full ${
      isMaximized ? 'w-full max-w-2xl max-h-[92vh] rounded-2xl' : 'w-full'
    }`}>
      {/* Terminal Header */}
      <div className="flex items-center justify-between px-3 sm:px-4 py-3 border-b border-line bg-ink-900/95 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className="h-8 w-8 rounded-lg flex items-center justify-center font-bold text-base border shrink-0"
            style={{
              backgroundColor: `${station.colorHex}22`,
              borderColor: station.colorHex,
              color: station.colorHex,
            }}
          >
            <Sparkles className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm sm:text-base tracking-tight text-fg truncate">
                {station.title}
              </h2>
              <span className="text-[10px] uppercase font-mono px-2 py-0.2 rounded-full border border-line text-subtle shrink-0">
                {station.tag}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              {isInsideCircle ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  In Circle · walk out to close
                </span>
              ) : isPinned ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-400">
                  <Pin className="h-2.5 w-2.5" />
                  Pinned open
                </span>
              ) : (
                <span className="text-[10px] text-muted truncate">{station.description}</span>
              )}
            </div>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-1 shrink-0 ml-2">
          {/* Pin open toggle */}
          {onTogglePinned ? (
            <button
              type="button"
              onClick={onTogglePinned}
              className={`tap-target rounded-lg border p-1.5 transition ${
                isPinned
                  ? 'border-accent-400 bg-accent-500/20 text-accent-400'
                  : 'border-line bg-ink-900 text-muted hover:text-fg'
              }`}
              title={isPinned ? 'Unpin: Auto-close when walking out of circle' : 'Pin: Keep segment open while walking'}
              aria-label={isPinned ? 'Unpin station terminal' : 'Pin station terminal'}
            >
              {isPinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
            </button>
          ) : null}

          {/* Maximize / Dock toggle */}
          <button
            type="button"
            onClick={() => setIsMaximized((v) => !v)}
            className="tap-target rounded-lg border border-line bg-ink-900 p-1.5 text-muted hover:text-fg hover:bg-ink-800 transition hidden sm:flex"
            title={isMaximized ? 'Dock to side' : 'Maximize to fullscreen'}
            aria-label={isMaximized ? 'Dock station terminal' : 'Maximize station terminal'}
          >
            {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>

          {/* Close button */}
          <button
            type="button"
            onClick={handleClose}
            className="tap-target rounded-lg border border-line bg-ink-900 p-1.5 text-muted hover:text-fg hover:bg-ink-800 transition"
            title="Close station terminal (or walk out of circle)"
            aria-label="Close station terminal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Terminal Body */}
      <div className="flex-1 overflow-y-auto p-3.5 sm:p-5 space-y-4">
        {renderContent()}
      </div>

      {/* Terminal Footer Bar */}
      <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 border-t border-line bg-ink-900/80 text-xs shrink-0">
        <div className="flex items-center gap-1.5">
          {prevStation ? (
            <button
              type="button"
              onClick={() => onSelectStation(prevStation)}
              className="tap-target flex items-center gap-1 px-2 py-1 rounded-lg border border-line bg-ink-900 text-muted hover:text-fg transition text-[11px]"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{prevStation.shortName}</span>
            </button>
          ) : null}
          {nextStation ? (
            <button
              type="button"
              onClick={() => onSelectStation(nextStation)}
              className="tap-target flex items-center gap-1 px-2 py-1 rounded-lg border border-line bg-ink-900 text-muted hover:text-fg transition text-[11px]"
            >
              <span className="hidden sm:inline">{nextStation.shortName}</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          ) : null}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-muted hidden sm:inline">
            Walk outside circle to auto-close
          </span>
          <button
            type="button"
            onClick={handleClose}
            className="tap-target px-3 py-1 rounded-lg bg-accent-500 text-ink-950 font-bold text-xs transition hover:bg-accent-400"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );

  // If maximized, render as centered full-screen modal
  if (isMaximized) {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-label={station.title}
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fade-in"
      >
        {modalContent}
      </div>
    );
  }

  // Otherwise docked side terminal (right on desktop, bottom sheet on mobile)
  return (
    <div
      role="region"
      aria-label={`${station.title} station terminal`}
      className="absolute top-0 right-0 bottom-0 z-30 w-full sm:w-[460px] md:w-[500px] lg:w-[540px] max-sm:h-[68%] max-sm:top-auto max-sm:bottom-0 flex flex-col shadow-2xl transition-all duration-300 animate-slide-in-right overflow-hidden pointer-events-auto border-l max-sm:border-l-0 max-sm:border-t border-line"
    >
      {modalContent}
    </div>
  );
}
