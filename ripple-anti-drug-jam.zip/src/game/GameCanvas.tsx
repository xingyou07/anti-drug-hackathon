import { useEffect, useRef } from 'react';
import type { PlayerState, StationDef } from './types';
import { playStepSound } from './sound';

interface Props {
  stations: StationDef[];
  player: PlayerState;
  onPlayerChange: (updater: (prev: PlayerState) => PlayerState) => void;
  onInteract: (station: StationDef) => void;
  activeStation: StationDef | null;
  worldWidth?: number;
  worldHeight?: number;
}

const WORLD_WIDTH = 1200;
const WORLD_HEIGHT = 900;
const PLAYER_SPEED = 240; // pixels per second

export function GameCanvas({
  stations,
  player,
  onPlayerChange,
  onInteract,
  activeStation,
}: Props): JSX.Element {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const lastTimeRef = useRef<number>(performance.now());
  const animFrameRef = useRef<number | null>(null);
  const clickTargetRef = useRef<{ x: number; y: number; time: number } | null>(null);

  // Store player in ref for high-frequency game loop without re-triggering hooks
  const playerRef = useRef<PlayerState>(player);
  playerRef.current = player;

  const stationsRef = useRef(stations);
  stationsRef.current = stations;
  const activeStationRef = useRef(activeStation);
  activeStationRef.current = activeStation;
  const onInteractRef = useRef(onInteract);
  onInteractRef.current = onInteract;
  const onPlayerChangeRef = useRef(onPlayerChange);
  onPlayerChangeRef.current = onPlayerChange;

  // Responsive canvas resizing via ResizeObserver
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const updateSize = () => {
      const rect = container.getBoundingClientRect();
      const w = Math.max(320, Math.floor(rect.width));
      const h = Math.max(380, Math.floor(rect.height));
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
    };

    updateSize();
    const ro = new ResizeObserver(() => updateSize());
    ro.observe(container);
    window.addEventListener('resize', updateSize);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  // Keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      // Don't capture keys when typing in an input
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(key)) {
        keysRef.current[key] = true;
        // Cancel click-to-move target if manual key pressed
        playerRef.current.target = null;
        e.preventDefault();
      }

      if (['e', 'enter', ' '].includes(key)) {
        if (activeStationRef.current) {
          e.preventDefault();
          onInteractRef.current(activeStationRef.current);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (keysRef.current[key]) {
        keysRef.current[key] = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Main 60 FPS Game Loop
  useEffect(() => {
    let animTime = 0;
    let lastSyncTime = 0;

    const loop = (now: number) => {
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;
      animTime += dt;

      const p = playerRef.current;
      const keys = keysRef.current;

      let dx = 0;
      let dy = 0;

      if (keys['w'] || keys['arrowup']) dy -= 1;
      if (keys['s'] || keys['arrowdown']) dy += 1;
      if (keys['a'] || keys['arrowleft']) dx -= 1;
      if (keys['d'] || keys['arrowright']) dx += 1;

      // Handle Click-to-move target
      if (dx === 0 && dy === 0 && p.target) {
        const toTargetX = p.target.x - p.x;
        const toTargetY = p.target.y - p.y;
        const dist = Math.hypot(toTargetX, toTargetY);
        if (dist > 6) {
          dx = toTargetX / dist;
          dy = toTargetY / dist;
        } else {
          p.target = null;
        }
      }

      let isMoving = false;
      let newDir = p.direction;

      if (dx !== 0 || dy !== 0) {
        isMoving = true;
        // Normalize diagonal speed
        const length = Math.hypot(dx, dy);
        dx /= length;
        dy /= length;

        p.x = Math.max(25, Math.min(WORLD_WIDTH - 25, p.x + dx * PLAYER_SPEED * dt));
        p.y = Math.max(25, Math.min(WORLD_HEIGHT - 25, p.y + dy * PLAYER_SPEED * dt));

        if (Math.abs(dx) > Math.abs(dy)) {
          newDir = dx > 0 ? 'right' : 'left';
        } else {
          newDir = dy > 0 ? 'down' : 'up';
        }

        p.frame += dt * 10;
        playStepSound();
      }

      p.isMoving = isMoving;
      p.direction = newDir;

      // Sync player state up periodically (every 50ms when moving or on state change)
      if (now - lastSyncTime > 50 || !isMoving) {
        lastSyncTime = now;
        onPlayerChangeRef.current((prev) => {
          if (
            Math.abs(prev.x - p.x) > 0.5 ||
            Math.abs(prev.y - p.y) > 0.5 ||
            prev.direction !== p.direction ||
            prev.isMoving !== p.isMoving
          ) {
            return { ...p };
          }
          return prev;
        });
      }

      // Canvas Rendering
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          renderWorld(
            ctx,
            canvas,
            p,
            stationsRef.current,
            activeStationRef.current,
            animTime,
            clickTargetRef.current
          );
        }
      }

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  // Click or touch to move
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const screenX = (e.clientX - rect.left) * scaleX;
    const screenY = (e.clientY - rect.top) * scaleY;

    // Convert screen coordinates to world coordinates by camera offset
    const camera = getCameraOffset(canvas, playerRef.current);
    const worldX = screenX + camera.x;
    const worldY = screenY + camera.y;

    // Check if user clicked directly on a station
    for (const station of stations) {
      const dist = Math.hypot(worldX - station.x, worldY - station.y);
      if (dist <= station.radius) {
        onInteract(station);
        return;
      }
    }

    clickTargetRef.current = { x: worldX, y: worldY, time: performance.now() };
    playerRef.current.target = { x: worldX, y: worldY };
  };

  return (
    <div ref={containerRef} className="relative w-full h-full min-h-[420px] select-none overflow-hidden touch-none">
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full block cursor-crosshair"
      />
    </div>
  );
}

// Camera calculation
function getCameraOffset(canvas: HTMLCanvasElement, player: PlayerState) {
  let camX = player.x - canvas.width / 2;
  let camY = player.y - canvas.height / 2;
  camX = Math.max(0, Math.min(WORLD_WIDTH - canvas.width, camX));
  camY = Math.max(0, Math.min(WORLD_HEIGHT - canvas.height, camY));
  return { x: camX, y: camY };
}

// Master Render Function
function renderWorld(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  player: PlayerState,
  stations: StationDef[],
  activeStation: StationDef | null,
  animTime: number,
  clickTarget: { x: number; y: number; time: number } | null
) {
  const camera = getCameraOffset(canvas, player);

  ctx.save();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // Translate coordinate space by camera offset
  ctx.translate(-camera.x, -camera.y);

  // 1. World Terrain Background (Deep calming indigo sanctuary)
  ctx.fillStyle = '#0B0F14';
  ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

  // Soft grid dots
  ctx.fillStyle = 'rgba(43, 58, 75, 0.4)';
  const gridSize = 40;
  for (let x = 0; x < WORLD_WIDTH; x += gridSize) {
    for (let y = 0; y < WORLD_HEIGHT; y += gridSize) {
      ctx.beginPath();
      ctx.arc(x, y, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 2. Central Sanctuary Plaza (Cobblestone circular grounds)
  const centerX = 600;
  const centerY = 470;

  // Paths connecting stations to center
  ctx.strokeStyle = '#1A2431';
  ctx.lineWidth = 26;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  for (const st of stations) {
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    // Slight curvature or straight path
    const midX = (centerX + st.x) / 2;
    const midY = (centerY + st.y) / 2;
    ctx.quadraticCurveTo(midX + 10, midY, st.x, st.y);
    ctx.stroke();
  }

  // Inner cobblestone path line
  ctx.strokeStyle = '#243140';
  ctx.lineWidth = 14;
  for (const st of stations) {
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    const midX = (centerX + st.x) / 2;
    const midY = (centerY + st.y) / 2;
    ctx.quadraticCurveTo(midX + 10, midY, st.x, st.y);
    ctx.stroke();
  }

  // Central Koi Pond / Fountain
  const pondPulse = Math.sin(animTime * 2) * 4;
  ctx.fillStyle = 'rgba(13, 148, 136, 0.15)';
  ctx.beginPath();
  ctx.arc(centerX, centerY, 70 + pondPulse, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#111821';
  ctx.beginPath();
  ctx.arc(centerX, centerY, 56, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#2DD4BF';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Water ripples inside central fountain
  const r1 = ((animTime * 20) % 40) + 10;
  ctx.strokeStyle = `rgba(45, 212, 191, ${Math.max(0, 1 - r1 / 50)})`;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(centerX, centerY, r1, 0, Math.PI * 2);
  ctx.stroke();

  // Center symbol
  ctx.fillStyle = '#2DD4BF';
  ctx.font = 'bold 16px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('10%', centerX, centerY);

  // 3. Environmental Scenery (Glowing lanterns, benches, trees)
  renderDecorations(ctx, animTime);

  // 4. Click-to-move Ripple
  if (clickTarget && performance.now() - clickTarget.time < 800) {
    const elapsed = (performance.now() - clickTarget.time) / 800;
    ctx.save();
    ctx.strokeStyle = `rgba(45, 212, 191, ${1 - elapsed})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(clickTarget.x, clickTarget.y, elapsed * 30, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // 5. Stations
  for (const st of stations) {
    const isStationActive = activeStation?.id === st.id;
    renderStation(ctx, st, isStationActive, animTime);
  }

  // 6. Player Character
  renderPlayer(ctx, player);

  // 7. Overhead Interaction Bubble (if near station)
  if (activeStation) {
    renderInteractionBubble(ctx, activeStation, player, animTime);
  }

  ctx.restore();
}

// Draw trees, benches, glowing lanterns around the map
function renderDecorations(ctx: CanvasRenderingContext2D, animTime: number) {
  const lanterns = [
    { x: 460, y: 340 },
    { x: 740, y: 340 },
    { x: 460, y: 600 },
    { x: 740, y: 600 },
    { x: 200, y: 220 },
    { x: 1000, y: 220 },
    { x: 200, y: 720 },
    { x: 1000, y: 720 },
  ];

  for (const l of lanterns) {
    // Warm radial glow
    const flicker = Math.sin(animTime * 4 + l.x) * 3;
    const grad = ctx.createRadialGradient(l.x, l.y, 4, l.x, l.y, 42 + flicker);
    grad.addColorStop(0, 'rgba(245, 158, 11, 0.25)');
    grad.addColorStop(1, 'rgba(245, 158, 11, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(l.x, l.y, 42 + flicker, 0, Math.PI * 2);
    ctx.fill();

    // Lantern post
    ctx.fillStyle = '#1A2431';
    ctx.fillRect(l.x - 3, l.y - 6, 6, 16);
    // Lantern light source
    ctx.fillStyle = '#FDE4A8';
    ctx.beginPath();
    ctx.arc(l.x, l.y - 8, 4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Decorative trees/shrubs
  const trees = [
    { x: 120, y: 120 },
    { x: 1080, y: 120 },
    { x: 120, y: 780 },
    { x: 1080, y: 780 },
    { x: 600, y: 70 },
    { x: 600, y: 840 },
    { x: 440, y: 130 },
    { x: 760, y: 130 },
  ];

  for (const t of trees) {
    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.ellipse(t.x, t.y + 14, 22, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // Trunk
    ctx.fillStyle = '#334457';
    ctx.fillRect(t.x - 4, t.y + 4, 8, 12);

    // Foliage
    ctx.fillStyle = '#164E63'; // Dark teal
    ctx.beginPath();
    ctx.arc(t.x, t.y - 4, 20, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#0D9488'; // Vibrant teal
    ctx.beginPath();
    ctx.arc(t.x - 3, t.y - 8, 14, 0, Math.PI * 2);
    ctx.fill();
  }
}

// Render individual station pavilion
function renderStation(
  ctx: CanvasRenderingContext2D,
  st: StationDef,
  isActive: boolean,
  animTime: number
) {
  // 1. Aura / Radius Ring
  const pulse = Math.sin(animTime * 3 + st.x) * 4;
  ctx.save();

  if (isActive) {
    // Pulsing energetic glow when player is inside
    const grad = ctx.createRadialGradient(st.x, st.y, 10, st.x, st.y, st.radius + 15);
    grad.addColorStop(0, `${st.colorHex}44`);
    grad.addColorStop(0.7, `${st.colorHex}15`);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(st.x, st.y, st.radius + 15 + pulse, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = st.colorHex;
    ctx.lineWidth = 2.5;
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -animTime * 20;
    ctx.beginPath();
    ctx.arc(st.x, st.y, st.radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  } else {
    // Subtle idle base ring
    ctx.strokeStyle = 'rgba(43, 58, 75, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(st.x, st.y, st.radius, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 2. Station Pedestal Base (Hexagon / Circular platform)
  ctx.fillStyle = '#111821';
  ctx.beginPath();
  ctx.arc(st.x, st.y, 34, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = isActive ? st.colorHex : '#243140';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Floating station icon circle with levitation animation
  const floatY = Math.sin(animTime * 2.5 + st.x * 0.1) * 3;
  const iconY = st.y + floatY;

  // Icon glow
  ctx.fillStyle = `${st.colorHex}33`;
  ctx.beginPath();
  ctx.arc(st.x, iconY, 22, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = isActive ? st.colorHex : '#F2F6FA';
  ctx.font = 'bold 18px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Draw simple recognizable glyph or station initial
  const glyph = getStationGlyph(st.id);
  ctx.fillText(glyph, st.x, iconY);

  // 3. Station Name Badge Banner
  const badgeY = st.y + 42;
  ctx.font = '600 11px system-ui, -apple-system, sans-serif';
  const textWidth = ctx.measureText(st.shortName).width;
  const badgeWidth = textWidth + 18;
  const badgeHeight = 20;

  // Badge background
  ctx.fillStyle = '#0B0F14';
  ctx.beginPath();
  ctx.roundRect(st.x - badgeWidth / 2, badgeY - 10, badgeWidth, badgeHeight, 6);
  ctx.fill();

  ctx.strokeStyle = isActive ? st.colorHex : '#2B3A4B';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Badge text
  ctx.fillStyle = isActive ? '#FFFFFF' : '#AAB8C6';
  ctx.fillText(st.shortName, st.x, badgeY);

  ctx.restore();
}

function getStationGlyph(id: string): string {
  switch (id) {
    case 'urge-surf':
      return '🌊';
    case 'breathe':
      return '🌬️';
    case 'grounding':
      return '🌿';
    case 'scripts':
      return '🛡️';
    case 'fake-call':
      return '📞';
    case 'legal':
      return '⚖️';
    case 'trigger-zones':
      return '📍';
    case 'crisis':
      return '🚨';
    case 'roulette':
      return '🎲';
    case 'pressure':
      return '⚡';
    case 'reality':
      return '📊';
    case 'literacy':
      return '💡';
    case 'someone':
      return '🤝';
    case 'settings':
      return '⚙️';
    case 'privacy':
      return '🔒';
    default:
      return '◈';
  }
}

// Draw the Player Avatar
function renderPlayer(ctx: CanvasRenderingContext2D, player: PlayerState) {
  const { x, y, direction, isMoving, frame } = player;

  ctx.save();

  // 1. Soft Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
  ctx.beginPath();
  ctx.ellipse(x, y + 14, 13, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Walking bounce
  const bounce = isMoving ? Math.abs(Math.sin(frame)) * 3 : 0;
  const py = y - bounce;

  // 2. Body / Torso
  ctx.fillStyle = '#2DD4BF'; // Teal Jacket
  ctx.beginPath();
  ctx.roundRect(x - 9, py - 4, 18, 14, 4);
  ctx.fill();

  // Jacket zipper / inner detail
  ctx.strokeStyle = '#0B0F14';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(x, py - 4);
  ctx.lineTo(x, py + 10);
  ctx.stroke();

  // 3. Legs / Feet (Animated walk steps)
  ctx.fillStyle = '#111821';
  const legOffset = isMoving ? Math.sin(frame) * 4 : 0;
  // Left foot
  ctx.beginPath();
  ctx.roundRect(x - 8, py + 10 + (direction === 'down' || direction === 'up' ? legOffset : 0), 6, 5, 2);
  ctx.fill();
  // Right foot
  ctx.beginPath();
  ctx.roundRect(x + 2, py + 10 - (direction === 'down' || direction === 'up' ? legOffset : 0), 6, 5, 2);
  ctx.fill();

  // 4. Head
  ctx.fillStyle = '#FDE4A8'; // Soft skin tone
  ctx.beginPath();
  ctx.arc(x, py - 12, 8, 0, Math.PI * 2);
  ctx.fill();

  // 5. Hair
  ctx.fillStyle = '#1A2431'; // Dark hair
  ctx.beginPath();
  ctx.arc(x, py - 14, 8.5, Math.PI, Math.PI * 2);
  ctx.fill();

  // 6. Eyes based on direction
  ctx.fillStyle = '#0B0F14';
  if (direction === 'down') {
    ctx.fillRect(x - 4, py - 13, 2.5, 2.5);
    ctx.fillRect(x + 1.5, py - 13, 2.5, 2.5);
  } else if (direction === 'left') {
    ctx.fillRect(x - 6, py - 13, 2.5, 2.5);
  } else if (direction === 'right') {
    ctx.fillRect(x + 3.5, py - 13, 2.5, 2.5);
  }

  // 7. Backpack (visible from up, left, right)
  if (direction === 'up') {
    ctx.fillStyle = '#F59E0B'; // Amber backpack
    ctx.beginPath();
    ctx.roundRect(x - 7, py - 3, 14, 11, 3);
    ctx.fill();
  }

  ctx.restore();
}

// Overhead prompt bubble when standing near a station
function renderInteractionBubble(
  ctx: CanvasRenderingContext2D,
  station: StationDef,
  player: PlayerState,
  animTime: number
) {
  const bob = Math.sin(animTime * 4) * 3;
  const bubbleX = player.x;
  const bubbleY = player.y - 38 + bob;

  ctx.save();

  const label = `[E] Enter ${station.shortName}`;
  ctx.font = 'bold 12px system-ui, sans-serif';
  const textWidth = ctx.measureText(label).width;
  const padX = 12;
  const width = textWidth + padX * 2;
  const height = 26;

  // Speech bubble box
  ctx.fillStyle = '#14B8A6'; // Glowing teal
  ctx.beginPath();
  ctx.roundRect(bubbleX - width / 2, bubbleY - height / 2, width, height, 13);
  ctx.fill();

  // Downward pointer arrow
  ctx.beginPath();
  ctx.moveTo(bubbleX - 5, bubbleY + height / 2);
  ctx.lineTo(bubbleX, bubbleY + height / 2 + 5);
  ctx.lineTo(bubbleX + 5, bubbleY + height / 2);
  ctx.fill();

  // Text inside bubble
  ctx.fillStyle = '#0B0F14';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, bubbleX, bubbleY);

  ctx.restore();
}
