import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Eye, Sparkles, Compass, Camera, Footprints } from 'lucide-react';
import type { PlayerState, StationDef } from './types';
import { playStepSound } from './sound';

export type CameraMode = 'fpv' | 'iso' | 'close' | 'top';

interface Props {
  stations: StationDef[];
  player: PlayerState;
  onPlayerChange: (updater: (prev: PlayerState) => PlayerState) => void;
  onInteract: (station: StationDef) => void;
  activeStation: StationDef | null;
  autoPopupEnabled?: boolean;
}

const WORLD_WIDTH = 1200;
const WORLD_HEIGHT = 900;
const SCALE = 0.08; // 1 2D pixel = 0.08 Three.js units
const PLAYER_SPEED_2D = 240; // pixels/sec

function to3D(x2d: number, y2d: number): { x: number; z: number } {
  return {
    x: (x2d - 600) * SCALE,
    z: (y2d - 470) * SCALE,
  };
}

function to2D(x3d: number, z3d: number): { x: number; y: number } {
  return {
    x: x3d / SCALE + 600,
    y: z3d / SCALE + 470,
  };
}

// Generate high-resolution billboard sprite texture for station title & tag
function createStationLabelSprite(station: StationDef): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 180;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Rounded background pill
    const radius = 28;
    const x = 16;
    const y = 16;
    const w = canvas.width - 32;
    const h = canvas.height - 32;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();

    // Dark glass gradient
    const grad = ctx.createLinearGradient(0, y, 0, y + h);
    grad.addColorStop(0, 'rgba(12, 18, 28, 0.94)');
    grad.addColorStop(1, 'rgba(6, 9, 14, 0.98)');
    ctx.fillStyle = grad;
    ctx.fill();

    // Border with station color
    ctx.strokeStyle = station.colorHex;
    ctx.lineWidth = 4;
    ctx.stroke();

    // Category tag pill
    ctx.fillStyle = station.colorHex;
    ctx.font = 'bold 22px system-ui, -apple-system, sans-serif';
    ctx.fillText(station.tag.toUpperCase(), 36, 60);

    // Title
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 36px system-ui, -apple-system, sans-serif';
    ctx.fillText(station.shortName, 36, 110);

    // Small prompt
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.font = '20px system-ui, -apple-system, sans-serif';
    ctx.fillText('Auto-Popup Station', 36, 142);

    ctx.restore();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;

  const spriteMaterial = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthWrite: false,
  });

  const sprite = new THREE.Sprite(spriteMaterial);
  sprite.scale.set(7.5, 2.6, 1);
  return sprite;
}

// Generate procedural floor texture for ground
function createGroundTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.fillStyle = '#0a0f18';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Circular concentric lines
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    for (let r = 80; r < 500; r += 70) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(38, 55, 78, 0.45)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Grid dots
    ctx.fillStyle = 'rgba(56, 189, 248, 0.12)';
    for (let x = 0; x < canvas.width; x += 48) {
      for (let y = 0; y < canvas.height; y += 48) {
        ctx.fillRect(x - 1, y - 1, 2, 2);
      }
    }

    // Outer glow ring
    ctx.beginPath();
    ctx.arc(centerX, centerY, 480, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(20, 184, 166, 0.35)';
    ctx.lineWidth = 4;
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export function GameCanvas3D({
  stations,
  player,
  onPlayerChange,
  onInteract,
  activeStation,
  autoPopupEnabled = true,
}: Props): JSX.Element {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const lastTimeRef = useRef<number>(performance.now());
  const animFrameRef = useRef<number | null>(null);
  const clickTargetMarkerRef = useRef<{ mesh: THREE.Mesh; startTime: number } | null>(null);

  // 3D View mode state: default to 'fpv' (First Person POV)
  const [cameraMode, setCameraMode] = useState<CameraMode>('fpv');
  const cameraModeRef = useRef<CameraMode>('fpv');
  cameraModeRef.current = cameraMode;

  // First-Person Camera Look Angles (radians)
  const fpvYawRef = useRef<number>(0);
  const fpvPitchRef = useRef<number>(0);
  const [compassHeading, setCompassHeading] = useState<number>(0);

  // Drag-to-look tracker for first person POV
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const dragDistanceRef = useRef(0);

  // Refs for current props to avoid re-initializing 3D scene
  const stationsRef = useRef(stations);
  stationsRef.current = stations;
  const activeStationRef = useRef(activeStation);
  activeStationRef.current = activeStation;
  const onInteractRef = useRef(onInteract);
  onInteractRef.current = onInteract;
  const onPlayerChangeRef = useRef(onPlayerChange);
  onPlayerChangeRef.current = onPlayerChange;
  const playerRef = useRef<PlayerState>(player);
  playerRef.current = player;

  // Scene references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const playerMeshGroupRef = useRef<THREE.Group | null>(null);
  const stationMeshesRef = useRef<
    Map<
      string,
      {
        group: THREE.Group;
        crystal: THREE.Mesh;
        beacon: THREE.Mesh;
        ring: THREE.Mesh;
        groundRing: THREE.Mesh;
        groundDisc: THREE.Mesh;
        light: THREE.PointLight;
        sprite: THREE.Sprite;
        def: StationDef;
      }
    >
  >(new Map());
  const particlesRef = useRef<THREE.Points | null>(null);

  // Keyboard handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const key = e.key.toLowerCase();
      keysRef.current[key] = true;

      // Camera view toggle with 'v' or 'c'
      if (key === 'v' || key === 'c') {
        e.preventDefault();
        setCameraMode((prev) => {
          if (prev === 'fpv') return 'iso';
          if (prev === 'iso') return 'close';
          if (prev === 'close') return 'top';
          return 'fpv';
        });
        return;
      }

      // Cancel target point when manually pressing movement keys
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(key)) {
        playerRef.current.target = null;
      }

      if (['e', 'enter', ' '].includes(key)) {
        if (activeStationRef.current) {
          e.preventDefault();
          onInteractRef.current(activeStationRef.current);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Initialize Three.js 3D Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 560;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b12);
    scene.fog = new THREE.FogExp2(0x070b12, 0.009);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(44, width / height, 0.5, 400);
    cameraRef.current = camera;
    const p3d = to3D(playerRef.current.x, playerRef.current.y);
    camera.position.set(p3d.x, 26, p3d.z + 24);
    camera.lookAt(p3d.x, 1.5, p3d.z);

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    container.replaceChildren(renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x334466, 1.4);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xbbe1fa, 2.0);
    dirLight.position.set(25, 45, 30);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 150;
    const shadowDist = 40;
    dirLight.shadow.camera.left = -shadowDist;
    dirLight.shadow.camera.right = shadowDist;
    dirLight.shadow.camera.top = shadowDist;
    dirLight.shadow.camera.bottom = -shadowDist;
    scene.add(dirLight);

    // 5. Ground Plane
    const groundGeo = new THREE.PlaneGeometry(160, 160);
    const groundTexture = createGroundTexture();
    const groundMat = new THREE.MeshStandardMaterial({
      map: groundTexture,
      roughness: 0.85,
      metalness: 0.15,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = true;
    scene.add(ground);

    // 6. Central Sanctuary Plaza (Tiered Dais & Pool)
    const centralGroup = new THREE.Group();
    const daisBottom = new THREE.Mesh(
      new THREE.CylinderGeometry(7.5, 8.2, 0.4, 48),
      new THREE.MeshStandardMaterial({ color: 0x111927, roughness: 0.7, metalness: 0.3 })
    );
    daisBottom.position.y = 0.2;
    daisBottom.receiveShadow = true;
    centralGroup.add(daisBottom);

    const daisTop = new THREE.Mesh(
      new THREE.CylinderGeometry(5.8, 6.2, 0.3, 48),
      new THREE.MeshStandardMaterial({ color: 0x1a2436, roughness: 0.6, metalness: 0.4 })
    );
    daisTop.position.y = 0.45;
    daisTop.receiveShadow = true;
    centralGroup.add(daisTop);

    // Center glowing water pool / energy well
    const pool = new THREE.Mesh(
      new THREE.CylinderGeometry(3.6, 3.6, 0.35, 32),
      new THREE.MeshStandardMaterial({
        color: 0x14b8a6,
        emissive: 0x0f766e,
        emissiveIntensity: 0.7,
        roughness: 0.1,
        metalness: 0.9,
      })
    );
    pool.position.y = 0.55;
    centralGroup.add(pool);

    // Central rotating monument crystal
    const centerMonument = new THREE.Mesh(
      new THREE.OctahedronGeometry(1.6, 0),
      new THREE.MeshStandardMaterial({
        color: 0x2dd4bf,
        emissive: 0x14b8a6,
        emissiveIntensity: 0.8,
        roughness: 0.1,
        metalness: 0.9,
      })
    );
    centerMonument.position.y = 2.8;
    centerMonument.castShadow = true;
    centerMonument.name = 'centerMonument';
    centralGroup.add(centerMonument);

    // Surrounding rotating gold rings around monument
    const centerRing = new THREE.Mesh(
      new THREE.TorusGeometry(2.4, 0.08, 16, 48),
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.6,
      })
    );
    centerRing.position.y = 2.8;
    centerRing.rotation.x = Math.PI / 3;
    centerRing.name = 'centerRing';
    centralGroup.add(centerRing);

    // Center point light
    const centerLight = new THREE.PointLight(0x2dd4bf, 2.5, 20);
    centerLight.position.set(0, 3, 0);
    centralGroup.add(centerLight);

    scene.add(centralGroup);

    // 7. Pathways connecting center to each station
    const pathMat = new THREE.MeshStandardMaterial({
      color: 0x131c2a,
      roughness: 0.8,
      metalness: 0.2,
    });
    const conduitMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      emissive: 0x0ea5e9,
      emissiveIntensity: 0.5,
      roughness: 0.3,
    });

    stationsRef.current.forEach((st) => {
      const pos = to3D(st.x, st.y);
      const dist = Math.hypot(pos.x, pos.z);
      const angle = Math.atan2(pos.x, pos.z);

      // Pathway strip
      const pathGeo = new THREE.PlaneGeometry(2.4, dist);
      const pathMesh = new THREE.Mesh(pathGeo, pathMat);
      pathMesh.rotation.x = -Math.PI / 2;
      pathMesh.rotation.z = -angle;
      pathMesh.position.set(pos.x / 2, 0.02, pos.z / 2);
      pathMesh.receiveShadow = true;
      scene.add(pathMesh);

      // Embedded glowing conduit line
      const conduitGeo = new THREE.PlaneGeometry(0.3, dist);
      const conduitMesh = new THREE.Mesh(conduitGeo, conduitMat);
      conduitMesh.rotation.x = -Math.PI / 2;
      conduitMesh.rotation.z = -angle;
      conduitMesh.position.set(pos.x / 2, 0.03, pos.z / 2);
      scene.add(conduitMesh);
    });

    // 8. 3D Station Nodes
    stationMeshesRef.current.clear();
    stationsRef.current.forEach((st) => {
      const st3d = to3D(st.x, st.y);
      const stationGroup = new THREE.Group();
      stationGroup.position.set(st3d.x, 0, st3d.z);

      // Pedestal base
      const baseGeo = new THREE.CylinderGeometry(4.2, 4.6, 0.4, 32);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0x111827,
        roughness: 0.7,
        metalness: 0.3,
      });
      const baseMesh = new THREE.Mesh(baseGeo, baseMat);
      baseMesh.position.y = 0.2;
      baseMesh.receiveShadow = true;
      baseMesh.castShadow = true;
      stationGroup.add(baseMesh);

      // Concentric glowing energy ring
      const ringGeo = new THREE.TorusGeometry(3.6, 0.12, 16, 48);
      const ringMat = new THREE.MeshStandardMaterial({
        color: st.colorHex,
        emissive: st.colorHex,
        emissiveIntensity: 0.8,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.position.y = 0.42;
      stationGroup.add(ringMesh);

      // Station interactive ground circle (radius * SCALE in 3D units)
      const circleRadius = st.radius * SCALE;
      const groundRingGeo = new THREE.RingGeometry(circleRadius - 0.22, circleRadius + 0.14, 64);
      const groundRingMat = new THREE.MeshBasicMaterial({
        color: st.colorHex,
        transparent: true,
        opacity: 0.6,
        side: THREE.DoubleSide,
      });
      const groundRingMesh = new THREE.Mesh(groundRingGeo, groundRingMat);
      groundRingMesh.rotation.x = -Math.PI / 2;
      groundRingMesh.position.y = 0.04;
      stationGroup.add(groundRingMesh);

      // Translucent glowing ground disc inside the circle
      const groundDiscGeo = new THREE.CircleGeometry(circleRadius, 48);
      const groundDiscMat = new THREE.MeshBasicMaterial({
        color: st.colorHex,
        transparent: true,
        opacity: 0.1,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const groundDiscMesh = new THREE.Mesh(groundDiscGeo, groundDiscMat);
      groundDiscMesh.rotation.x = -Math.PI / 2;
      groundDiscMesh.position.y = 0.03;
      stationGroup.add(groundDiscMesh);

      // Floating 3D Crystal artifact
      const crystalGeo = new THREE.IcosahedronGeometry(1.4, 0);
      const crystalMat = new THREE.MeshStandardMaterial({
        color: st.colorHex,
        emissive: st.colorHex,
        emissiveIntensity: 0.9,
        roughness: 0.15,
        metalness: 0.85,
      });
      const crystal = new THREE.Mesh(crystalGeo, crystalMat);
      crystal.position.y = 2.4;
      crystal.castShadow = true;
      stationGroup.add(crystal);

      // Upward Beacon Beam
      const beaconGeo = new THREE.CylinderGeometry(0.2, 1.6, 16, 16, 1, true);
      const beaconMat = new THREE.MeshBasicMaterial({
        color: st.colorHex,
        transparent: true,
        opacity: 0.2,
        side: THREE.DoubleSide,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.y = 8;
      stationGroup.add(beacon);

      // Pedestal Point Light
      const pointLight = new THREE.PointLight(st.colorHex, 2.0, 14);
      pointLight.position.set(0, 2.5, 0);
      stationGroup.add(pointLight);

      // Floating 3D Billboard Sprite with Station Title
      const sprite = createStationLabelSprite(st);
      sprite.position.set(0, 5.2, 0);
      stationGroup.add(sprite);

      scene.add(stationGroup);

      stationMeshesRef.current.set(st.id, {
        group: stationGroup,
        crystal,
        beacon,
        ring: ringMesh,
        groundRing: groundRingMesh,
        groundDisc: groundDiscMesh,
        light: pointLight,
        sprite,
        def: st,
      });
    });

    // 9. Floating Obelisks / Perimeter Architecture
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2;
      const radius = 54;
      const obelisk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 1.2, 5.5, 4),
        new THREE.MeshStandardMaterial({
          color: 0x152238,
          roughness: 0.7,
          metalness: 0.3,
          emissive: 0x1e3a8a,
          emissiveIntensity: 0.3,
        })
      );
      obelisk.position.set(Math.cos(angle) * radius, 3.2, Math.sin(angle) * radius);
      obelisk.castShadow = true;
      scene.add(obelisk);
    }

    // 10. Ambient Floating Sparks (Dust/Firefly Particles)
    const particleCount = 140;
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 110;
      particlePositions[i + 1] = 0.8 + Math.random() * 8.0;
      particlePositions[i + 2] = (Math.random() - 0.5) * 110;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.35,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    particlesRef.current = particles;
    scene.add(particles);

    // 11. 3D Player Character Avatar
    const playerGroup = new THREE.Group();
    const pInit = to3D(playerRef.current.x, playerRef.current.y);
    playerGroup.position.set(pInit.x, 0, pInit.z);

    // Torso / Jacket
    const torso = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 1.1, 0.6),
      new THREE.MeshStandardMaterial({
        color: 0x1f2937,
        emissive: 0x14b8a6,
        emissiveIntensity: 0.4,
        roughness: 0.4,
      })
    );
    torso.position.y = 1.35;
    torso.castShadow = true;
    playerGroup.add(torso);

    // Head
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.4, 16, 16),
      new THREE.MeshStandardMaterial({
        color: 0xf3f4f6,
        roughness: 0.3,
      })
    );
    head.position.y = 2.25;
    head.castShadow = true;
    playerGroup.add(head);

    // Glowing Visor
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.45, 0.16, 0.3),
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x38bdf8,
        emissiveIntensity: 1.2,
      })
    );
    visor.position.set(0, 2.25, 0.3);
    playerGroup.add(visor);

    // Tech Backpack
    const backpack = new THREE.Mesh(
      new THREE.BoxGeometry(0.6, 0.7, 0.35),
      new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        emissive: 0x10b981,
        emissiveIntensity: 0.6,
      })
    );
    backpack.position.set(0, 1.4, -0.4);
    backpack.castShadow = true;
    playerGroup.add(backpack);

    // Left Leg
    const leftLeg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.14, 0.75, 12),
      new THREE.MeshStandardMaterial({ color: 0x111827 })
    );
    leftLeg.position.set(-0.25, 0.45, 0);
    leftLeg.castShadow = true;
    leftLeg.name = 'leftLeg';
    playerGroup.add(leftLeg);

    // Right Leg
    const rightLeg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.14, 0.75, 12),
      new THREE.MeshStandardMaterial({ color: 0x111827 })
    );
    rightLeg.position.set(0.25, 0.45, 0);
    rightLeg.castShadow = true;
    rightLeg.name = 'rightLeg';
    playerGroup.add(rightLeg);

    // Ground Shadow Decal
    const shadowDisc = new THREE.Mesh(
      new THREE.CircleGeometry(0.7, 24),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45 })
    );
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = 0.02;
    playerGroup.add(shadowDisc);

    // Player forward exploration light
    const playerLight = new THREE.PointLight(0x38bdf8, 1.8, 9);
    playerLight.position.set(0, 1.6, 0.8);
    playerGroup.add(playerLight);

    playerMeshGroupRef.current = playerGroup;
    scene.add(playerGroup);

    // Click target ripple ring geometry (pre-created)
    const ringTargetGeo = new THREE.RingGeometry(0.2, 0.8, 32);
    const ringTargetMat = new THREE.MeshBasicMaterial({
      color: 0x14b8a6,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
    });
    const clickTargetMesh = new THREE.Mesh(ringTargetGeo, ringTargetMat);
    clickTargetMesh.name = 'clickTargetMesh';
    clickTargetMesh.rotation.x = -Math.PI / 2;
    clickTargetMesh.position.y = 0.04;
    clickTargetMesh.visible = false;
    scene.add(clickTargetMesh);

    // 12. Main 60 FPS Render & Physics Loop
    let walkCycle = 0;
    let lastStepTime = 0;
    let lastSyncTime = 0;

    const animate = (now: number) => {
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;

      // Handle keyboard movement inputs
      let dx = 0;
      let dy = 0;
      const keys = keysRef.current;
      const currentCamMode = cameraModeRef.current;

      if (currentCamMode === 'fpv') {
        // In First-Person POV:
        // ArrowLeft / ArrowRight rotate camera yaw smoothly
        if (keys['arrowleft']) {
          fpvYawRef.current -= 2.2 * dt;
        }
        if (keys['arrowright']) {
          fpvYawRef.current += 2.2 * dt;
        }
        // W / Up moves forward, S / Down moves backward
        if (keys['w'] || keys['arrowup']) dy -= 1;
        if (keys['s'] || keys['arrowdown']) dy += 1;
        // A strafes left, D strafes right
        if (keys['a']) dx -= 1;
        if (keys['d']) dx += 1;
      } else {
        if (keys['w'] || keys['arrowup']) dy -= 1;
        if (keys['s'] || keys['arrowdown']) dy += 1;
        if (keys['a'] || keys['arrowleft']) dx -= 1;
        if (keys['d'] || keys['arrowright']) dx += 1;
      }

      const p = playerRef.current;
      let isMoving = false;
      let targetRotY = playerGroup.rotation.y;

      if (dx !== 0 || dy !== 0) {
        if (currentCamMode === 'fpv') {
          // Camera-relative navigation in 1st person
          const yaw = fpvYawRef.current;
          const fwd = -dy; // forward is +1
          const strafe = dx; // right is +1
          const len = Math.hypot(fwd, strafe);
          const normFwd = fwd / len;
          const normStr = strafe / len;

          // Camera heading in 3D:
          // Forward is (sin(yaw), cos(yaw))
          // Strafe right is (cos(yaw), -sin(yaw))
          const moveX3D = Math.sin(yaw) * normFwd + Math.cos(yaw) * normStr;
          const moveZ3D = Math.cos(yaw) * normFwd - Math.sin(yaw) * normStr;

          p.x += moveX3D * PLAYER_SPEED_2D * dt;
          p.y += moveZ3D * PLAYER_SPEED_2D * dt;
          isMoving = true;
          targetRotY = yaw;
          p.direction = Math.abs(moveX3D) > Math.abs(moveZ3D) ? (moveX3D > 0 ? 'right' : 'left') : (moveZ3D > 0 ? 'down' : 'up');
        } else {
          // Standard isometric movement
          const len = Math.hypot(dx, dy);
          const normX = dx / len;
          const normY = dy / len;

          p.x += normX * PLAYER_SPEED_2D * dt;
          p.y += normY * PLAYER_SPEED_2D * dt;
          isMoving = true;

          // Angle in 3D: dx maps to +X, dy maps to +Z
          targetRotY = Math.atan2(normX, normY);

          if (Math.abs(normX) > Math.abs(normY)) {
            p.direction = normX > 0 ? 'right' : 'left';
          } else {
            p.direction = normY > 0 ? 'down' : 'up';
          }
        }
      } else if (p.target) {
        // Click-to-move target navigation
        const distX = p.target.x - p.x;
        const distY = p.target.y - p.y;
        const dist = Math.hypot(distX, distY);

        if (dist > 5) {
          const moveStep = PLAYER_SPEED_2D * dt;
          if (dist <= moveStep) {
            p.x = p.target.x;
            p.y = p.target.y;
            p.target = null;
          } else {
            const dirX = distX / dist;
            const dirY = distY / dist;
            p.x += dirX * moveStep;
            p.y += dirY * moveStep;
            isMoving = true;
            targetRotY = Math.atan2(dirX, dirY);

            if (currentCamMode === 'fpv') {
              // Smoothly steer camera yaw towards walking target in FPV
              const diff = Math.atan2(Math.sin(targetRotY - fpvYawRef.current), Math.cos(targetRotY - fpvYawRef.current));
              fpvYawRef.current += diff * Math.min(1, 6 * dt);
            }

            if (Math.abs(dirX) > Math.abs(dirY)) {
              p.direction = dirX > 0 ? 'right' : 'left';
            } else {
              p.direction = dirY > 0 ? 'down' : 'up';
            }
          }
        } else {
          p.target = null;
        }
      }

      // Constrain world bounds (2D coordinate space)
      p.x = Math.max(80, Math.min(WORLD_WIDTH - 80, p.x));
      p.y = Math.max(80, Math.min(WORLD_HEIGHT - 80, p.y));
      p.isMoving = isMoving;

      // Update 3D player mesh position & smooth rotation
      const current3D = to3D(p.x, p.y);
      playerGroup.position.set(current3D.x, 0, current3D.z);

      if (isMoving) {
        // Smoothly interpolate angle
        const diff = Math.atan2(Math.sin(targetRotY - playerGroup.rotation.y), Math.cos(targetRotY - playerGroup.rotation.y));
        playerGroup.rotation.y += diff * Math.min(1, 14 * dt);

        // Walking gait animation (legs swing back & forth)
        walkCycle += dt * 11;
        const leftL = playerGroup.getObjectByName('leftLeg');
        const rightL = playerGroup.getObjectByName('rightLeg');
        if (leftL && rightL) {
          leftL.rotation.x = Math.sin(walkCycle) * 0.45;
          rightL.rotation.x = -Math.sin(walkCycle) * 0.45;
        }
        playerGroup.position.y = Math.abs(Math.sin(walkCycle)) * 0.08;

        // Footstep audio chimes
        if (now - lastStepTime > 320) {
          playStepSound();
          lastStepTime = now;
        }
      } else {
        // Return legs to neutral
        const leftL = playerGroup.getObjectByName('leftLeg');
        const rightL = playerGroup.getObjectByName('rightLeg');
        if (leftL && rightL) {
          leftL.rotation.x *= 0.8;
          rightL.rotation.x *= 0.8;
        }
        playerGroup.position.y = 0;
      }

      // Sync state back to parent React state throttled for UI updates (minimap, etc)
      if (now - lastSyncTime > 60 || !isMoving) {
        lastSyncTime = now;
        onPlayerChangeRef.current((prev) => {
          if (
            Math.abs(prev.x - p.x) > 0.5 ||
            Math.abs(prev.y - p.y) > 0.5 ||
            prev.direction !== p.direction ||
            prev.isMoving !== p.isMoving
          ) {
            return { ...p };
          }
          return prev;
        });
      }

      // Camera positioning based on cameraMode
      if (currentCamMode === 'fpv') {
        // In First-Person POV: hide player figure avatar to keep sightline crystal clear
        playerGroup.visible = false;

        const eyeHeight = 2.15;
        const headBob = isMoving ? Math.sin(walkCycle) * 0.04 : 0;
        const headSway = isMoving ? Math.cos(walkCycle * 0.5) * 0.025 : 0;

        const camX = current3D.x + headSway;
        const camY = eyeHeight + headBob;
        const camZ = current3D.z;

        camera.position.set(camX, camY, camZ);

        const yaw = fpvYawRef.current;
        const pitch = fpvPitchRef.current;
        const lookDist = 12;
        const lookX = current3D.x + Math.sin(yaw) * Math.cos(pitch) * lookDist;
        const lookY = eyeHeight + Math.sin(pitch) * lookDist + headBob * 0.5;
        const lookZ = current3D.z + Math.cos(yaw) * Math.cos(pitch) * lookDist;

        camera.lookAt(lookX, lookY, lookZ);

        // Update compass heading for HUD (0 to 360 degrees)
        const headingDeg = Math.round(((-yaw * 180) / Math.PI + 360) % 360);
        setCompassHeading(headingDeg);
      } else {
        // In 3rd-Person Views: player figure avatar is fully visible
        playerGroup.visible = true;

        let camTargetX = current3D.x;
        let camTargetY = 24;
        let camTargetZ = current3D.z + 23;
        let lookAtY = 1.6;

        if (currentCamMode === 'close') {
          camTargetY = 14;
          camTargetZ = current3D.z + 14;
          lookAtY = 1.8;
        } else if (currentCamMode === 'top') {
          camTargetY = 46;
          camTargetZ = current3D.z + 12;
          lookAtY = 0;
        }

        camera.position.x += (camTargetX - camera.position.x) * 0.08;
        camera.position.y += (camTargetY - camera.position.y) * 0.08;
        camera.position.z += (camTargetZ - camera.position.z) * 0.08;
        camera.lookAt(current3D.x, lookAtY, current3D.z);
      }

      // Animate center monument & rings
      const centerM = scene.getObjectByName('centerMonument');
      if (centerM) {
        centerM.rotation.y += 0.015;
        centerM.rotation.x += 0.008;
        centerM.position.y = 2.8 + Math.sin(now * 0.002) * 0.25;
      }
      const cRing = scene.getObjectByName('centerRing');
      if (cRing) {
        cRing.rotation.z += 0.012;
      }

      // Animate stations: crystal rotation, beacon pulse, and visible ground circles
      const activeSt = activeStationRef.current;
      stationMeshesRef.current.forEach((stMesh, stId) => {
        const isActive = activeSt?.id === stId;
        const timeSec = now * 0.001;

        // Rotate & bob crystal
        stMesh.crystal.rotation.y += 0.02;
        stMesh.crystal.rotation.z = Math.sin(timeSec * 2) * 0.1;
        stMesh.crystal.position.y = 2.4 + Math.sin(timeSec * 2.5 + stMesh.def.x) * 0.3;

        // Pulsing station ring, beacon, and ground activation circle
        if (isActive) {
          const pulse = 1 + Math.sin(timeSec * 6) * 0.2;
          stMesh.ring.scale.set(pulse, pulse, pulse);
          stMesh.light.intensity = 3.5 + Math.sin(timeSec * 6) * 1.0;
          stMesh.beacon.scale.set(1.4, 1.2, 1.4);
          stMesh.sprite.scale.set(8.5, 2.9, 1);
          if (stMesh.groundRing) {
            (stMesh.groundRing.material as THREE.MeshBasicMaterial).opacity = 0.95 + Math.sin(timeSec * 8) * 0.05;
            stMesh.groundRing.scale.set(1 + Math.sin(timeSec * 4) * 0.02, 1 + Math.sin(timeSec * 4) * 0.02, 1);
          }
          if (stMesh.groundDisc) {
            (stMesh.groundDisc.material as THREE.MeshBasicMaterial).opacity = 0.22 + Math.sin(timeSec * 6) * 0.06;
          }
        } else {
          stMesh.ring.scale.set(1, 1, 1);
          stMesh.light.intensity = 2.0;
          stMesh.beacon.scale.set(1, 1, 1);
          stMesh.sprite.scale.set(7.5, 2.6, 1);
          if (stMesh.groundRing) {
            (stMesh.groundRing.material as THREE.MeshBasicMaterial).opacity = 0.55;
            stMesh.groundRing.scale.set(1, 1, 1);
          }
          if (stMesh.groundDisc) {
            (stMesh.groundDisc.material as THREE.MeshBasicMaterial).opacity = 0.1;
          }
        }
      });

      // Animate ambient particles drifting
      if (particlesRef.current) {
        const positions = particlesRef.current.geometry.attributes.position;
        if (positions) {
          const arr = positions.array as Float32Array;
          for (let i = 1; i < arr.length; i += 3) {
            arr[i] = 1.0 + ((arr[i]! + 0.015) % 10.0);
          }
          positions.needsUpdate = true;
        }
      }

      // Animate click target marker
      if (clickTargetMarkerRef.current) {
        const elapsed = (now - clickTargetMarkerRef.current.startTime) / 1000;
        if (elapsed < 0.6) {
          const scale = 1 + elapsed * 1.8;
          clickTargetMesh.scale.set(scale, scale, 1);
          (clickTargetMesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - elapsed / 0.6);
          clickTargetMesh.visible = true;
        } else {
          clickTargetMesh.visible = false;
          clickTargetMarkerRef.current = null;
        }
      }

      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    // Responsive Resize Observer
    const updateSize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 560;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const ro = new ResizeObserver(() => updateSize());
    ro.observe(container);
    window.addEventListener('resize', updateSize);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', updateSize);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
      container.replaceChildren();
    };
  }, [cameraMode]);

  // Pointer event handlers: Drag to look around in FPV, click to walk/interact
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    dragDistanceRef.current = 0;
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    dragDistanceRef.current += Math.hypot(dx, dy);

    // Pan camera view in First-Person POV
    if (cameraModeRef.current === 'fpv') {
      fpvYawRef.current += dx * 0.0035;
      fpvPitchRef.current = Math.max(-0.55, Math.min(0.55, fpvPitchRef.current - dy * 0.0035));
    }

    dragStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const wasShortClick = dragDistanceRef.current < 7;
    isDraggingRef.current = false;

    if (!wasShortClick) return;

    // Perform click raycasting in 3D Space
    const container = mountRef.current;
    const camera = cameraRef.current;
    const scene = sceneRef.current;
    if (!container || !camera || !scene) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), camera);

    // 1. Check if user clicked on a station mesh or its ground ring
    const stationObjects: THREE.Object3D[] = [];
    stationMeshesRef.current.forEach((val) => {
      stationObjects.push(val.crystal);
      stationObjects.push(val.ring);
      stationObjects.push(val.groundRing);
      stationObjects.push(val.sprite);
    });

    const stationHits = raycaster.intersectObjects(stationObjects, true);
    if (stationHits.length > 0) {
      const hitObj = stationHits[0]?.object;
      for (const [, val] of stationMeshesRef.current.entries()) {
        if (
          val.crystal === hitObj ||
          val.ring === hitObj ||
          val.groundRing === hitObj ||
          val.sprite === hitObj ||
          val.group === hitObj ||
          val.group.children.includes(hitObj as THREE.Object3D)
        ) {
          // Walk into station circle and pop up
          playerRef.current.target = { x: val.def.x, y: val.def.y + 30 };
          onInteractRef.current(val.def);
          return;
        }
      }
    }

    // 2. Otherwise raycast onto ground plane (y = 0)
    const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const targetPoint = new THREE.Vector3();
    const hit = raycaster.ray.intersectPlane(groundPlane, targetPoint);

    if (hit) {
      // Spawn ripple animation at click location in 3D
      const clickMesh = scene.getObjectByName('clickTargetMesh');
      if (clickMesh) {
        clickMesh.position.set(hit.x, 0.04, hit.z);
      }
      clickTargetMarkerRef.current = {
        mesh: clickMesh as THREE.Mesh,
        startTime: performance.now(),
      };

      // Convert 3D world coordinates back to 2D player state coordinates
      const coords2D = to2D(hit.x, hit.z);
      coords2D.x = Math.max(80, Math.min(WORLD_WIDTH - 80, coords2D.x));
      coords2D.y = Math.max(80, Math.min(WORLD_HEIGHT - 80, coords2D.y));

      playerRef.current.target = coords2D;
    }
  };

  // Cardinal direction helper for FPV Compass
  const getCardinalDirection = (deg: number): string => {
    if (deg >= 337.5 || deg < 22.5) return 'N';
    if (deg >= 22.5 && deg < 67.5) return 'NE';
    if (deg >= 67.5 && deg < 112.5) return 'E';
    if (deg >= 112.5 && deg < 157.5) return 'SE';
    if (deg >= 157.5 && deg < 202.5) return 'S';
    if (deg >= 202.5 && deg < 247.5) return 'SW';
    if (deg >= 247.5 && deg < 292.5) return 'W';
    return 'NW';
  };

  return (
    <div className="relative w-full h-full min-h-[440px] select-none overflow-hidden touch-none">
      {/* 3D WebGL Canvas Container */}
      <div
        ref={mountRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className={`w-full h-full block ${cameraMode === 'fpv' ? 'cursor-grab active:cursor-grabbing' : 'cursor-crosshair'}`}
      />

      {/* First-Person POV HUD: Central Reticle / Targeting Crosshair */}
      {cameraMode === 'fpv' ? (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="relative flex items-center justify-center">
            {/* Center dot */}
            <div className="h-1.5 w-1.5 rounded-full bg-accent-400 shadow-[0_0_8px_rgba(45,212,191,0.9)]" />
            {/* Subtle outer reticle brackets */}
            <div className="absolute h-8 w-8 rounded-full border border-accent-400/35 border-dashed" />
            <div className="absolute -top-3 h-1.5 w-0.5 bg-accent-400/50" />
            <div className="absolute -bottom-3 h-1.5 w-0.5 bg-accent-400/50" />
            <div className="absolute -left-3 h-0.5 w-1.5 bg-accent-400/50" />
            <div className="absolute -right-3 h-0.5 w-1.5 bg-accent-400/50" />
          </div>
        </div>
      ) : null}

      {/* First-Person POV HUD: Cybernetic Compass Tape */}
      {cameraMode === 'fpv' ? (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center gap-2 bg-ink-950/85 backdrop-blur-md px-3 py-1 rounded-full border border-line shadow-lg text-xs font-mono">
          <Compass className="h-3.5 w-3.5 text-accent-400" />
          <span className="font-bold text-accent-400">
            {compassHeading.toString().padStart(3, '0')}°
          </span>
          <span className="px-1.5 py-0.2 rounded bg-ink-900 border border-line text-[10px] text-fg font-semibold">
            {getCardinalDirection(compassHeading)}
          </span>
          <span className="text-subtle text-[10px] hidden sm:inline">FIRST PERSON POV</span>
        </div>
      ) : null}

      {/* In-Circle Active Banner (when inside a station's radius) */}
      {activeStation ? (
        <div className="absolute top-12 sm:top-14 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center gap-2 bg-emerald-950/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-emerald-500/50 shadow-xl text-xs text-emerald-200 animate-pulse">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-semibold text-emerald-300">
            Inside {activeStation.shortName} circle
          </span>
          <span className="text-emerald-400/80 text-[11px] hidden sm:inline">
            · Segment open (walk away to close)
          </span>
        </div>
      ) : null}

      {/* 3D Camera Controls Floating HUD */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-1.5 bg-ink-950/85 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-line shadow-lg">
        <span className="text-[10px] font-mono text-muted flex items-center gap-1 mr-1">
          <Eye className="h-3 w-3 text-accent-400" />
          <span className="hidden sm:inline">VIEW</span>
        </span>
        <button
          type="button"
          onClick={() => setCameraMode('fpv')}
          className={`tap-target flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-semibold transition ${
            cameraMode === 'fpv'
              ? 'bg-accent-500 text-ink-950 shadow-sm'
              : 'text-muted hover:text-fg hover:bg-ink-900'
          }`}
          title="First-Person POV: See through the figure's eyes (Key: V)"
        >
          <Camera className="h-3 w-3" />
          <span>1st Person POV</span>
        </button>
        <button
          type="button"
          onClick={() => setCameraMode('iso')}
          className={`tap-target px-2 py-0.5 rounded-lg text-xs font-semibold transition ${
            cameraMode === 'iso'
              ? 'bg-accent-500 text-ink-950 shadow-sm'
              : 'text-muted hover:text-fg hover:bg-ink-900'
          }`}
          title="Isometric 3D Perspective (Key: V)"
        >
          Isometric
        </button>
        <button
          type="button"
          onClick={() => setCameraMode('close')}
          className={`tap-target px-2 py-0.5 rounded-lg text-xs font-semibold transition ${
            cameraMode === 'close'
              ? 'bg-accent-500 text-ink-950 shadow-sm'
              : 'text-muted hover:text-fg hover:bg-ink-900'
          }`}
          title="Close-Up 3D Perspective"
        >
          Close-Up
        </button>
        <button
          type="button"
          onClick={() => setCameraMode('top')}
          className={`tap-target px-2 py-0.5 rounded-lg text-xs font-semibold transition ${
            cameraMode === 'top'
              ? 'bg-accent-500 text-ink-950 shadow-sm'
              : 'text-muted hover:text-fg hover:bg-ink-900'
          }`}
          title="Tactical Aerial 3D View"
        >
          Top-Down
        </button>
      </div>

      {/* Movement & Drag Navigation Help Bar */}
      <div className="absolute bottom-3 left-3 z-20 hidden md:flex items-center gap-2 bg-ink-950/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-line text-[11px] text-muted">
        <Footprints className="h-3 w-3 text-accent-400" />
        {cameraMode === 'fpv' ? (
          <span>
            <strong className="text-fg">W/A/S/D</strong> walk · <strong className="text-fg">Drag / Arrows</strong> look · <strong className="text-fg">V</strong> view
          </span>
        ) : (
          <span>
            <strong className="text-fg">W/A/S/D</strong> walk · <strong className="text-fg">Click</strong> move · <strong className="text-fg">V</strong> 1st Person POV
          </span>
        )}
      </div>

      {/* Auto-Popup Status Badge */}
      <div className="absolute bottom-3 right-3 z-20 hidden sm:flex items-center gap-1.5 bg-ink-950/85 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-line text-[11px] text-muted">
        <Sparkles className="h-3 w-3 text-accent-400" />
        <span>
          Circles: <strong className="text-emerald-400">{autoPopupEnabled ? 'AUTO-POPUP' : 'MANUAL'}</strong> on enter · auto-closes on exit
        </span>
      </div>
    </div>
  );
}
