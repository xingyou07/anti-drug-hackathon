import { MapPin } from 'lucide-react';
import type { PlayerState, StationDef } from './types';

interface Props {
  stations: StationDef[];
  player: PlayerState;
  onStationClick: (station: StationDef) => void;
  activeStation: StationDef | null;
}

const WORLD_WIDTH = 1200;
const WORLD_HEIGHT = 900;

export function MiniMap({
  stations,
  player,
  onStationClick,
  activeStation,
}: Props): JSX.Element {
  return (
    <div className="relative bg-ink-950/90 backdrop-blur-md rounded-xl border border-line p-2 shadow-xl">
      <div className="flex items-center justify-between gap-2 pb-1 border-b border-line mb-1 text-[10px] font-mono text-subtle">
        <span className="flex items-center gap-1">
          <MapPin className="h-3 w-3 text-accent-400" />
          <span>RADAR</span>
        </span>
        <span>CLICK TO WALK</span>
      </div>

      <div className="relative w-36 h-28 bg-ink-900 rounded-lg overflow-hidden border border-line/60">
        {/* Soft grid */}
        <div className="absolute inset-0 bg-[radial-gradient(#2B3A4B_1px,transparent_1px)] [background-size:12px_12px] opacity-40" />

        {/* Stations dots */}
        {stations.map((st) => {
          const leftPercent = (st.x / WORLD_WIDTH) * 100;
          const topPercent = (st.y / WORLD_HEIGHT) * 100;
          const isActive = activeStation?.id === st.id;

          return (
            <button
              key={st.id}
              type="button"
              onClick={() => onStationClick(st)}
              title={`${st.title} (${st.tag})`}
              className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full transition-transform hover:scale-150 ${
                isActive ? 'ring-2 ring-white scale-125 z-10' : ''
              }`}
              style={{
                left: `${leftPercent}%`,
                top: `${topPercent}%`,
                width: isActive ? '8px' : '6px',
                height: isActive ? '8px' : '6px',
                backgroundColor: st.colorHex,
              }}
            />
          );
        })}

        {/* Player dot with directional radar beam */}
        <div
          className="absolute -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none"
          style={{
            left: `${(player.x / WORLD_WIDTH) * 100}%`,
            top: `${(player.y / WORLD_HEIGHT) * 100}%`,
          }}
        >
          <div className="h-2.5 w-2.5 rounded-full bg-white ring-2 ring-accent-400 shadow-md animate-pulse" />
        </div>
      </div>
    </div>
  );
}
