export type TrackType = 'youth' | 'recovery';

export type StationCategory =
  | 'Coping Tool'
  | 'Somatic'
  | 'Tactical'
  | 'Emergency'
  | 'Legal & Facts'
  | 'Education'
  | 'System';

export interface StationDef {
  id: string;
  title: string;
  shortName: string;
  tag: StationCategory;
  description: string;
  x: number;
  y: number;
  radius: number;
  iconName: string;
  colorHex: string;
  accentClass: string;
  track: 'youth' | 'recovery' | 'all';
  componentKey: string;
  routePath?: string;
  phase?: string | null;
}

export type Direction = 'up' | 'down' | 'left' | 'right';

export interface PlayerState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  direction: Direction;
  isMoving: boolean;
  frame: number;
  target: { x: number; y: number } | null;
}
