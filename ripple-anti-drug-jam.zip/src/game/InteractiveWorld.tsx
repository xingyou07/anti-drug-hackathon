import { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import {
  Compass,
  MapPin,
  List,
  Volume2,
  VolumeX,
  Sparkles,
  Smartphone,
  Info,
  Box,
  Layers,
  Zap,
} from 'lucide-react';
import type { PlayerState, StationDef, TrackType, Direction } from './types';
import { getStationsForTrack } from './stationsData';
import { GameCanvas3D } from './GameCanvas3D';
import { GameCanvas } from './GameCanvas';
import { MiniMap } from './MiniMap';
import { VirtualControls } from './VirtualControls';
import { StationModal } from './StationModal';
import { StationDirectory } from './StationDirectory';
import { isSoundEnabled, setSoundEnabled, playApproachSound, playOpenSound } from './sound';
import { useCrisisSheet } from '@/state/CrisisSheetContext';

interface Props {
  track: TrackType;
  onSwitchToListMode: () => void;
  initialStationId?: string | null;
}

export function InteractiveWorld({
  track,
  onSwitchToListMode,
  initialStationId,
}: Props): JSX.Element {
  const { open: openCrisisSheet } = useCrisisSheet();
  const stations = useMemo(() => getStationsForTrack(track), [track]);

  // Player position state
  const [player, setPlayer] = useState<PlayerState>(() => {
    return {
      x: 600,
      y: 470,
      vx: 0,
      vy: 0,
      direction: 'down',
      isMoving: false,
      frame: 0,
      target: null,
    };
  });

  const [selectedStation, setSelectedStation] = useState<StationDef | null>(null);
  const [showDirectory, setShowDirectory] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [sound, setSound] = useState(isSoundEnabled());
  const [showHelpHint, setShowHelpHint] = useState(true);
  const [renderMode, setRenderMode] = useState<'3d' | '2d'>('3d');
  const [autoPopupEnabled, setAutoPopupEnabled] = useState(true);
  const [popupAlert, setPopupAlert] = useState<string | null>(null);
  const [isPinned, setIsPinned] = useState(false);
  const isPinnedRef = useRef(isPinned);
  isPinnedRef.current = isPinned;

  // Ref to remember dismissed station while player remains in its interactive radius
  const dismissedStationIdRef = useRef<string | null>(null);

  // Check if touch device
  useEffect(() => {
    if (typeof window !== 'undefined' && 'ontouchstart' in window) {
      setShowControls(true);
    }
  }, []);

  // Proximity detection: Find station within interactive circle radius
  const activeStation = useMemo(() => {
    for (const st of stations) {
      const dist = Math.hypot(player.x - st.x, player.y - st.y);
      if (dist <= st.radius + 15) {
        return st;
      }
    }
    return null;
  }, [stations, player.x, player.y]);

  // Automatic station info pop-up the moment the figure is in the circle
  // and auto-close the moment figure walks out of circle (no ESC key required!)
  useEffect(() => {
    if (activeStation) {
      playApproachSound(activeStation.id);

      // When reaching station circle: automatically pop up the segment
      if (
        autoPopupEnabled &&
        dismissedStationIdRef.current !== activeStation.id &&
        selectedStation?.id !== activeStation.id
      ) {
        playOpenSound();
        setSelectedStation(activeStation);
        setPopupAlert(`Inside ${activeStation.shortName} circle — Segment opened`);
        const timer = setTimeout(() => setPopupAlert(null), 3000);
        return () => clearTimeout(timer);
      }
    } else {
      // Left the station circle: automatically close the segment without needing to press ESC!
      if (!isPinnedRef.current && selectedStation) {
        setSelectedStation(null);
      }
      dismissedStationIdRef.current = null;
    }
  }, [activeStation, autoPopupEnabled, selectedStation]);

  // Handle initial station if requested
  useEffect(() => {
    if (initialStationId) {
      const match = stations.find((s) => s.id === initialStationId);
      if (match) {
        setSelectedStation(match);
      }
    }
  }, [initialStationId, stations]);

  const handleCloseModal = useCallback(() => {
    if (selectedStation) {
      dismissedStationIdRef.current = selectedStation.id;
    }
    setSelectedStation(null);
  }, [selectedStation]);

  const handleInteract = useCallback((station: StationDef) => {
    dismissedStationIdRef.current = null;
    playOpenSound();
    setSelectedStation(station);
  }, []);

  const handleWalkToStation = (station: StationDef) => {
    dismissedStationIdRef.current = null;
    setPlayer((prev) => ({
      ...prev,
      target: { x: station.x, y: station.y + 40 },
    }));
  };

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    setSoundEnabled(next);
  };

  // Virtual control inputs
  const handleMoveStart = (dir: Direction) => {
    const targetMap: Record<Direction, { dx: number; dy: number }> = {
      up: { dx: 0, dy: -120 },
      down: { dx: 0, dy: 120 },
      left: { dx: -120, dy: 0 },
      right: { dx: 120, dy: 0 },
    };
    const offset = targetMap[dir];
    setPlayer((prev) => ({
      ...prev,
      target: {
        x: Math.max(80, Math.min(1120, prev.x + offset.dx)),
        y: Math.max(80, Math.min(820, prev.y + offset.dy)),
      },
    }));
  };

  const handleMoveEnd = () => {
    // Let target finish or stop
  };

  return (
    <div className="relative flex flex-col w-full h-[calc(100vh-6rem)] min-h-[580px] max-h-[920px] bg-ink-950 rounded-2xl border border-line overflow-hidden shadow-2xl">
      {/* Game HUD Top Bar */}
      <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 bg-ink-900/95 border-b border-line z-30 select-none">
        {/* Track Title & Badge & Switcher */}
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-accent-500/20 border border-accent-400 text-accent-400 flex items-center justify-center font-bold text-sm">
            <Compass className="h-4 w-4 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-fg">
                {track === 'recovery' ? 'Adult Recovery Campus' : 'Youth Sanctuary'}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-accent-500/15 text-accent-400 border border-accent-400/30 font-semibold">
                {renderMode === '3d' ? '3D Live' : '2D Radar'}
              </span>
            </div>
            <p className="text-[10px] text-muted hidden sm:block">
              {renderMode === '3d'
                ? 'Explore the 3D sanctuary — reaching any station automatically opens its terminal'
                : 'Interactive sanctuary grounds — auto-pops info upon arrival'}
            </p>
          </div>
        </div>

        {/* Action Controls & Toggles */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* 3D / 2D Mode Switcher */}
          <button
            type="button"
            onClick={() => setRenderMode((m) => (m === '3d' ? '2d' : '3d'))}
            className={`tap-target flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition ${
              renderMode === '3d'
                ? 'bg-accent-500 text-ink-950 border-accent-400 font-bold shadow-sm'
                : 'bg-ink-950 text-muted border-line hover:text-fg'
            }`}
            title="Toggle between 3D World and 2D Tactical View"
          >
            {renderMode === '3d' ? <Box className="h-3.5 w-3.5" /> : <Layers className="h-3.5 w-3.5" />}
            <span>{renderMode === '3d' ? '3D' : '2D'}</span>
          </button>

          {/* Auto-Popup Toggle */}
          <button
            type="button"
            onClick={() => setAutoPopupEnabled((v) => !v)}
            className={`tap-target hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition ${
              autoPopupEnabled
                ? 'bg-accent-500/15 text-accent-400 border-accent-400/40'
                : 'bg-ink-950 text-subtle border-line hover:text-fg'
            }`}
            title="Toggle auto-opening info terminal when reaching station"
          >
            <Zap className="h-3.5 w-3.5 text-accent-400" />
            <span>Auto-Popup: {autoPopupEnabled ? 'ON' : 'OFF'}</span>
          </button>

          {/* Station Directory Fast-Travel */}
          <button
            type="button"
            onClick={() => setShowDirectory(true)}
            className="tap-target flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-line bg-ink-950 text-xs font-medium text-fg hover:bg-ink-800 transition"
            title="Open Station Directory"
          >
            <MapPin className="h-3.5 w-3.5 text-accent-400" />
            <span className="hidden xs:inline">Stations</span>
          </button>

          {/* Touch D-Pad Toggle */}
          <button
            type="button"
            onClick={() => setShowControls((v) => !v)}
            className={`tap-target p-1.5 rounded-lg border text-xs transition ${
              showControls
                ? 'bg-accent-500 text-ink-950 border-accent-400 font-bold'
                : 'bg-ink-950 text-muted border-line hover:text-fg'
            }`}
            title="Toggle On-Screen Virtual D-pad"
            aria-label="Toggle Virtual Controls"
          >
            <Smartphone className="h-4 w-4" />
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={toggleSound}
            className="tap-target p-1.5 rounded-lg border border-line bg-ink-950 text-muted hover:text-fg transition"
            title={sound ? 'Mute Audio Chimes' : 'Enable Audio Chimes'}
            aria-label={sound ? 'Mute Audio Chimes' : 'Enable Audio Chimes'}
          >
            {sound ? <Volume2 className="h-4 w-4 text-accent-400" /> : <VolumeX className="h-4 w-4" />}
          </button>

          {/* Switch to Classic List View */}
          <button
            type="button"
            onClick={onSwitchToListMode}
            className="tap-target flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-line bg-ink-950 text-xs font-semibold text-muted hover:text-fg transition hover:border-accent-400"
            title="Switch to standard list view"
          >
            <List className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Classic List</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="relative flex-1 w-full overflow-hidden bg-ink-950">
        {/* Render 3D World (default) or 2D Tactical View */}
        {renderMode === '3d' ? (
          <GameCanvas3D
            stations={stations}
            player={player}
            onPlayerChange={setPlayer}
            onInteract={handleInteract}
            activeStation={activeStation}
            autoPopupEnabled={autoPopupEnabled}
          />
        ) : (
          <GameCanvas
            stations={stations}
            player={player}
            onPlayerChange={setPlayer}
            onInteract={handleInteract}
            activeStation={activeStation}
          />
        )}

        {/* Reached Station Auto-Popup Toast Notification */}
        {popupAlert ? (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-none flex items-center gap-2 px-4 py-2 rounded-full bg-accent-500 text-ink-950 font-bold text-xs shadow-2xl animate-fade-in border border-accent-300">
            <Sparkles className="h-4 w-4" />
            <span>{popupAlert}</span>
          </div>
        ) : null}

        {/* Floating MiniMap (Top Right) */}
        <div className="absolute top-3 right-3 z-20 pointer-events-auto">
          <MiniMap
            stations={stations}
            player={player}
            onStationClick={handleWalkToStation}
            activeStation={activeStation}
          />
        </div>

        {/* Floating Proximity Prompt (Bottom Center Desktop) when station is active but modal closed */}
        {activeStation && !selectedStation ? (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 pointer-events-auto animate-bounce-subtle">
            <button
              type="button"
              onClick={() => handleInteract(activeStation)}
              className="tap-target flex items-center gap-2.5 px-5 py-2.5 rounded-xl bg-accent-500 text-ink-950 font-bold text-sm shadow-2xl border border-accent-300 hover:scale-105 transition"
            >
              <Sparkles className="h-4 w-4" />
              <span>Click to Re-open {activeStation.shortName} Info [E]</span>
            </button>
          </div>
        ) : null}

        {/* Instructions banner on bottom left */}
        {showHelpHint ? (
          <div className="absolute bottom-3 left-3 z-10 hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-ink-950/90 border border-line text-[11px] text-muted backdrop-blur-md">
            <Info className="h-3.5 w-3.5 text-accent-400 shrink-0" />
            <span>
              Use <span className="text-fg font-mono font-bold">W A S D</span> or click anywhere to walk. Reach any station pad to automatically open info.
            </span>
            <button
              type="button"
              onClick={() => setShowHelpHint(false)}
              className="ml-1 text-subtle hover:text-fg text-xs"
              aria-label="Dismiss help hint"
            >
              ✕
            </button>
          </div>
        ) : null}

        {/* Virtual Controls for touch/mobile */}
        {showControls ? (
          <VirtualControls
            onMoveStart={handleMoveStart}
            onMoveEnd={handleMoveEnd}
            onInteract={() => {
              if (activeStation) handleInteract(activeStation);
            }}
            activeStation={activeStation}
          />
        ) : null}
        {/* Station Modal (Interactive Terminal Docked / Pop-Up) */}
        {selectedStation ? (
          <StationModal
            station={selectedStation}
            stations={stations}
            onClose={handleCloseModal}
            onSelectStation={(st) => {
              dismissedStationIdRef.current = st.id;
              setSelectedStation(st);
            }}
            onOpenCrisisSheet={() => {
              handleCloseModal();
              openCrisisSheet();
            }}
            isInsideCircle={Boolean(activeStation && activeStation.id === selectedStation.id)}
            isPinned={isPinned}
            onTogglePinned={() => setIsPinned((p) => !p)}
          />
        ) : null}
      </div>

      {/* Fast-Travel Directory Drawer */}
      {showDirectory ? (
        <StationDirectory
          stations={stations}
          player={player}
          onSelectStation={handleInteract}
          onTeleportToStation={handleWalkToStation}
          onClose={() => setShowDirectory(false)}
        />
      ) : null}
    </div>
  );
}
