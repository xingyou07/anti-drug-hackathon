import { useState } from 'react';
import { Compass, Volume2, VolumeX, Sparkles, Navigation, X } from 'lucide-react';
import type { PlayerState, StationDef } from './types';
import { isSoundEnabled, setSoundEnabled } from './sound';

interface Props {
  stations: StationDef[];
  player: PlayerState;
  onSelectStation: (station: StationDef) => void;
  onTeleportToStation: (station: StationDef) => void;
  onClose: () => void;
}

export function StationDirectory({
  stations,
  player,
  onSelectStation,
  onTeleportToStation,
  onClose,
}: Props): JSX.Element {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [sound, setSound] = useState(isSoundEnabled());

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    setSoundEnabled(next);
  };

  const categories = ['All', ...Array.from(new Set(stations.map((s) => s.tag)))];

  const filtered = activeCategory === 'All'
    ? stations
    : stations.filter((s) => s.tag === activeCategory);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Station Directory"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative w-full max-w-lg max-h-[85vh] flex flex-col rounded-2xl bg-ink-950 border border-line shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-line bg-ink-900">
          <div className="flex items-center gap-2.5">
            <Compass className="h-5 w-5 text-accent-400" />
            <div>
              <h2 className="font-bold text-fg text-base">Station Directory & Fast Travel</h2>
              <p className="text-xs text-muted">Navigate to any station on the Sanctuary map</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleSound}
              className="tap-target p-2 rounded-xl border border-line bg-ink-950 text-muted hover:text-fg transition"
              title={sound ? 'Mute Game Sounds' : 'Enable Game Sounds'}
              aria-label={sound ? 'Mute Game Sounds' : 'Enable Game Sounds'}
            >
              {sound ? <Volume2 className="h-4 w-4 text-accent-400" /> : <VolumeX className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="tap-target p-2 rounded-xl border border-line bg-ink-950 text-muted hover:text-fg transition"
              aria-label="Close directory"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Category filter pills */}
        <div className="flex gap-1.5 overflow-x-auto p-3 border-b border-line bg-ink-900/50 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`tap-target shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                cat === activeCategory
                  ? 'bg-accent-500 text-ink-950 font-semibold'
                  : 'bg-ink-900 border border-line text-muted hover:text-fg'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Stations list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filtered.map((st) => {
            const dist = Math.round(Math.hypot(player.x - st.x, player.y - st.y));
            return (
              <div
                key={st.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-line bg-ink-900 p-3.5 hover:border-ink-600 transition"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="h-9 w-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 border"
                    style={{
                      backgroundColor: `${st.colorHex}22`,
                      borderColor: st.colorHex,
                      color: st.colorHex,
                    }}
                  >
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-sm text-fg truncate">{st.title}</p>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border border-line text-subtle">
                        {st.tag}
                      </span>
                    </div>
                    <p className="text-xs text-muted truncate mt-0.5">{st.description}</p>
                    <p className="text-[10px] font-mono text-subtle mt-0.5">~{dist}px away</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      onTeleportToStation(st);
                      onClose();
                    }}
                    className="tap-target flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-line bg-ink-950 text-xs font-medium text-muted hover:text-fg transition"
                    title="Walk character to this station"
                  >
                    <Navigation className="h-3.5 w-3.5 text-accent-400" />
                    <span>Walk</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSelectStation(st);
                      onClose();
                    }}
                    className="tap-target px-3 py-1.5 rounded-lg bg-accent-500 text-ink-950 text-xs font-bold transition hover:bg-accent-400"
                  >
                    Enter
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
