import type { Hours } from '@/lib/hours';

/** Every content file carries a review status (constraint 5). */
export type ContentStatus = 'UNREVIEWED_PLACEHOLDER' | 'SEED_VERIFIED';

export interface ContentEnvelope {
  status: ContentStatus;
  reviewedBy: string | null;
  reviewedOn: string | null;
}

export interface CrisisResource {
  id: string;
  name: string;
  number: string;
  channel: 'voice' | 'whatsapp';
  blurb: string;
  hours: Hours;
  lastVerified: string | null;
  note?: string;
}

export interface CrisisResourcesFile extends ContentEnvelope {
  note: string;
  todo: string;
  resources: CrisisResource[];
}

export interface OnboardingOption {
  track: 'youth' | 'recovery';
  label: string;
  detail: string;
}

export interface OnboardingStep {
  id: string;
  title: string;
  body: string[];
  options?: OnboardingOption[];
}

export interface OnboardingFile extends ContentEnvelope {
  todo: string;
  steps: OnboardingStep[];
}

export interface PrivacyFile extends ContentEnvelope {
  todo: string;
  title: string;
  summary: string;
  sections: Array<{ heading: string; body: string }>;
}

export interface AppMetaFile extends ContentEnvelope {
  displayName: string;
  disclaimer: string;
  placeholderChipLabel: string;
  unconfirmedNumberNote: string;
}

export interface UrgeSurfFile extends ContentEnvelope {
  todo: string;
  durationSeconds: number;
  curveNote: string;
  title: string;
  lede: string;
  startLabel: string;
  prompts: string[];
  completion: { title: string; body: string; counterLabel: string };
  earlyStop: { title: string; body: string };
}

export interface BreathingPhase {
  label: string;
  seconds: number;
  grow: boolean;
}

export interface BreathingPattern {
  id: 'box' | 'sigh';
  name: string;
  summary: string;
  detail: string;
  phases: BreathingPhase[];
}

export interface BreathingFile extends ContentEnvelope {
  todo: string;
  patterns: BreathingPattern[];
  defaultPrompt: string;
}

export interface GroundingFile extends ContentEnvelope {
  todo: string;
  title: string;
  lede: string;
  steps: Array<{ count: number; sense: string; hint: string }>;
  completion: { title: string; body: string };
}

export type RefusalTone = 'light' | 'flat' | 'firm';

export interface RefusalContext {
  id: string;
  label: string;
  blurb: string;
  tags: string[];
  tones: Record<RefusalTone, string[]>;
}

export interface RefusalScriptsFile extends ContentEnvelope {
  todo: string;
  toneLabels: Record<RefusalTone, string>;
  ladderLabels: string[];
  contexts: RefusalContext[];
}

export interface FakeCallFile extends ContentEnvelope {
  todo: string;
  title: string;
  lede: string;
  audioNote: string;
  callerPresets: string[];
  delayOptions: Array<{ seconds: number; label: string }>;
  armedLabel: string;
  exitLine: string;
}

export interface LegalExplainerFile extends ContentEnvelope {
  todo: string;
  title: string;
  body: string[];
  crisisNote: string;
}

/* ---------------------------------------------------------------------------
 * Ripple (the youth-track game). All copy lives in ripple.json.
 * ------------------------------------------------------------------------- */

export type RippleEffect = 'steady' | 'wobble' | 'strain';

export interface RippleFact {
  text: string;
  source: string;
  sourceUrl: string;
}

export interface RippleLine {
  /** A person id from `people`, or 'narrator'. */
  who: string;
  text: string;
}

export interface RippleChoice {
  id: string;
  label: string;
  effect: RippleEffect;
  reaction: RippleLine[];
  ripple: Array<{ person: string; effect: RippleEffect; text: string }>;
  learn: string;
  /** Emergency moment only: the player is sent back to choose again. */
  redo?: boolean;
}

export interface RipplePractice {
  kind: 'refuse' | 'checkin';
  friendId: string;
  friendName: string;
  opener: string;
  scenario: string;
}

export type RippleLandmark = 'void-deck' | 'hawker' | 'mrt' | 'library' | 'kopitiam' | 'playground';

export interface RippleMoment {
  id: string;
  order: number;
  landmark: RippleLandmark;
  kind: 'offer' | 'chat' | 'checkin' | 'emergency';
  format: 'face' | 'chat';
  pressure: 1 | 2 | 3;
  place: string;
  timeLabel: string;
  title: string;
  setup: string;
  npcs: string[];
  lines: RippleLine[];
  prompt: string;
  choices: RippleChoice[];
  factIds: string[];
  practice?: RipplePractice;
}

export interface RippleFile extends ContentEnvelope {
  todo: string;
  title: string;
  tagline: string;
  lede: string;
  howToPlay: string[];
  confidence: {
    intro: string;
    scaleLabels: string[];
    items: Array<{ id: string; prompt: string }>;
  };
  effectLabels: Record<RippleEffect, string>;
  people: Record<string, { name: string; role: string }>;
  facts: Record<string, RippleFact>;
  moments: RippleMoment[];
  finale: {
    title: string;
    lede: string;
    confidenceHeading: string;
    takeawaysHeading: string;
    takeaways: string[];
    commitHeading: string;
    commitOptions: Array<{ id: string; label: string }>;
    commitDone: string;
    practiceHeading: string;
    practiceSub: string;
    nextPlayer: string;
    helpButton: string;
  };
  practice: {
    title: string;
    sub: string;
    placeholder: string;
    send: string;
    skip: string;
    privacy: string;
    offlineNote: string;
    onlineNote: string;
    maxTurns: number;
    maxChars: number;
    starters: string[];
    checkinStarters: string[];
    crisisNote: string;
  };
  labels: Record<string, string>;
}
