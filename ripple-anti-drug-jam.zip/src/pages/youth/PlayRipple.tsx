import { RippleGame } from '@/game/ripple/RippleGame';

/** Youth-track home. The recovery track never routes here (RequireTrack guards /youth). */
export function PlayRipple(): JSX.Element {
  return (
    <div className="px-0 pt-0 sm:px-4 sm:pt-3">
      <RippleGame />
    </div>
  );
}
