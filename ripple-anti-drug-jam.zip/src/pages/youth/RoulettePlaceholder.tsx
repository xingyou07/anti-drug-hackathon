import { ScreenHeader } from '@/components/ScreenHeader';
import { RouletteEngine } from '@/features/youth/RouletteEngine';
import { useNavigate } from 'react-router-dom';

/**
 * The four-step Roulette Engine.
 * Note: Youth-only route (enforced by RequireTrack in TrackGuards.tsx - constraint 12).
 * Strictly adheres to Constraint 11 (No RNG, deterministic resolve order, no replay button).
 */
export function RoulettePlaceholder(): JSX.Element {
  const navigate = useNavigate();

  return (
    <div className="px-4 pb-32">
      <ScreenHeader
        title="The hundred"
        lede="One choice, a hundred versions of you. You don't get to know which one you were."
      />
      <RouletteEngine
        onNavigateToScripts={() => navigate('/youth')}
        onNavigateToSomeone={() => navigate('/youth')}
      />
    </div>
  );
}
