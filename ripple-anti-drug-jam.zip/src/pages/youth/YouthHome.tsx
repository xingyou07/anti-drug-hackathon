import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ScreenHeader } from '@/components/ScreenHeader';
import { InteractiveWorld } from '@/game/InteractiveWorld';
import { Gamepad2 } from 'lucide-react';

interface Tile {
  to: string;
  title: string;
  detail: string;
  phase: string | null;
  stationId?: string;
}

const TILES: Tile[] = [
  {
    to: '/roulette',
    title: 'The hundred',
    detail: "One choice, a hundred versions of you. You don't get to know which one you were.",
    phase: null,
    stationId: 'roulette',
  },
  {
    to: '/youth',
    title: 'Pressure scenarios',
    detail: 'Practise getting out of a moment across 6 real situations.',
    phase: null,
    stationId: 'pressure',
  },
  {
    to: '/youth',
    title: 'Reality check',
    detail: 'What you think everyone does, versus official Singapore statistics.',
    phase: null,
    stationId: 'reality',
  },
  {
    to: '/youth',
    title: 'Literacy challenge',
    detail: 'Synthetic substances, etomidate in vapes, and honest odds.',
    phase: null,
    stationId: 'literacy',
  },
  {
    to: '/youth',
    title: 'Someone you know is using',
    detail: 'What to do, what not to do, and who to call when a friend is struggling.',
    phase: null,
    stationId: 'someone',
  },
  {
    to: '/youth',
    title: 'Crisis Lighthouse',
    detail: 'Helplines in Singapore, one tap away. No tracking.',
    phase: null,
    stationId: 'crisis',
  },
];

export function YouthHome(): JSX.Element {
  const [viewMode, setViewMode] = useState<'game' | 'list'>(() => {
    try {
      const saved = localStorage.getItem('ten_percent_view_mode_youth');
      if (saved === 'game') return 'game';
    } catch {
      // Ignore
    }
    // Ripple is the game now (the /youth home); this page is the tools shelf, so it opens as a list.
    return 'list';
  });

  const [targetStation, setTargetStation] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('ten_percent_view_mode_youth', viewMode);
    } catch {
      // Ignore
    }
  }, [viewMode]);

  if (viewMode === 'game') {
    return (
      <div className="px-2 sm:px-4 pb-24">
        <InteractiveWorld
          track="youth"
          onSwitchToListMode={() => setViewMode('list')}
          initialStationId={targetStation}
        />
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between px-4 pt-2">
        <ScreenHeader title="Stay informed" lede="Short things, none of them a lecture." />
        <button
          type="button"
          onClick={() => {
            setTargetStation(null);
            setViewMode('game');
          }}
          className="tap-target flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-accent-500 text-ink-950 font-bold text-xs shadow-lg hover:bg-accent-400 transition"
        >
          <Gamepad2 className="h-4 w-4" />
          <span>Interactive World (WASD)</span>
        </button>
      </div>

      <div className="flex flex-col gap-3 px-4 pb-28">
        <Link
          to="/youth"
          className="rounded-xl2 border border-teal-400/40 bg-gradient-to-r from-teal-400/15 to-fuchsia-400/15 p-4 transition hover:border-teal-300"
        >
          <span className="text-lg font-semibold text-fg">Play Ripple</span>
          <span className="mt-1 block text-sm leading-relaxed text-muted">
            Walk through six moments in first and third person, and see who each choice reaches.
          </span>
        </Link>
        {TILES.map((tile) => (
          <div
            key={tile.title}
            className="flex items-center justify-between rounded-xl2 border border-line bg-ink-900 p-4 transition hover:border-accent-400 hover:bg-ink-800"
          >
            <Link
              to={tile.to}
              className="flex-1 min-w-0"
              onClick={(e) => {
                if (tile.stationId && tile.to === '/youth') {
                  e.preventDefault();
                  setTargetStation(tile.stationId);
                  setViewMode('game');
                }
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <span className="text-lg font-semibold text-fg">{tile.title}</span>
                {tile.phase ? (
                  <span className="shrink-0 rounded-full border border-line px-2 py-0.5 text-xs text-subtle">
                    {tile.phase}
                  </span>
                ) : null}
              </div>
              <span className="mt-1 block text-sm leading-relaxed text-muted">{tile.detail}</span>
            </Link>

            {tile.stationId ? (
              <button
                type="button"
                onClick={() => {
                  setTargetStation(tile.stationId ?? null);
                  setViewMode('game');
                }}
                className="tap-target ml-3 p-2 rounded-xl border border-line bg-ink-950 text-muted hover:text-accent-400 hover:border-accent-400 text-xs flex items-center gap-1 shrink-0"
                title="Open station in Interactive World"
              >
                <Gamepad2 className="h-4 w-4" />
              </button>
            ) : null}
          </div>
        ))}
      </div>
    </>
  );
}
