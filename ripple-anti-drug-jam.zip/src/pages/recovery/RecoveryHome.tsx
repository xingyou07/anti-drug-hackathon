import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ScreenHeader } from '@/components/ScreenHeader';
import { useAppState } from '@/state/AppStateContext';
import { InteractiveWorld } from '@/game/InteractiveWorld';
import { Gamepad2 } from 'lucide-react';

interface Tile {
  to: string;
  title: string;
  detail: string;
  phase: string | null;
  stationId?: string;
}

const TILES: Tile[] = [
  { to: '/recovery/urge-surf', title: 'Ride the wave', detail: 'Fifteen minutes. It comes down on its own.', phase: null, stationId: 'urge-surf' },
  { to: '/recovery/breathe', title: 'Breathe', detail: 'Box breathing, or a physiological sigh.', phase: null, stationId: 'breathe' },
  { to: '/recovery/grounding', title: 'Grounding', detail: '5-4-3-2-1, one sense at a time.', phase: null, stationId: 'grounding' },
  { to: '/recovery/scripts', title: 'Refusal scripts', detail: 'Words for when one "no" is not enough.', phase: null, stationId: 'scripts' },
  { to: '/recovery/fake-call', title: 'Fake call', detail: 'A reason to walk out of a room.', phase: null, stationId: 'fake-call' },
  { to: '/recovery/legal', title: 'Am I going to get in trouble?', detail: "The question most people have first. Singapore legal rights, CNB procedures.", phase: null, stationId: 'legal' },
  { to: '/recovery', title: 'Trigger zones', detail: 'Simulated geofencing radar, never accessing your real GPS.', phase: null, stationId: 'trigger-zones' },
  { to: '/recovery', title: 'Crisis Lighthouse', detail: 'Direct access to 24/7 verified emergency lines.', phase: null, stationId: 'crisis' },
];

export function RecoveryHome(): JSX.Element {
  const { state } = useAppState();
  const totalWaves = Object.values(state.recovery.wavesRidden).reduce((sum, n) => sum + n, 0);

  const [viewMode, setViewMode] = useState<'game' | 'list'>(() => {
    try {
      const saved = localStorage.getItem('ten_percent_view_mode_recovery');
      if (saved === 'list') return 'list';
    } catch {
      // Ignore
    }
    return 'game'; // Gamified mode default per user request
  });

  const [targetStation, setTargetStation] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('ten_percent_view_mode_recovery', viewMode);
    } catch {
      // Ignore
    }
  }, [viewMode]);

  if (viewMode === 'game') {
    return (
      <div className="px-2 sm:px-4 pb-24">
        <InteractiveWorld
          track="recovery"
          onSwitchToListMode={() => setViewMode('list')}
          initialStationId={targetStation}
        />
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between px-4 pt-2">
        <ScreenHeader title="You're here" lede="Whatever today is, this is the right place to be." />
        <button
          type="button"
          onClick={() => {
            setTargetStation(null);
            setViewMode('game');
          }}
          className="tap-target flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-accent-500 text-ink-950 font-bold text-xs shadow-lg hover:bg-accent-400 transition"
        >
          <Gamepad2 className="h-4 w-4" />
          <span>Interactive World (WASD)</span>
        </button>
      </div>

      {totalWaves > 0 ? (
        <div className="mx-4 mb-4 rounded-xl2 border border-line bg-ink-900 p-4">
          <p className="text-sm text-muted">Waves ridden</p>
          <p className="text-3xl font-bold tabular-nums">{totalWaves}</p>
        </div>
      ) : null}

      <div className="flex flex-col gap-3 px-4 pb-28">
        {TILES.map((tile) => (
          <div
            key={tile.title}
            className="flex items-center justify-between rounded-xl2 border border-line bg-ink-900 p-4 transition hover:border-accent-400 hover:bg-ink-800"
          >
            <Link
              to={tile.to}
              className="flex-1 min-w-0"
              onClick={(e) => {
                if (tile.stationId && tile.to === '/recovery') {
                  e.preventDefault();
                  setTargetStation(tile.stationId);
                  setViewMode('game');
                }
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <span className="text-lg font-semibold text-fg">{tile.title}</span>
                {tile.phase ? (
                  <span className="shrink-0 rounded-full border border-line px-2 py-0.5 text-xs text-subtle">
                    {tile.phase}
                  </span>
                ) : null}
              </div>
              <span className="mt-1 block text-sm leading-relaxed text-muted">{tile.detail}</span>
            </Link>

            {tile.stationId ? (
              <button
                type="button"
                onClick={() => {
                  setTargetStation(tile.stationId ?? null);
                  setViewMode('game');
                }}
                className="tap-target ml-3 p-2 rounded-xl border border-line bg-ink-950 text-muted hover:text-accent-400 hover:border-accent-400 text-xs flex items-center gap-1 shrink-0"
                title="Open station in Interactive World"
              >
                <Gamepad2 className="h-4 w-4" />
              </button>
            ) : null}
          </div>
        ))}
      </div>
    </>
  );
}
