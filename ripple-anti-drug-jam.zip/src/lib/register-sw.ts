/**
 * Registration only. The worker itself is a static file in /public so it is
 * served at the app's scope root. No build-time plugin, so nothing about the
 * offline behaviour is hidden from review.
 *
 * Not registered in the dev server: its un-hashed module URLs would be served
 * cache-first and show stale code while editing (and in AI Studio's live
 * preview). Any worker left over from an earlier build is removed there.
 */
export function registerServiceWorker(): void {
  if (!('serviceWorker' in navigator)) return;

  if (import.meta.env.DEV) {
    navigator.serviceWorker
      .getRegistrations()
      .then((regs) => regs.forEach((r) => void r.unregister()))
      .catch(() => undefined);
    return;
  }

  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // Offline support is an enhancement; failing to register must never
      // break the app or the crisis path.
    });
  });
}
