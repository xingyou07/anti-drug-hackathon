import { useState } from 'react';
import { PlaceholderChip } from '@/components/PlaceholderChip';
import { SourceCitation } from '@/components/SourceCitation';
import { rippleContent } from '@/content';

interface Question {
  q: string;
  options: string[];
  correctIndex: number;
  /** Key into ripple.json `facts`: the explanation IS the sourced fact, so a question can't ship without a citation. */
  factId: string;
}

const QUESTIONS: Question[] = [
  {
    q: "Why can't anyone tell you what is really in an illicit vape?",
    options: [
      'They are made under regulated factory controls',
      'They are not made or tested under any safety checks, and many are laced',
      'The battery decides what goes in the liquid',
    ],
    correctIndex: 1,
    factId: 'laced',
  },
  {
    q: 'Since 1 May 2026, how does Singapore law treat etomidate?',
    options: [
      'It is legal for adults',
      "It is a 'specified psychoactive substance' under the Tobacco and Vaporisers Control Act",
      'Only selling it is an offence',
    ],
    correctIndex: 1,
    factId: 'etomidate',
  },
  {
    q: 'You are a Singapore citizen on a trip abroad. Does Singapore drug law still apply to you?',
    options: [
      'No. It only applies inside Singapore',
      'Yes. Consuming controlled drugs overseas is also an offence for citizens and PRs',
      'Only if the trip is for work',
    ],
    correctIndex: 1,
    factId: 'overseas',
  },
  {
    q: "A friend can't be woken up after taking something. What comes first?",
    options: [
      'Let them sleep it off',
      'Call 995, give the location and stay on the line',
      'Message the group chat and wait',
    ],
    correctIndex: 1,
    factId: 'call995',
  },
];

export function LiteracyChallenge(): JSX.Element {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const question = QUESTIONS[currentIdx] ?? QUESTIONS[0]!;
  const fact = rippleContent.facts[question.factId];

  const handleSelect = (idx: number): void => {
    if (showExplanation) return;
    setSelectedOpt(idx);
    setShowExplanation(true);
  };

  const handleNext = (): void => {
    setSelectedOpt(null);
    setShowExplanation(false);
    setCurrentIdx((prev) => (prev + 1) % QUESTIONS.length);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight text-fg">Drug Literacy Challenge</h2>
        <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
      </div>
      <div className="flex items-center justify-between text-xs font-mono text-subtle">
        <span>QUESTION {currentIdx + 1} OF {QUESTIONS.length}</span>
        <span>NO TRICK ANSWERS</span>
      </div>

      <div className="rounded-xl2 border border-line bg-ink-900 p-4 space-y-4">
        <p className="text-base font-semibold text-fg leading-snug">{question.q}</p>

        <div className="space-y-2">
          {question.options.map((opt, idx) => {
            const isSelected = selectedOpt === idx;
            const isCorrect = idx === question.correctIndex;
            let btnStyle = 'border-line bg-ink-950 text-fg hover:border-ink-600';
            if (showExplanation) {
              if (isCorrect) {
                btnStyle = 'border-accent-400 bg-accent-950/40 text-accent-300 font-semibold';
              } else if (isSelected) {
                btnStyle = 'border-crisis-500 bg-crisis-950/40 text-crisis-300';
              } else {
                btnStyle = 'border-line/40 bg-ink-950/40 text-muted opacity-60';
              }
            }
            return (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelect(idx)}
                className={`tap-target w-full text-left rounded-xl border p-3.5 text-sm transition ${btnStyle}`}
              >
                <div className="flex items-start gap-2.5">
                  <span className="font-mono text-xs text-subtle mt-0.5">{String.fromCharCode(65 + idx)}.</span>
                  <span className="leading-snug">{opt}</span>
                </div>
              </button>
            );
          })}
        </div>

        {showExplanation && fact ? (
          <div className="rounded-xl border border-line/80 bg-ink-950 p-3.5 space-y-3">
            <p className="text-xs text-muted leading-relaxed">
              <span className="font-semibold text-fg">Fact check: </span>
              {fact.text} <SourceCitation source={fact.source} sourceUrl={fact.sourceUrl} />
            </p>
            <button
              type="button"
              onClick={handleNext}
              className="tap-target w-full rounded-lg bg-accent-500 text-ink-950 font-bold py-2 text-xs transition hover:bg-accent-400"
            >
              {currentIdx < QUESTIONS.length - 1 ? 'Next question →' : 'Review from the start ↻'}
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
}
