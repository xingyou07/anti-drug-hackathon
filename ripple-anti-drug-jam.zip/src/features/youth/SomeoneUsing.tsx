import { PlaceholderChip } from '@/components/PlaceholderChip';

export function SomeoneUsing(): JSX.Element {
  const items = [
    {
      title: "Don't make it a confrontation.",
      body: 'Ultimatums usually cost you the one line of contact they still have with someone sober.',
    },
    {
      title: 'Ask, then stop talking.',
      body: '“You\'ve seemed off lately — what\'s going on?” and then let the silence sit without rushing to solve it.',
    },
    {
      title: 'Know the critical emergency signs.',
      body: 'Unconscious, slow breathing, seizures/fitting, or completely unresponsive: call 995 immediately without delay.',
    },
    {
      title: 'You are not their treatment plan.',
      body: 'Getting them to reach out to one helpline or service (such as NAMS or WE CARE) is a big step. The rest is not yours to shoulder alone.',
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight text-fg">Someone You Know Is Using</h2>
        <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
      </div>
      <p className="text-sm text-muted">
        Practical steps when someone close to you is experimenting or in distress.
      </p>

      <div className="space-y-3">
        {items.map((item, i) => (
          <div key={i} className="rounded-xl border border-line bg-ink-900 p-4">
            <p className="font-semibold text-fg text-sm">{item.title}</p>
            <p className="text-xs text-muted mt-1 leading-relaxed">{item.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
