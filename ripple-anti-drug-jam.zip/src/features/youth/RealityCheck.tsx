import { useState } from 'react';
import { PlaceholderChip } from '@/components/PlaceholderChip';
import { SourceCitation } from '@/components/SourceCitation';
import { rippleContent } from '@/content';

/**
 * Guess-the-number built on one sourced official figure. The earlier version
 * showed a "6 / 100" survey baseline that had no source, so it was removed
 * (constraint 13: no unsourced statistics).
 */
const OPTIONS: Array<{ label: string; correct: boolean }> = [
  { label: 'Fewer than 100', correct: false },
  { label: 'A few hundred', correct: false },
  { label: 'About a thousand', correct: false },
  { label: 'More than 2,000', correct: true },
];

export function RealityCheck(): JSX.Element {
  const [picked, setPicked] = useState<number | null>(null);
  const fact = rippleContent.facts['vapeEnforcement'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight text-fg">Reality Check</h2>
        <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
      </div>
      <p className="text-sm leading-relaxed text-muted">
        In just three months (April to June 2026), how many people in Singapore were caught and penalised for possessing or using vapes?
      </p>

      <div className="space-y-2">
        {OPTIONS.map((o, i) => {
          const done = picked !== null;
          const style = !done
            ? 'border-line bg-ink-900 text-fg hover:border-accent-400'
            : o.correct
              ? 'border-accent-400 bg-accent-500/15 font-semibold text-accent-100'
              : picked === i
                ? 'border-flag-500/60 bg-flag-900/30 text-flag-200'
                : 'border-line/40 bg-ink-950/40 text-muted opacity-60';
          return (
            <button
              key={o.label}
              type="button"
              disabled={done}
              onClick={() => setPicked(i)}
              className={`tap-target w-full rounded-xl border p-3.5 text-left text-sm transition ${style}`}
            >
              {o.label}
            </button>
          );
        })}
      </div>

      {picked !== null && fact ? (
        <div className="space-y-3">
          <div className="rounded-xl2 border border-accent-500/40 bg-ink-900 p-4 text-center">
            <p className="text-xs font-mono uppercase tracking-wider text-accent-400">Official figure</p>
            <p className="mt-1 text-4xl font-bold tabular-nums text-fg">2,428</p>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              {fact.text} <SourceCitation source={fact.source} sourceUrl={fact.sourceUrl} />
            </p>
          </div>
          <p className="text-xs leading-relaxed text-subtle">
            This counts people who were caught. It does not tell you how many people you know are doing it, and it is not a survey of young people.
          </p>
        </div>
      ) : null}
    </div>
  );
}
