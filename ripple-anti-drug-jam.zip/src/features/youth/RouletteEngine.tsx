import { useEffect, useMemo, useState } from 'react';
import { PlaceholderChip } from '@/components/PlaceholderChip';
import { SourceCitation } from '@/components/SourceCitation';
import { Link } from 'react-router-dom';
import { rippleContent } from '@/content';

const DARK_SET = new Set([3, 7, 11, 19, 24, 31, 38, 42, 47, 55, 61, 68, 73, 79, 84, 90, 96]);

// Deterministic resolve order for the hundred-grid (37 is coprime with 100).
// NO Math.random anywhere in this file — strictly adhering to constraint 11.
function resolveOrder(i: number): number {
  return (i * 37) % 100;
}

function Silhouette({ className }: { className?: string }): JSX.Element {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <circle cx="12" cy="7" r="4" />
      <path d="M4 21v-2a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2" />
    </svg>
  );
}

function HundredGrid(): JSX.Element {
  const [lit, setLit] = useState<Set<number>>(() => new Set());
  const [gone, setGone] = useState<Set<number>>(() => new Set());

  const reduceMotion = useMemo(
    () =>
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    []
  );

  useEffect(() => {
    if (reduceMotion) {
      const l = new Set<number>();
      const g = new Set<number>();
      for (let i = 0; i < 100; i++) (DARK_SET.has(i) ? g : l).add(i);
      setLit(l);
      setGone(g);
      return;
    }
    const timers: number[] = [];
    const step = 6000 / 100;
    for (let i = 0; i < 100; i++) {
      const timer = window.setTimeout(() => {
        if (DARK_SET.has(i)) {
          setGone((prev) => new Set(prev).add(i));
        } else {
          setLit((prev) => new Set(prev).add(i));
        }
      }, resolveOrder(i) * step);
      timers.push(timer);
    }
    return () => timers.forEach(clearTimeout);
  }, [reduceMotion]);

  return (
    <div
      className="grid grid-cols-10 gap-1.5 p-3 rounded-xl bg-ink-950 border border-line"
      role="img"
      aria-label="A hundred identical silhouettes resolving. Some go dark. You are never told which one is you."
    >
      {Array.from({ length: 100 }, (_, i) => (
        <Silhouette
          key={i}
          className={`h-5 w-5 mx-auto transition-opacity duration-500 ${
            lit.has(i)
              ? 'opacity-100 text-accent-400'
              : gone.has(i)
                ? 'opacity-15 text-slate-600'
                : 'opacity-30 text-accent-400'
          }`}
        />
      ))}
    </div>
  );
}

interface Props {
  onNavigateToScripts?: () => void;
  onNavigateToSomeone?: () => void;
  onClose?: () => void;
}

export function RouletteEngine({ onNavigateToScripts, onNavigateToSomeone }: Props): JSX.Element {
  const [step, setStep] = useState(1);
  const [resolved, setResolved] = useState(false);

  useEffect(() => {
    if (step !== 2) return;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = window.setTimeout(() => setResolved(true), reduceMotion ? 50 : 6200);
    return () => clearTimeout(timer);
  }, [step]);

  if (step === 1) {
    return (
      <div className="max-w-md mx-auto space-y-4 text-fg">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-subtle">STEP 1 OF 4</span>
          <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight">The void deck</h2>
        <p className="leading-relaxed text-muted">
          It&apos;s a Tuesday. You&apos;re sitting downstairs with people you&apos;ve known since primary school. One of them holds something out to you — not a stranger, someone whose opinion of you matters.
        </p>
        <p className="leading-relaxed text-muted">
          He says he&apos;s had it before and it&apos;s fine. He isn&apos;t lying to you. He genuinely doesn&apos;t know what is in it, because the person who sold it to him didn&apos;t know either.
        </p>
        <div className="space-y-2 pt-2">
          <button
            type="button"
            onClick={() => setStep(2)}
            className="tap-target w-full rounded-xl bg-accent-500 text-ink-950 font-bold py-3 transition hover:bg-accent-400"
          >
            Take it
          </button>
          {onNavigateToScripts ? (
            <button
              type="button"
              onClick={onNavigateToScripts}
              className="tap-target w-full rounded-xl border border-line bg-ink-900 font-semibold py-3 transition hover:bg-ink-800"
            >
              Pass
            </button>
          ) : (
            <Link
              to="/youth"
              className="tap-target block text-center w-full rounded-xl border border-line bg-ink-900 font-semibold py-3 transition hover:bg-ink-800"
            >
              Pass
            </Link>
          )}
        </div>
        <p className="text-xs text-subtle leading-relaxed">
          Both of these are real choices. Passing doesn&apos;t lead to a congratulations screen — it leads to the words you&apos;d actually need.
        </p>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="max-w-md mx-auto space-y-4 text-fg">
        <p className="text-xs font-mono text-subtle">STEP 2 OF 4</p>
        <h2 className="text-2xl font-bold tracking-tight">A hundred of you</h2>
        <p className="text-muted leading-relaxed">
          A hundred versions of you, all making this exact choice, on this exact evening.
        </p>
        <HundredGrid />
        {!resolved ? (
          <button
            type="button"
            onClick={() => setResolved(true)}
            className="tap-target w-full rounded-xl border border-line bg-ink-900 text-sm text-muted font-medium py-2.5 transition hover:bg-ink-800"
          >
            (Skip ahead)
          </button>
        ) : null}
        {resolved ? (
          <div className="space-y-4 pt-1">
            <div className="rounded-xl border border-accent-500/40 bg-accent-950/20 p-4">
              <p className="font-semibold text-fg text-lg leading-snug">
                You don&apos;t get to know which one you were. Neither did they.
              </p>
              <p className="mt-2 text-xs leading-relaxed text-subtle">
                Illustration only. The number of dark figures is not a real rate, and nobody can know the real one.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setStep(3)}
              className="tap-target w-full rounded-xl bg-accent-500 text-ink-950 font-bold py-3 transition hover:bg-accent-400"
            >
              Continue
            </button>
          </div>
        ) : null}
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className="max-w-md mx-auto space-y-4 text-fg">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-subtle">STEP 3 OF 4</span>
          <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
        </div>
        <h2 className="text-2xl font-bold tracking-tight">The honest number</h2>
        <p className="leading-relaxed text-muted">
          We called this &ldquo;The 10%.&rdquo; Here&apos;s the truth: nobody can give you the number. It isn&apos;t a fixed figure. It changes from batch to batch, because the person selling it usually doesn&apos;t know what is in it either.
        </p>
        {(['laced', 'etomidate', 'vapeEnforcement'] as const).map((id) => {
          const f = rippleContent.facts[id];
          if (!f) return null;
          return (
            <div key={id} className="rounded-xl border border-line bg-ink-900 p-4 space-y-1">
              <p className="font-semibold text-fg">{f.text}</p>
              <SourceCitation source={f.source} sourceUrl={f.sourceUrl} />
            </div>
          );
        })}
        <button
          type="button"
          onClick={() => setStep(4)}
          className="tap-target w-full rounded-xl bg-accent-500 text-ink-950 font-bold py-3 transition hover:bg-accent-400"
        >
          Continue
        </button>
      </div>
    );
  }

  // Step 4: The exit. Notice there is NO replay button anywhere (constraint 11).
  return (
    <div className="max-w-md mx-auto space-y-4 text-fg">
      <p className="text-xs font-mono text-subtle">STEP 4 OF 4</p>
      <h2 className="text-2xl font-bold tracking-tight">So what do you do with that?</h2>
      <p className="text-muted leading-relaxed">
        There is no replay, no score, and nothing to beat — this ends by handing you something you can use.
      </p>
      <div className="space-y-3">
        {onNavigateToScripts ? (
          <button
            type="button"
            onClick={onNavigateToScripts}
            className="tap-target w-full text-left rounded-xl border border-line bg-ink-900 p-4 transition hover:border-accent-400 hover:bg-ink-800"
          >
            <span className="font-bold block text-fg">What do I say when it&apos;s my friend offering?</span>
            <span className="text-sm text-muted mt-1 block">
              The words, and the two after them for when one &ldquo;no&rdquo; isn&apos;t enough.
            </span>
          </button>
        ) : null}
        {onNavigateToSomeone ? (
          <button
            type="button"
            onClick={onNavigateToSomeone}
            className="tap-target w-full text-left rounded-xl border border-line bg-ink-900 p-4 transition hover:border-accent-400 hover:bg-ink-800"
          >
            <span className="font-bold block text-fg">Someone I know is using</span>
            <span className="text-sm text-muted mt-1 block">What to do, what not to do, and who to call.</span>
          </button>
        ) : null}
      </div>
      <p className="text-xs text-subtle leading-relaxed">
        No replay button by design. A mortality module you can re-run becomes a game.
      </p>
    </div>
  );
}
