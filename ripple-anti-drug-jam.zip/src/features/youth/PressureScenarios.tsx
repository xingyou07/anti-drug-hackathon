import { useState } from 'react';
import { PlaceholderChip } from '@/components/PlaceholderChip';

interface Scenario {
  id: string;
  label: string;
  hasDrugs: boolean;
  setup: string;
  exits: Array<{ label: string; note: string }>;
}

const SCENARIOS: Scenario[] = [
  {
    id: 'void-deck',
    label: 'The void deck',
    hasDrugs: true,
    setup: "It's a Tuesday. You're sitting downstairs with people you've known since primary school. One of them holds something out — not a stranger, someone whose opinion of you matters. He says he's had it before and it's fine. He isn't lying to you; he genuinely doesn't know what is in it, because the person who sold it to him didn't know either.",
    exits: [
      { label: '"I\'m good — pass it on, don\'t waste it on me."', note: 'Light and quick. Keeps the moment small and doesn\'t make it about him.' },
      { label: '"No thanks. Not my thing."', note: 'Flat and final. No explanation owed.' },
      { label: 'Get up and go buy a drink.', note: 'Physical exit. Sometimes the strongest move is just not being in the conversation anymore.' },
    ],
  },
  {
    id: 'exam-burnout',
    label: 'Exam-week burnout',
    hasDrugs: false,
    setup: 'Three papers in four days and you haven\'t slept properly all week. A course-mate says they\'ve got something that\'ll help you "lock in" for one more all-nighter — no details, just a knowing look and "trust me, everyone does it before finals."',
    exits: [
      { label: '"I\'ll just take the L on this one paper and sleep."', note: 'Sometimes the exit is lowering the stakes, not fighting through them.' },
      { label: '"I\'m gonna go nap for two hours and try again."', note: 'Buys time without a confrontation.' },
      { label: 'Text a friend who isn\'t in this room.', note: 'Getting one outside voice into the moment often breaks its pull.' },
    ],
  },
  {
    id: 'brothers-friends',
    label: "A friend's older brother",
    hasDrugs: false,
    setup: 'You\'re at a friend\'s place and his older brother\'s crew is over, a few years ahead of you, clearly the "cool" ones. One of them offers you a vape that isn\'t just nicotine and says "don\'t be soft, your boy does it too" — except your friend looks just as uncomfortable as you feel.',
    exits: [
      { label: '"Nah, I\'m good." and catch your friend\'s eye.', note: 'You don\'t have to say more — a look can be an exit for two people at once.' },
      { label: '"We were about to head out anyway."', note: 'Gives both of you a shared reason to leave the room.' },
      { label: 'Ask to see something else in the house.', note: 'Redirecting the moment is a real exit, not a dodge.' },
    ],
  },
  {
    id: 'overseas-trip',
    label: 'Overseas trip',
    hasDrugs: false,
    setup: 'You\'re on a grad trip somewhere the rules feel looser. Someone in the group says "it\'s basically legal here, no one back home will ever know" and passes something round the table.',
    exits: [
      { label: '"Singapore\'s rules follow me home, so no."', note: 'Singapore law can apply to citizens and PRs even overseas, so "no one back home will ever know" is not a safe bet. Practical, not preachy.' },
      { label: '"I\'m good, I want a clear head for tomorrow."', note: 'Ties the no to something you\'re looking forward to, not to fear.' },
      { label: 'Step outside to take photos / call home.', note: 'A believable, low-drama reason to not be at the table right then.' },
    ],
  },
  {
    id: 'party-alcohol',
    label: 'A party where the pressure is alcohol',
    hasDrugs: false,
    setup: 'Someone\'s already lining up shots and pushing one into your hand, loudly, in front of people you\'re trying to make a good impression on. "Come on, one won\'t kill you."',
    exits: [
      { label: '"I\'m driving later."', note: 'One of the few reasons almost nobody argues with.' },
      { label: '"I\'m good with this drink, thanks."', note: 'Hold up what\'s already in your hand instead of explaining an empty one.' },
      { label: '"Race you to the food table instead."', note: 'Redirect the energy rather than refusing it head-on.' },
    ],
  },
  {
    id: 'group-chat',
    label: 'The group chat',
    hasDrugs: false,
    setup: 'A chat you\'re in is hyping up a "plan" for the weekend that you\'re not comfortable with, and everyone\'s replying with fire emojis. Silence in a group chat can feel louder than saying no out loud.',
    exits: [
      { label: 'React, don\'t reply. "👍" then quietly don\'t show up.', note: 'You don\'t owe the group chat a debate.' },
      { label: 'DM one person you trust in the group instead.', note: 'Peeling off one ally is often easier than addressing the whole chat.' },
      { label: '"Can\'t make it, got something on."', note: 'A group chat isn\'t a courtroom. You don\'t need a verified alibi.' },
    ],
  },
];

export function PressureScenarios(): JSX.Element {
  const [selectedId, setSelectedId] = useState<string>(SCENARIOS[0]?.id || '');
  const [chosenExit, setChosenExit] = useState<number | null>(null);

  const scenario = SCENARIOS.find((s) => s.id === selectedId) || SCENARIOS[0]!;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight text-fg">Pressure Scenarios</h2>
        <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
      </div>
      <p className="text-sm text-muted">
        Practise getting out of a moment. At least 4 of 6 scenarios have zero drugs — because exit-from-pressure is a general skill.
      </p>

      {/* Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-none">
        {SCENARIOS.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => {
              setSelectedId(s.id);
              setChosenExit(null);
            }}
            className={`tap-target shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              s.id === selectedId
                ? 'bg-accent-500 text-ink-950 font-semibold'
                : 'bg-ink-900 border border-line text-muted hover:text-fg'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Scenario card */}
      <div className="rounded-xl2 border border-line bg-ink-900 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase tracking-wide font-mono text-accent-400">The Situation</span>
          {scenario.hasDrugs ? (
            <span className="text-xs px-2 py-0.5 rounded-full border border-flag-500/40 text-flag-500 bg-flag-900/30">
              Substance pressure
            </span>
          ) : (
            <span className="text-xs px-2 py-0.5 rounded-full border border-line text-subtle">
              Social pressure
            </span>
          )}
        </div>
        <p className="leading-relaxed text-fg text-sm">{scenario.setup}</p>
      </div>

      {/* Exits */}
      <div className="space-y-2">
        <p className="text-xs font-mono uppercase tracking-wider text-subtle">Choose an exit tactic</p>
        {scenario.exits.map((exit, idx) => (
          <div
            key={idx}
            className={`rounded-xl border p-3.5 transition cursor-pointer ${
              chosenExit === idx
                ? 'border-accent-400 bg-accent-950/30'
                : 'border-line bg-ink-900 hover:border-ink-600'
            }`}
            onClick={() => setChosenExit(idx)}
          >
            <p className="font-semibold text-fg text-sm">{exit.label}</p>
            {chosenExit === idx ? (
              <p className="mt-2 text-xs text-accent-400 leading-relaxed border-t border-line/60 pt-2">
                💡 <span className="font-medium">Why it works:</span> {exit.note}
              </p>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}
