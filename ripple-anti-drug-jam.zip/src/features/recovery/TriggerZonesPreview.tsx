import { useState } from 'react';
import { PlaceholderChip } from '@/components/PlaceholderChip';

interface Zone {
  id: string;
  name: string;
  type: string;
}

const DEFAULT_ZONES: Zone[] = [
  { id: '1', name: 'Old hangout spot near Clarke Quay', type: 'High risk' },
  { id: '2', name: 'Late night void deck gathering area', type: 'Caution' },
];

export function TriggerZonesPreview(): JSX.Element {
  const [zones, setZones] = useState<Zone[]>(() => {
    try {
      const saved = localStorage.getItem('ten_percent_mock_zones');
      if (saved) return JSON.parse(saved) as Zone[];
    } catch {
      // Ignore
    }
    return DEFAULT_ZONES;
  });

  const [alertFired, setAlertFired] = useState(false);
  const [newZoneName, setNewZoneName] = useState('');

  const handleAddZone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newZoneName.trim()) return;
    const updated = [...zones, { id: Date.now().toString(), name: newZoneName.trim(), type: 'Custom zone' }];
    setZones(updated);
    setNewZoneName('');
    try {
      localStorage.setItem('ten_percent_mock_zones', JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  const handleSimulate = () => {
    setAlertFired(true);
    setTimeout(() => setAlertFired(false), 5000);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold tracking-tight text-fg">Trigger Zones (Simulation)</h2>
        <PlaceholderChip status="UNREVIEWED_PLACEHOLDER" />
      </div>

      <div className="rounded-xl border border-line bg-ink-950 p-3.5 text-xs text-subtle leading-relaxed">
        🔒 <span className="font-semibold text-fg">Zero GPS Tracking:</span> This feature never accesses your device&apos;s real location or the Geolocation API. All markers are stored locally in your browser storage.
      </div>

      {/* Simulated radar map */}
      <div className="relative h-44 w-full rounded-xl2 border border-line bg-ink-900 overflow-hidden flex items-center justify-center">
        {/* Radar concentric rings */}
        <div className="absolute inset-0 flex items-center justify-center opacity-30">
          <div className="w-64 h-64 rounded-full border border-accent-400/40" />
          <div className="w-44 h-44 rounded-full border border-accent-400/60" />
          <div className="w-24 h-24 rounded-full border border-accent-400" />
        </div>
        {/* Radar sweeping line */}
        <div className="absolute w-32 h-0.5 bg-gradient-to-r from-transparent to-accent-400 origin-left animate-spin duration-3000" />

        {/* Simulated markers */}
        <div className="absolute top-8 left-12 flex flex-col items-center">
          <span className="h-3 w-3 rounded-full bg-flag-500 animate-ping" />
          <span className="text-[10px] font-mono text-flag-200 mt-1 bg-ink-950/80 px-1.5 py-0.5 rounded">Zone A</span>
        </div>
        <div className="absolute bottom-10 right-16 flex flex-col items-center">
          <span className="h-3 w-3 rounded-full bg-accent-400" />
          <span className="text-[10px] font-mono text-accent-200 mt-1 bg-ink-950/80 px-1.5 py-0.5 rounded">Safe Haven</span>
        </div>

        <div className="z-10 bg-ink-950/90 border border-line px-3 py-1.5 rounded-full text-xs font-mono text-fg">
          Simulated Sanctuary Radar
        </div>
      </div>

      {alertFired ? (
        <div className="rounded-xl border border-crisis-500 bg-crisis-950/60 p-4 text-center animate-pulse space-y-1">
          <p className="text-sm font-bold text-crisis-300">🚨 APPROACH ALERT (SIMULATED)</p>
          <p className="text-xs text-fg">You are approaching a registered trigger zone. Take 3 deep breaths or open a refusal script.</p>
        </div>
      ) : null}

      <button
        type="button"
        onClick={handleSimulate}
        className="tap-target w-full rounded-xl bg-accent-500 text-ink-950 font-bold py-3 text-sm transition hover:bg-accent-400"
      >
        Simulate approaching a zone
      </button>

      {/* Zone list */}
      <div className="space-y-2 pt-2">
        <p className="text-xs font-mono uppercase tracking-wider text-subtle">Saved safe zones</p>
        {zones.map((zone) => (
          <div key={zone.id} className="flex items-center justify-between rounded-xl border border-line bg-ink-900 p-3 text-xs">
            <span className="font-medium text-fg">{zone.name}</span>
            <span className="rounded px-2 py-0.5 border border-line text-subtle">{zone.type}</span>
          </div>
        ))}
      </div>

      <form onSubmit={handleAddZone} className="flex gap-2">
        <input
          type="text"
          value={newZoneName}
          onChange={(e) => setNewZoneName(e.target.value)}
          placeholder="Add custom trigger zone name..."
          className="flex-1 rounded-xl border border-line bg-ink-900 px-3 py-2 text-xs text-fg placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent-400"
        />
        <button
          type="submit"
          className="tap-target rounded-xl border border-line bg-ink-800 px-4 py-2 text-xs font-semibold text-fg hover:bg-ink-700"
        >
          Add
        </button>
      </form>
    </div>
  );
}
